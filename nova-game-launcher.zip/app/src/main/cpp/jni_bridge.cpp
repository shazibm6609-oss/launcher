#include <jni.h>
#include <memory>
#include <vector>
#include "NovaAudioEngine.h"

namespace {
std::unique_ptr<nova_dsp::NovaAudioEngine> gEngine;
std::unique_ptr<nova_dsp::NovaDspPipeline> gOfflineDsp;
}

extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_example_audio_NativeVoiceBridge_nativeStart(
    JNIEnv* env, jobject /*thiz*/,
    jint inputDeviceId, jint outputDeviceId, jint sampleRate, jint framesPerBurst) {
    if (!gEngine) {
        gEngine = std::make_unique<nova_dsp::NovaAudioEngine>();
    }
    return gEngine->start(inputDeviceId, outputDeviceId, sampleRate, framesPerBurst) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_example_audio_NativeVoiceBridge_nativeStop(JNIEnv* /*env*/, jobject /*thiz*/) {
    if (gEngine) {
        gEngine->stop();
    }
}

JNIEXPORT jboolean JNICALL
Java_com_example_audio_NativeVoiceBridge_nativeIsRunning(JNIEnv* /*env*/, jobject /*thiz*/) {
    return (gEngine && gEngine->isRunning()) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_example_audio_NativeVoiceBridge_nativeUpdateParams(
    JNIEnv* /*env*/, jobject /*thiz*/,
    jboolean effectEnabled, jboolean bypassOriginal,
    jfloat pitchSemitones, jfloat formantShift,
    jfloat brightness, jfloat softness, jfloat tone, jfloat cartoonTone,
    jfloat effectIntensity, jboolean noiseReduction,
    jfloat eqBassDb, jfloat eqMidDb, jfloat eqTrebleDb,
    jfloat echoAmount, jfloat reverbAmount,
    jfloat inputGain, jfloat outputGain, jint characterMode) {
    nova_dsp::DspParameters p;
    p.effectEnabled = (effectEnabled == JNI_TRUE);
    p.bypassOriginal = (bypassOriginal == JNI_TRUE);
    p.pitchSemitones = pitchSemitones;
    p.formantShift = formantShift;
    p.brightness = brightness;
    p.softness = softness;
    p.tone = tone;
    p.cartoonTone = cartoonTone;
    p.effectIntensity = effectIntensity;
    p.noiseReduction = (noiseReduction == JNI_TRUE);
    p.eqBassDb = eqBassDb;
    p.eqMidDb = eqMidDb;
    p.eqTrebleDb = eqTrebleDb;
    p.echoAmount = echoAmount;
    p.reverbAmount = reverbAmount;
    p.inputGain = inputGain;
    p.outputGain = outputGain;
    p.characterMode = characterMode;
    if (gEngine) {
        gEngine->updateParameters(p);
    }
}

JNIEXPORT jfloatArray JNICALL
Java_com_example_audio_NativeVoiceBridge_nativeGetMetrics(JNIEnv* env, jobject /*thiz*/) {
    jfloatArray arr = env->NewFloatArray(6);
    float vals[6] = {0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 48000.0f};
    if (gEngine) {
        vals[0] = gEngine->getInputRms();
        vals[1] = gEngine->getOutputRms();
        vals[2] = gEngine->getPeakLevel();
        vals[3] = gEngine->getLatencyMs();
        vals[4] = static_cast<float>(gEngine->getDspCpuUs());
        vals[5] = static_cast<float>(gEngine->getActualSampleRate());
    }
    env->SetFloatArrayRegion(arr, 0, 6, vals);
    return arr;
}

JNIEXPORT jstring JNICALL
Java_com_example_audio_NativeVoiceBridge_nativeGetAudioApi(JNIEnv* env, jobject /*thiz*/) {
    std::string api = gEngine ? gEngine->getAudioApiName() : "Inactive";
    return env->NewStringUTF(api.c_str());
}

JNIEXPORT void JNICALL
Java_com_example_audio_NativeVoiceBridge_nativeGetWaveform(JNIEnv* env, jobject /*thiz*/, jfloatArray outWave) {
    if (!gEngine || !outWave) return;
    jsize len = env->GetArrayLength(outWave);
    std::vector<float> buf(static_cast<size_t>(len), 0.0f);
    gEngine->copyWaveform(buf.data(), len);
    env->SetFloatArrayRegion(outWave, 0, len, buf.data());
}

JNIEXPORT void JNICALL
Java_com_example_audio_NativeVoiceBridge_nativePrepareOffline(JNIEnv* /*env*/, jobject /*thiz*/, jfloat sampleRate) {
    if (!gOfflineDsp) {
        gOfflineDsp = std::make_unique<nova_dsp::NovaDspPipeline>();
    }
    gOfflineDsp->prepare(sampleRate);
}

JNIEXPORT void JNICALL
Java_com_example_audio_NativeVoiceBridge_nativeProcessOffline(
    JNIEnv* env, jobject /*thiz*/,
    jfloatArray inputArr, jfloatArray outputArr,
    jboolean effectEnabled, jboolean bypassOriginal,
    jfloat pitchSemitones, jfloat formantShift,
    jfloat brightness, jfloat softness, jfloat tone, jfloat cartoonTone,
    jfloat effectIntensity, jboolean noiseReduction,
    jfloat eqBassDb, jfloat eqMidDb, jfloat eqTrebleDb,
    jfloat echoAmount, jfloat reverbAmount,
    jfloat inputGain, jfloat outputGain, jint characterMode) {
    if (!gOfflineDsp) {
        gOfflineDsp = std::make_unique<nova_dsp::NovaDspPipeline>();
        gOfflineDsp->prepare(48000.0f);
    }
    jsize len = env->GetArrayLength(inputArr);
    std::vector<float> inBuf(static_cast<size_t>(len));
    std::vector<float> outBuf(static_cast<size_t>(len));
    env->GetFloatArrayRegion(inputArr, 0, len, inBuf.data());

    nova_dsp::DspParameters p;
    p.effectEnabled = (effectEnabled == JNI_TRUE);
    p.bypassOriginal = (bypassOriginal == JNI_TRUE);
    p.pitchSemitones = pitchSemitones;
    p.formantShift = formantShift;
    p.brightness = brightness;
    p.softness = softness;
    p.tone = tone;
    p.cartoonTone = cartoonTone;
    p.effectIntensity = effectIntensity;
    p.noiseReduction = (noiseReduction == JNI_TRUE);
    p.eqBassDb = eqBassDb;
    p.eqMidDb = eqMidDb;
    p.eqTrebleDb = eqTrebleDb;
    p.echoAmount = echoAmount;
    p.reverbAmount = reverbAmount;
    p.inputGain = inputGain;
    p.outputGain = outputGain;
    p.characterMode = characterMode;

    gOfflineDsp->processBlock(inBuf.data(), outBuf.data(), len, p);
    env->SetFloatArrayRegion(outputArr, 0, len, outBuf.data());
}

}  // extern "C"
