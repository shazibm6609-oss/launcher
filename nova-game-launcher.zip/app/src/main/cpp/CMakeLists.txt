cmake_minimum_required(VERSION 3.22.1)
project("nova_dsp" LANGUAGES CXX)

find_package(oboe REQUIRED CONFIG)

add_library(
    nova_dsp
    SHARED
    NovaAudioEngine.cpp
    jni_bridge.cpp
)

target_compile_features(nova_dsp PRIVATE cxx_std_17)

find_library(log-lib log)

target_link_libraries(
    nova_dsp
    oboe::oboe
    ${log-lib}
)
