#pragma once

#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstdint>

namespace nova_dsp {

constexpr float kPi = 3.14159265358979323846f;
constexpr float kTwoPi = 2.0f * kPi;

struct DspParameters {
    bool effectEnabled = true;
    bool bypassOriginal = false;
    float pitchSemitones = 0.0f;      // -12 .. +12
    float formantShift = 1.0f;        // 0.65 .. 1.45
    float brightness = 0.0f;          // -1 .. +1
    float softness = 0.0f;            // 0 .. 1
    float tone = 0.0f;                // -1 .. +1
    float cartoonTone = 0.0f;         // 0 .. 1
    float effectIntensity = 1.0f;     // 0 .. 1
    bool noiseReduction = true;
    float eqBassDb = 0.0f;            // -12 .. +12
    float eqMidDb = 0.0f;             // -12 .. +12
    float eqTrebleDb = 0.0f;          // -12 .. +12
    float echoAmount = 0.0f;          // 0 .. 1
    float reverbAmount = 0.0f;        // 0 .. 1
    float inputGain = 1.0f;           // 0 .. 2.5
    float outputGain = 1.0f;          // 0 .. 2.5
    int characterMode = 0;            // 0=Natural, 1=Robot, 2=Alien, 3=Radio
};

class BiquadFilter {
public:
    void reset() {
        z1_ = 0.0f;
        z2_ = 0.0f;
    }

    void setHighPass(float sampleRate, float freq, float q = 0.707f) {
        float w0 = kTwoPi * std::clamp(freq, 20.0f, sampleRate * 0.45f) / sampleRate;
        float cosW0 = std::cos(w0);
        float alpha = std::sin(w0) / (2.0f * std::max(0.1f, q));
        float a0 = 1.0f + alpha;
        b0_ = ((1.0f + cosW0) * 0.5f) / a0;
        b1_ = -(1.0f + cosW0) / a0;
        b2_ = ((1.0f + cosW0) * 0.5f) / a0;
        a1_ = (-2.0f * cosW0) / a0;
        a2_ = (1.0f - alpha) / a0;
    }

    void setLowPass(float sampleRate, float freq, float q = 0.707f) {
        float w0 = kTwoPi * std::clamp(freq, 20.0f, sampleRate * 0.45f) / sampleRate;
        float cosW0 = std::cos(w0);
        float alpha = std::sin(w0) / (2.0f * std::max(0.1f, q));
        float a0 = 1.0f + alpha;
        b0_ = ((1.0f - cosW0) * 0.5f) / a0;
        b1_ = (1.0f - cosW0) / a0;
        b2_ = ((1.0f - cosW0) * 0.5f) / a0;
        a1_ = (-2.0f * cosW0) / a0;
        a2_ = (1.0f - alpha) / a0;
    }

    void setPeaking(float sampleRate, float freq, float q, float gainDb) {
        float a = std::pow(10.0f, std::clamp(gainDb, -18.0f, 18.0f) / 40.0f);
        float w0 = kTwoPi * std::clamp(freq, 30.0f, sampleRate * 0.45f) / sampleRate;
        float cosW0 = std::cos(w0);
        float alpha = std::sin(w0) / (2.0f * std::max(0.2f, q));
        float a0 = 1.0f + alpha / a;
        b0_ = (1.0f + alpha * a) / a0;
        b1_ = (-2.0f * cosW0) / a0;
        b2_ = (1.0f - alpha * a) / a0;
        a1_ = (-2.0f * cosW0) / a0;
        a2_ = (1.0f - alpha / a) / a0;
    }

    void setLowShelf(float sampleRate, float freq, float gainDb) {
        float a = std::pow(10.0f, std::clamp(gainDb, -18.0f, 18.0f) / 40.0f);
        float w0 = kTwoPi * std::clamp(freq, 30.0f, sampleRate * 0.45f) / sampleRate;
        float cosW0 = std::cos(w0);
        float sinW0 = std::sin(w0);
        float alpha = sinW0 / 2.0f * std::sqrt((a + 1.0f / a) * (1.0f / 0.707f - 1.0f) + 2.0f);
        float twoSqrtAAlpha = 2.0f * std::sqrt(a) * alpha;
        float a0 = (a + 1.0f) + (a - 1.0f) * cosW0 + twoSqrtAAlpha;
        b0_ = (a * ((a + 1.0f) - (a - 1.0f) * cosW0 + twoSqrtAAlpha)) / a0;
        b1_ = (2.0f * a * ((a - 1.0f) - (a + 1.0f) * cosW0)) / a0;
        b2_ = (a * ((a + 1.0f) - (a - 1.0f) * cosW0 - twoSqrtAAlpha)) / a0;
        a1_ = (-2.0f * ((a - 1.0f) + (a + 1.0f) * cosW0)) / a0;
        a2_ = ((a + 1.0f) + (a - 1.0f) * cosW0 - twoSqrtAAlpha) / a0;
    }

    void setHighShelf(float sampleRate, float freq, float gainDb) {
        float a = std::pow(10.0f, std::clamp(gainDb, -18.0f, 18.0f) / 40.0f);
        float w0 = kTwoPi * std::clamp(freq, 30.0f, sampleRate * 0.45f) / sampleRate;
        float cosW0 = std::cos(w0);
        float sinW0 = std::sin(w0);
        float alpha = sinW0 / 2.0f * std::sqrt((a + 1.0f / a) * (1.0f / 0.707f - 1.0f) + 2.0f);
        float twoSqrtAAlpha = 2.0f * std::sqrt(a) * alpha;
        float a0 = (a + 1.0f) - (a - 1.0f) * cosW0 + twoSqrtAAlpha;
        b0_ = (a * ((a + 1.0f) + (a - 1.0f) * cosW0 + twoSqrtAAlpha)) / a0;
        b1_ = (-2.0f * a * ((a - 1.0f) + (a + 1.0f) * cosW0)) / a0;
        b2_ = (a * ((a + 1.0f) + (a - 1.0f) * cosW0 - twoSqrtAAlpha)) / a0;
        a1_ = (2.0f * ((a - 1.0f) - (a + 1.0f) * cosW0)) / a0;
        a2_ = ((a + 1.0f) - (a - 1.0f) * cosW0 - twoSqrtAAlpha) / a0;
    }

    inline float process(float x) {
        float y = b0_ * x + z1_;
        z1_ = b1_ * x - a1_ * y + z2_;
        z2_ = b2_ * x - a2_ * y;
        return y;
    }

private:
    float b0_ = 1.0f, b1_ = 0.0f, b2_ = 0.0f;
    float a1_ = 0.0f, a2_ = 0.0f;
    float z1_ = 0.0f, z2_ = 0.0f;
};

class NovaDspPipeline {
public:
    static constexpr int kPitchBufSize = 4096;
    static constexpr int kPitchMask = kPitchBufSize - 1;
    static constexpr int kWindowSize = 768;
    static constexpr int kEchoBufSize = 24000;
    static constexpr int kRobotCombSize = 512;

    void prepare(float sampleRate) {
        sampleRate_ = std::max(16000.0f, sampleRate);
        pitchBuf_.fill(0.0f);
        echoBuf_.fill(0.0f);
        robotComb_.fill(0.0f);
        comb1_.fill(0.0f);
        comb2_.fill(0.0f);
        comb3_.fill(0.0f);
        comb4_.fill(0.0f);
        ap1_.fill(0.0f);
        ap2_.fill(0.0f);

        writeIdx_ = 0;
        echoIdx_ = 0;
        robotCombIdx_ = 0;
        c1Idx_ = c2Idx_ = c3Idx_ = c4Idx_ = 0;
        ap1Idx_ = ap2Idx_ = 0;
        phaseA_ = 0.0f;
        delayA_ = static_cast<float>(kWindowSize) * 0.5f;
        delayB_ = static_cast<float>(kWindowSize) * 0.5f;
        noiseFloor_ = 0.002f;
        gateGain_ = 1.0f;
        envFollower_ = 0.0f;
        modPhase1_ = 0.0f;
        modPhase2_ = 0.0f;
        lfoPhase_ = 0.0f;

        hpfInput_.reset();
        hpfInput_.setHighPass(sampleRate_, 75.0f, 0.707f);
        updateFilters(lastParams_, true);
    }

    void processBlock(const float* input, float* output, int numFrames, const DspParameters& params) {
        updateFilters(params, false);

        const float pitchRatio = std::pow(2.0f, std::clamp(params.pitchSemitones, -12.0f, 12.0f) / 12.0f);
        const float rateDelta = 1.0f - pitchRatio;
        const float mix = params.bypassOriginal || !params.effectEnabled
                            ? 0.0f
                            : std::clamp(params.effectIntensity, 0.0f, 1.0f);

        const int echoDelaySamples = std::clamp(static_cast<int>(sampleRate_ * 0.21f), 64, kEchoBufSize - 1);
        const int robotCombDelay = std::clamp(static_cast<int>(sampleRate_ * 0.0058f), 16, kRobotCombSize - 1);

        double sumInSq = 0.0;
        double sumOutSq = 0.0;
        float maxPeak = 0.0f;

        for (int i = 0; i < numFrames; ++i) {
            float rawIn = input[i] * params.inputGain;
            float clean = hpfInput_.process(rawIn);
            sumInSq += static_cast<double>(clean * clean);

            // Adaptive noise gate / expander
            float absSample = std::fabs(clean);
            envFollower_ = 0.992f * envFollower_ + 0.008f * absSample;
            if (params.noiseReduction) {
                if (envFollower_ < noiseFloor_ * 1.4f) {
                    noiseFloor_ = 0.9992f * noiseFloor_ + 0.0008f * envFollower_;
                } else {
                    noiseFloor_ = 0.9999f * noiseFloor_ + 0.0001f * envFollower_;
                }
                float threshold = std::max(0.0035f, noiseFloor_ * 2.2f);
                float targetGate = (envFollower_ >= threshold)
                                     ? 1.0f
                                     : std::clamp((envFollower_ / threshold) * (envFollower_ / threshold), 0.08f, 1.0f);
                float coeff = (targetGate > gateGain_) ? 0.05f : 0.004f;
                gateGain_ += coeff * (targetGate - gateGain_);
                clean *= gateGain_;
            }

            // Write clean signal to pitch ring buffer
            pitchBuf_[writeIdx_ & kPitchMask] = clean;

            // Pitch Shifting (Dual-Tap Raised-Cosine Overlap-Add with micro-phase alignment)
            float pitched = clean;
            if (std::fabs(params.pitchSemitones) > 0.05f) {
                float phaseB = phaseA_ + 0.5f;
                if (phaseB >= 1.0f) phaseB -= 1.0f;

                float prevPhaseA = phaseA_;
                phaseA_ += 1.0f / static_cast<float>(kWindowSize);
                if (phaseA_ >= 1.0f) {
                    phaseA_ -= 1.0f;
                    delayA_ = findAlignedDelay(delayB_);
                }
                float prevPhaseB = prevPhaseA + 0.5f;
                if (prevPhaseB >= 1.0f) prevPhaseB -= 1.0f;
                if (prevPhaseB > phaseB) {
                    delayB_ = findAlignedDelay(delayA_);
                }

                delayA_ += rateDelta;
                delayB_ += rateDelta;

                const float minDelay = 16.0f;
                const float maxDelay = static_cast<float>(kPitchBufSize - 64);
                if (delayA_ < minDelay) delayA_ += static_cast<float>(kWindowSize);
                if (delayA_ > maxDelay) delayA_ -= static_cast<float>(kWindowSize);
                if (delayB_ < minDelay) delayB_ += static_cast<float>(kWindowSize);
                if (delayB_ > maxDelay) delayB_ -= static_cast<float>(kWindowSize);

                float wA = 0.5f * (1.0f - std::cos(kTwoPi * phaseA_));
                float wB = 0.5f * (1.0f - std::cos(kTwoPi * phaseB));

                float sA = readLinear(static_cast<float>(writeIdx_) - delayA_);
                float sB = readLinear(static_cast<float>(writeIdx_) - delayB_);
                pitched = sA * wA + sB * wB;
            }

            // Formant & Vocal Tract Shaping
            float vocal = chestFilter_.process(pitched);
            vocal = f1Filter_.process(vocal);
            vocal = f2Filter_.process(vocal);
            vocal = f3Filter_.process(vocal);
            vocal = cartoonFilter_.process(vocal);
            vocal = brightnessFilter_.process(vocal);
            vocal = toneFilter_.process(vocal);

            // Softness: tame harsh sibilance & add gentle warm velvet saturation
            if (params.softness > 0.01f) {
                float softened = softnessFilter_.process(vocal);
                float warm = std::tanh(softened * (1.0f + 0.35f * params.softness)) /
                             std::tanh(1.0f + 0.35f * params.softness);
                vocal = vocal * (1.0f - params.softness) + warm * params.softness;
            }

            // Character Mode Processing
            if (params.characterMode == 1) {
                // Robot Voice: carrier ring-mod + metallic comb resonator
                modPhase1_ += kTwoPi * 112.0f / sampleRate_;
                if (modPhase1_ > kTwoPi) modPhase1_ -= kTwoPi;
                float carrier = 0.65f * std::sin(modPhase1_) + 0.35f * ((modPhase1_ < kPi) ? 1.0f : -1.0f);
                int readComb = (robotCombIdx_ - robotCombDelay + kRobotCombSize) % kRobotCombSize;
                float combOut = vocal + 0.48f * robotComb_[readComb];
                robotComb_[robotCombIdx_] = combOut;
                robotCombIdx_ = (robotCombIdx_ + 1) % kRobotCombSize;
                vocal = 0.55f * (vocal * carrier) + 0.45f * combOut;
            } else if (params.characterMode == 2) {
                // Alien Voice: dual FM ring modulation + slow vibrato wobble
                lfoPhase_ += kTwoPi * 4.5f / sampleRate_;
                if (lfoPhase_ > kTwoPi) lfoPhase_ -= kTwoPi;
                float fmFreq = 46.0f + 18.0f * std::sin(lfoPhase_);
                modPhase1_ += kTwoPi * fmFreq / sampleRate_;
                modPhase2_ += kTwoPi * 165.0f / sampleRate_;
                if (modPhase1_ > kTwoPi) modPhase1_ -= kTwoPi;
                if (modPhase2_ > kTwoPi) modPhase2_ -= kTwoPi;
                float ring = 0.65f * std::sin(modPhase1_) + 0.35f * std::sin(modPhase2_);
                vocal = 0.62f * (vocal * ring) + 0.38f * vocal;
            } else if (params.characterMode == 3) {
                // Radio Voice: narrow comm bandpass + crisp overdrive
                float bp = radioHpf_.process(vocal);
                bp = radioLpf_.process(bp);
                vocal = std::tanh(bp * 2.1f) * 0.72f;
            }

            // 3-Band EQ
            float eqOut = eqBass_.process(vocal);
            eqOut = eqMid_.process(eqOut);
            eqOut = eqTreble_.process(eqOut);

            // Echo + Compact Schroeder Reverb
            float fxOut = eqOut;
            if (params.echoAmount > 0.01f) {
                int rIdx = (echoIdx_ - echoDelaySamples + kEchoBufSize) % kEchoBufSize;
                float delayed = echoBuf_[rIdx];
                echoBuf_[echoIdx_] = eqOut + delayed * 0.36f;
                echoIdx_ = (echoIdx_ + 1) % kEchoBufSize;
                fxOut += delayed * (params.echoAmount * 0.55f);
            } else {
                echoBuf_[echoIdx_] = 0.0f;
                echoIdx_ = (echoIdx_ + 1) % kEchoBufSize;
            }

            if (params.reverbAmount > 0.01f) {
                float rev = processReverb(eqOut);
                fxOut += rev * (params.reverbAmount * 0.45f);
            }

            // Wet/Dry Mix + Output Gain + Soft Limiter
            float blended = clean * (1.0f - mix) + fxOut * mix;
            float outSample = std::tanh(blended * params.outputGain * 0.92f);

            output[i] = outSample;
            sumOutSq += static_cast<double>(outSample * outSample);
            maxPeak = std::max(maxPeak, std::fabs(outSample));

            // Push downsampled waveform point
            if ((writeIdx_ & 63) == 0) {
                int wavePos = waveWriteIdx_.load(std::memory_order_relaxed);
                waveform_[wavePos % kWaveBins] = outSample;
                waveWriteIdx_.store(wavePos + 1, std::memory_order_relaxed);
            }

            writeIdx_ = (writeIdx_ + 1) & kPitchMask;
        }

        if (numFrames > 0) {
            float inRms = static_cast<float>(std::sqrt(sumInSq / numFrames));
            float outRms = static_cast<float>(std::sqrt(sumOutSq / numFrames));
            inputRms_.store(inRms, std::memory_order_relaxed);
            outputRms_.store(outRms, std::memory_order_relaxed);
            peakLevel_.store(maxPeak, std::memory_order_relaxed);
        }
    }

    float getInputRms() const { return inputRms_.load(std::memory_order_relaxed); }
    float getOutputRms() const { return outputRms_.load(std::memory_order_relaxed); }
    float getPeakLevel() const { return peakLevel_.load(std::memory_order_relaxed); }

    void copyWaveform(float* dest, int count) const {
        int n = std::min(count, kWaveBins);
        int head = waveWriteIdx_.load(std::memory_order_relaxed);
        for (int i = 0; i < n; ++i) {
            int idx = (head - n + i + kWaveBins * 4) % kWaveBins;
            dest[i] = waveform_[idx];
        }
    }

    static constexpr int kWaveBins = 48;

private:
    inline float readLinear(float index) const {
        while (index < 0.0f) index += static_cast<float>(kPitchBufSize);
        int i0 = static_cast<int>(index) & kPitchMask;
        int i1 = (i0 + 1) & kPitchMask;
        float frac = index - std::floor(index);
        return pitchBuf_[i0] * (1.0f - frac) + pitchBuf_[i1] * frac;
    }

    float findAlignedDelay(float refDelay) const {
        float baseDelay = static_cast<float>(kWindowSize) * 0.5f;
        float bestOffset = 0.0f;
        float bestCorr = -1e9f;
        for (int offset = -36; offset <= 36; offset += 4) {
            float cand = baseDelay + static_cast<float>(offset);
            float corr = 0.0f;
            for (int k = 0; k < 24; k += 2) {
                float a = readLinear(static_cast<float>(writeIdx_) - cand - static_cast<float>(k));
                float b = readLinear(static_cast<float>(writeIdx_) - refDelay - static_cast<float>(k));
                corr += a * b;
            }
            if (corr > bestCorr) {
                bestCorr = corr;
                bestOffset = static_cast<float>(offset);
            }
        }
        return std::clamp(baseDelay + bestOffset, 32.0f, static_cast<float>(kPitchBufSize - 128));
    }

    float processReverb(float x) {
        const int d1 = 1557, d2 = 1617, d3 = 1491, d4 = 1422;
        const int a1 = 225, a2 = 556;

        float c1 = comb1_[c1Idx_];
        comb1_[c1Idx_] = x + c1 * 0.72f;
        c1Idx_ = (c1Idx_ + 1) % d1;

        float c2 = comb2_[c2Idx_];
        comb2_[c2Idx_] = x + c2 * 0.70f;
        c2Idx_ = (c2Idx_ + 1) % d2;

        float c3 = comb3_[c3Idx_];
        comb3_[c3Idx_] = x + c3 * 0.68f;
        c3Idx_ = (c3Idx_ + 1) % d3;

        float c4 = comb4_[c4Idx_];
        comb4_[c4Idx_] = x + c4 * 0.66f;
        c4Idx_ = (c4Idx_ + 1) % d4;

        float sum = (c1 + c2 + c3 + c4) * 0.25f;

        float buf1 = ap1_[ap1Idx_];
        float out1 = -sum + buf1;
        ap1_[ap1Idx_] = sum + buf1 * 0.5f;
        ap1Idx_ = (ap1Idx_ + 1) % a1;

        float buf2 = ap2_[ap2Idx_];
        float out2 = -out1 + buf2;
        ap2_[ap2Idx_] = out1 + buf2 * 0.5f;
        ap2Idx_ = (ap2Idx_ + 1) % a2;

        return out2;
    }

    void updateFilters(const DspParameters& p, bool force) {
        if (!force &&
            std::fabs(p.formantShift - lastParams_.formantShift) < 0.005f &&
            std::fabs(p.brightness - lastParams_.brightness) < 0.005f &&
            std::fabs(p.softness - lastParams_.softness) < 0.005f &&
            std::fabs(p.tone - lastParams_.tone) < 0.005f &&
            std::fabs(p.cartoonTone - lastParams_.cartoonTone) < 0.005f &&
            std::fabs(p.eqBassDb - lastParams_.eqBassDb) < 0.05f &&
            std::fabs(p.eqMidDb - lastParams_.eqMidDb) < 0.05f &&
            std::fabs(p.eqTrebleDb - lastParams_.eqTrebleDb) < 0.05f) {
            return;
        }
        lastParams_ = p;

        float fs = std::clamp(p.formantShift, 0.65f, 1.45f);
        float delta = fs - 1.0f;

        // Vocal tract chest vs airy formant shifts
        float chestDb = (delta >= 0.0f) ? (-delta * 16.0f) : (-delta * 14.0f);
        chestFilter_.setLowShelf(sampleRate_, 210.0f, std::clamp(chestDb, -10.0f, 9.0f));

        f1Filter_.setPeaking(sampleRate_, 520.0f * fs, 1.35f, delta * 12.0f);
        f2Filter_.setPeaking(sampleRate_, 1480.0f * fs, 1.65f, delta * 14.0f);
        f3Filter_.setPeaking(sampleRate_, 2650.0f * fs, 1.85f, delta * 10.0f);

        cartoonFilter_.setPeaking(sampleRate_, 2150.0f, 2.3f, p.cartoonTone * 9.5f);
        brightnessFilter_.setHighShelf(sampleRate_, 3500.0f, p.brightness * 9.0f);
        toneFilter_.setPeaking(sampleRate_, 1150.0f, 0.9f, p.tone * 6.0f);
        softnessFilter_.setPeaking(sampleRate_, 2400.0f, 1.4f, -p.softness * 5.5f);

        radioHpf_.setHighPass(sampleRate_, 360.0f, 0.85f);
        radioLpf_.setLowPass(sampleRate_, 3050.0f, 0.85f);

        eqBass_.setLowShelf(sampleRate_, 120.0f, p.eqBassDb);
        eqMid_.setPeaking(sampleRate_, 1200.0f, 1.0f, p.eqMidDb);
        eqTreble_.setHighShelf(sampleRate_, 5400.0f, p.eqTrebleDb);
    }

    float sampleRate_ = 48000.0f;
    DspParameters lastParams_{};

    std::array<float, kPitchBufSize> pitchBuf_{};
    std::array<float, kEchoBufSize> echoBuf_{};
    std::array<float, kRobotCombSize> robotComb_{};

    std::array<float, 1600> comb1_{};
    std::array<float, 1650> comb2_{};
    std::array<float, 1520> comb3_{};
    std::array<float, 1450> comb4_{};
    std::array<float, 256> ap1_{};
    std::array<float, 580> ap2_{};

    int writeIdx_ = 0;
    int echoIdx_ = 0;
    int robotCombIdx_ = 0;
    int c1Idx_ = 0, c2Idx_ = 0, c3Idx_ = 0, c4Idx_ = 0;
    int ap1Idx_ = 0, ap2Idx_ = 0;

    float phaseA_ = 0.0f;
    float delayA_ = 384.0f;
    float delayB_ = 384.0f;
    float noiseFloor_ = 0.002f;
    float gateGain_ = 1.0f;
    float envFollower_ = 0.0f;
    float modPhase1_ = 0.0f;
    float modPhase2_ = 0.0f;
    float lfoPhase_ = 0.0f;

    BiquadFilter hpfInput_;
    BiquadFilter chestFilter_;
    BiquadFilter f1Filter_;
    BiquadFilter f2Filter_;
    BiquadFilter f3Filter_;
    BiquadFilter cartoonFilter_;
    BiquadFilter brightnessFilter_;
    BiquadFilter toneFilter_;
    BiquadFilter softnessFilter_;
    BiquadFilter radioHpf_;
    BiquadFilter radioLpf_;
    BiquadFilter eqBass_;
    BiquadFilter eqMid_;
    BiquadFilter eqTreble_;

    std::atomic<float> inputRms_{0.0f};
    std::atomic<float> outputRms_{0.0f};
    std::atomic<float> peakLevel_{0.0f};
    std::array<float, kWaveBins> waveform_{};
    std::atomic<int> waveWriteIdx_{0};
};

}  // namespace nova_dsp
