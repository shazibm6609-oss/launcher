#include "NovaAudioEngine.h"

#include <android/log.h>
#include <chrono>
#include <cstring>

#define LOG_TAG "NovaAudioEngine"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace nova_dsp {

NovaAudioEngine::~NovaAudioEngine() {
    stop();
}

bool NovaAudioEngine::start(int inputDeviceId, int outputDeviceId, int sampleRate, int framesPerBurst) {
    std::lock_guard<std::mutex> lock(streamMutex_);
    if (isRunning_.load()) {
        return true;
    }

    int targetSr = (sampleRate > 0) ? sampleRate : 48000;

    // 1. Open Output Stream first to align native sample rate
    oboe::AudioStreamBuilder outBuilder;
    outBuilder.setDirection(oboe::Direction::Output)
        ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
        ->setSharingMode(oboe::SharingMode::Exclusive)
        ->setFormat(oboe::AudioFormat::Float)
        ->setChannelCount(oboe::ChannelCount::Mono)
        ->setSampleRate(targetSr)
        ->setUsage(oboe::Usage::Media)
        ->setDataCallback(this)
        ->setErrorCallback(this);

    if (outputDeviceId > 0) {
        outBuilder.setDeviceId(outputDeviceId);
    }
    if (framesPerBurst > 0) {
        outBuilder.setFramesPerDataCallback(framesPerBurst);
    }

    oboe::Result res = outBuilder.openStream(outputStream_);
    if (res != oboe::Result::OK || !outputStream_) {
        outBuilder.setSharingMode(oboe::SharingMode::Shared);
        res = outBuilder.openStream(outputStream_);
        if (res != oboe::Result::OK || !outputStream_) {
            LOGE("Failed to open output stream: %s", oboe::convertToText(res));
            return false;
        }
    }

    int actualSr = outputStream_->getSampleRate();
    actualSampleRate_.store(actualSr);
    dsp_.prepare(static_cast<float>(actualSr));

    // 2. Open Full-Duplex Input Stream matching actual sample rate
    oboe::AudioStreamBuilder inBuilder;
    inBuilder.setDirection(oboe::Direction::Input)
        ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
        ->setSharingMode(oboe::SharingMode::Exclusive)
        ->setFormat(oboe::AudioFormat::Float)
        ->setChannelCount(oboe::ChannelCount::Mono)
        ->setSampleRate(actualSr)
        ->setInputPreset(oboe::InputPreset::VoiceCommunication);

    if (inputDeviceId > 0) {
        inBuilder.setDeviceId(inputDeviceId);
    }

    res = inBuilder.openStream(inputStream_);
    if (res != oboe::Result::OK || !inputStream_) {
        inBuilder.setSharingMode(oboe::SharingMode::Shared)
            ->setInputPreset(oboe::InputPreset::Generic);
        res = inBuilder.openStream(inputStream_);
        if (res != oboe::Result::OK || !inputStream_) {
            LOGE("Failed to open input stream: %s", oboe::convertToText(res));
            outputStream_->close();
            outputStream_.reset();
            return false;
        }
    }

    warmupCallbacks_.store(0);

    // Start input before output so mic frames are primed
    res = inputStream_->requestStart();
    if (res != oboe::Result::OK) {
        LOGE("Failed to start input stream: %s", oboe::convertToText(res));
        inputStream_->close();
        outputStream_->close();
        inputStream_.reset();
        outputStream_.reset();
        return false;
    }

    res = outputStream_->requestStart();
    if (res != oboe::Result::OK) {
        LOGE("Failed to start output stream: %s", oboe::convertToText(res));
        inputStream_->requestStop();
        inputStream_->close();
        outputStream_->close();
        inputStream_.reset();
        outputStream_.reset();
        return false;
    }

    isRunning_.store(true);
    LOGI("Oboe full-duplex started at %d Hz (%s)", actualSr, getAudioApiName().c_str());
    return true;
}

void NovaAudioEngine::stop() {
    std::lock_guard<std::mutex> lock(streamMutex_);
    isRunning_.store(false);
    if (outputStream_) {
        outputStream_->requestStop();
        outputStream_->close();
        outputStream_.reset();
    }
    if (inputStream_) {
        inputStream_->requestStop();
        inputStream_->close();
        inputStream_.reset();
    }
}

void NovaAudioEngine::updateParameters(const DspParameters& params) {
    effectEnabled_.store(params.effectEnabled, std::memory_order_relaxed);
    bypassOriginal_.store(params.bypassOriginal, std::memory_order_relaxed);
    pitchSemitones_.store(params.pitchSemitones, std::memory_order_relaxed);
    formantShift_.store(params.formantShift, std::memory_order_relaxed);
    brightness_.store(params.brightness, std::memory_order_relaxed);
    softness_.store(params.softness, std::memory_order_relaxed);
    tone_.store(params.tone, std::memory_order_relaxed);
    cartoonTone_.store(params.cartoonTone, std::memory_order_relaxed);
    effectIntensity_.store(params.effectIntensity, std::memory_order_relaxed);
    noiseReduction_.store(params.noiseReduction, std::memory_order_relaxed);
    eqBassDb_.store(params.eqBassDb, std::memory_order_relaxed);
    eqMidDb_.store(params.eqMidDb, std::memory_order_relaxed);
    eqTrebleDb_.store(params.eqTrebleDb, std::memory_order_relaxed);
    echoAmount_.store(params.echoAmount, std::memory_order_relaxed);
    reverbAmount_.store(params.reverbAmount, std::memory_order_relaxed);
    inputGain_.store(params.inputGain, std::memory_order_relaxed);
    outputGain_.store(params.outputGain, std::memory_order_relaxed);
    characterMode_.store(params.characterMode, std::memory_order_relaxed);
}

std::string NovaAudioEngine::getAudioApiName() const {
    if (!outputStream_) return "Inactive";
    return (outputStream_->getAudioApi() == oboe::AudioApi::AAudio) ? "AAudio (Oboe)" : "OpenSL ES (Oboe)";
}

oboe::DataCallbackResult NovaAudioEngine::onAudioReady(
    oboe::AudioStream* audioStream,
    void* audioData,
    int32_t numFrames) {
    auto* outBuf = static_cast<float*>(audioData);
    int32_t frames = std::min(numFrames, static_cast<int32_t>(scratchInput_.size()));

    if (!isRunning_.load() || !inputStream_) {
        std::memset(outBuf, 0, static_cast<size_t>(numFrames) * sizeof(float));
        return oboe::DataCallbackResult::Continue;
    }

    auto tStart = std::chrono::steady_clock::now();

    // Drain initial priming callbacks cleanly
    int cbCount = warmupCallbacks_.fetch_add(1, std::memory_order_relaxed);
    if (cbCount < 3) {
        inputStream_->read(scratchInput_.data(), frames, 0);
        std::memset(outBuf, 0, static_cast<size_t>(numFrames) * sizeof(float));
        return oboe::DataCallbackResult::Continue;
    }

    auto readResult = inputStream_->read(scratchInput_.data(), frames, 0);
    int32_t framesRead = readResult ? readResult.value() : 0;
    if (framesRead < frames) {
        std::memset(scratchInput_.data() + framesRead, 0, static_cast<size_t>(frames - framesRead) * sizeof(float));
    }

    DspParameters params;
    params.effectEnabled = effectEnabled_.load(std::memory_order_relaxed);
    params.bypassOriginal = bypassOriginal_.load(std::memory_order_relaxed);
    params.pitchSemitones = pitchSemitones_.load(std::memory_order_relaxed);
    params.formantShift = formantShift_.load(std::memory_order_relaxed);
    params.brightness = brightness_.load(std::memory_order_relaxed);
    params.softness = softness_.load(std::memory_order_relaxed);
    params.tone = tone_.load(std::memory_order_relaxed);
    params.cartoonTone = cartoonTone_.load(std::memory_order_relaxed);
    params.effectIntensity = effectIntensity_.load(std::memory_order_relaxed);
    params.noiseReduction = noiseReduction_.load(std::memory_order_relaxed);
    params.eqBassDb = eqBassDb_.load(std::memory_order_relaxed);
    params.eqMidDb = eqMidDb_.load(std::memory_order_relaxed);
    params.eqTrebleDb = eqTrebleDb_.load(std::memory_order_relaxed);
    params.echoAmount = echoAmount_.load(std::memory_order_relaxed);
    params.reverbAmount = reverbAmount_.load(std::memory_order_relaxed);
    params.inputGain = inputGain_.load(std::memory_order_relaxed);
    params.outputGain = outputGain_.load(std::memory_order_relaxed);
    params.characterMode = characterMode_.load(std::memory_order_relaxed);

    dsp_.processBlock(scratchInput_.data(), outBuf, frames, params);
    if (numFrames > frames) {
        std::memset(outBuf + frames, 0, static_cast<size_t>(numFrames - frames) * sizeof(float));
    }

    auto tEnd = std::chrono::steady_clock::now();
    int us = static_cast<int>(std::chrono::duration_cast<std::chrono::microseconds>(tEnd - tStart).count());
    dspCpuUs_.store(us, std::memory_order_relaxed);

    if ((cbCount & 15) == 0) {
        auto outLat = outputStream_->calculateLatencyMillis();
        auto inLat = inputStream_->calculateLatencyMillis();
        double totalLat = 0.0;
        if (outLat) totalLat += outLat.value();
        if (inLat) totalLat += inLat.value();
        if (totalLat <= 0.0) {
            totalLat = (static_cast<double>(frames) * 2.0 / std::max(16000, actualSampleRate_.load())) * 1000.0;
        }
        latencyMs_.store(static_cast<float>(totalLat), std::memory_order_relaxed);
    }

    return oboe::DataCallbackResult::Continue;
}

void NovaAudioEngine::onErrorAfterClose(oboe::AudioStream* stream, oboe::Result error) {
    LOGE("Oboe stream error after close: %s", oboe::convertToText(error));
    isRunning_.store(false);
}

}  // namespace nova_dsp
