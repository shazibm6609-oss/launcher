#pragma once

#include <oboe/Oboe.h>
#include <array>
#include <atomic>
#include <memory>
#include <mutex>
#include <string>
#include "NovaDspPipeline.h"

namespace nova_dsp {

class NovaAudioEngine : public oboe::AudioStreamDataCallback,
                        public oboe::AudioStreamErrorCallback {
public:
    NovaAudioEngine() = default;
    ~NovaAudioEngine() override;

    bool start(int inputDeviceId, int outputDeviceId, int sampleRate, int framesPerBurst);
    void stop();
    bool isRunning() const { return isRunning_.load(); }

    void updateParameters(const DspParameters& params);

    float getInputRms() const { return dsp_.getInputRms(); }
    float getOutputRms() const { return dsp_.getOutputRms(); }
    float getPeakLevel() const { return dsp_.getPeakLevel(); }
    float getLatencyMs() const { return latencyMs_.load(); }
    int getDspCpuUs() const { return dspCpuUs_.load(); }
    int getActualSampleRate() const { return actualSampleRate_.load(); }
    std::string getAudioApiName() const;
    void copyWaveform(float* dest, int count) const { dsp_.copyWaveform(dest, count); }

    oboe::DataCallbackResult onAudioReady(
        oboe::AudioStream* audioStream,
        void* audioData,
        int32_t numFrames) override;

    void onErrorAfterClose(oboe::AudioStream* stream, oboe::Result error) override;

private:
    std::shared_ptr<oboe::AudioStream> inputStream_;
    std::shared_ptr<oboe::AudioStream> outputStream_;
    NovaDspPipeline dsp_;

    std::atomic<bool> isRunning_{false};
    std::atomic<float> latencyMs_{0.0f};
    std::atomic<int> dspCpuUs_{0};
    std::atomic<int> actualSampleRate_{48000};
    std::atomic<int> warmupCallbacks_{0};

    // Atomic parameter snapshot read lock-free in audio callback
    std::atomic<bool> effectEnabled_{true};
    std::atomic<bool> bypassOriginal_{false};
    std::atomic<float> pitchSemitones_{0.0f};
    std::atomic<float> formantShift_{1.0f};
    std::atomic<float> brightness_{0.0f};
    std::atomic<float> softness_{0.0f};
    std::atomic<float> tone_{0.0f};
    std::atomic<float> cartoonTone_{0.0f};
    std::atomic<float> effectIntensity_{1.0f};
    std::atomic<bool> noiseReduction_{true};
    std::atomic<float> eqBassDb_{0.0f};
    std::atomic<float> eqMidDb_{0.0f};
    std::atomic<float> eqTrebleDb_{0.0f};
    std::atomic<float> echoAmount_{0.0f};
    std::atomic<float> reverbAmount_{0.0f};
    std::atomic<float> inputGain_{1.0f};
    std::atomic<float> outputGain_{1.0f};
    std::atomic<int> characterMode_{0};

    std::array<float, 4096> scratchInput_{};
    std::mutex streamMutex_;
};

}  // namespace nova_dsp
