package com.example.data

import com.example.model.OperatingMode
import com.example.model.PerformanceMode
import com.example.model.SensitivityProfile
import com.example.model.VoiceCategory
import com.example.model.VoiceParameters
import com.example.model.VoicePreset
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.UUID

class NovaRepository(
    private val database: NovaDatabase,
    private val preferences: NovaPreferences
) {
    private val presetDao = database.customVoicePresetDao()
    private val sensitivityDao = database.sensitivityProfileDao()
    private val gameDao = database.gameProfileDao()

    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
    }

    val settingsFlow: Flow<AppSettings> = preferences.settingsFlow

    val customVoicePresetsFlow: Flow<List<VoicePreset>> = presetDao.observeAll().map { list ->
        list.map { e ->
            VoicePreset(
                id = e.id,
                name = e.name,
                category = VoiceCategory.entries.firstOrNull { it.name == e.category } ?: VoiceCategory.CUSTOM,
                description = e.description,
                isBuiltIn = false,
                params = VoiceParameters(
                    pitchSemitones = e.pitchSemitones,
                    formantShift = e.formantShift,
                    brightness = e.brightness,
                    softness = e.softness,
                    tone = e.tone,
                    cartoonTone = e.cartoonTone,
                    effectIntensity = e.effectIntensity,
                    noiseReduction = e.noiseReduction,
                    eqBassDb = e.eqBassDb,
                    eqMidDb = e.eqMidDb,
                    eqTrebleDb = e.eqTrebleDb,
                    echoAmount = e.echoAmount,
                    reverbAmount = e.reverbAmount,
                    inputGain = e.inputGain,
                    outputGain = e.outputGain,
                    characterMode = e.characterMode
                )
            )
        }
    }

    val sensitivityProfilesFlow: Flow<List<SensitivityProfile>> = sensitivityDao.observeAll().map { list ->
        list.map { e ->
            SensitivityProfile(
                id = e.id,
                name = e.name,
                general = e.general,
                redDot = e.redDot,
                scope2x = e.scope2x,
                scope4x = e.scope4x,
                sniperScope = e.sniperScope,
                freeLook = e.freeLook,
                linkedPackage = e.linkedPackage,
                updatedAt = e.updatedAt
            )
        }
    }

    val gameProfilesFlow: Flow<Map<String, GameProfileEntity>> = gameDao.observeAll().map { list ->
        list.associateBy { it.packageName }
    }

    suspend fun seedDefaultsIfEmpty() {
        if (sensitivityDao.count() == 0) {
            sensitivityDao.upsertAll(
                listOf(
                    SensitivityProfileEntity(
                        id = "ff_onetap",
                        name = "Free Fire Headshot Pro",
                        general = 185,
                        redDot = 172,
                        scope2x = 158,
                        scope4x = 140,
                        sniperScope = 96,
                        freeLook = 165,
                        linkedPackage = "com.dts.freefireth"
                    ),
                    SensitivityProfileEntity(
                        id = "ff_max_balanced",
                        name = "Free Fire MAX Balanced",
                        general = 160,
                        redDot = 148,
                        scope2x = 135,
                        scope4x = 118,
                        sniperScope = 82,
                        freeLook = 140,
                        linkedPackage = "com.dts.freefiremax"
                    ),
                    SensitivityProfileEntity(
                        id = "tactical_sniper",
                        name = "Precision Long-Range",
                        general = 120,
                        redDot = 110,
                        scope2x = 95,
                        scope4x = 78,
                        sniperScope = 54,
                        freeLook = 125,
                        linkedPackage = null
                    )
                )
            )
        }
    }

    suspend fun saveCustomVoicePreset(
        name: String,
        category: VoiceCategory,
        description: String,
        params: VoiceParameters
    ): VoicePreset {
        val id = "custom_${UUID.randomUUID().toString().take(8)}"
        val entity = CustomVoicePresetEntity(
            id = id,
            name = name.trim(),
            category = category.name,
            description = description.ifBlank { "Custom studio DSP preset" },
            pitchSemitones = params.pitchSemitones,
            formantShift = params.formantShift,
            brightness = params.brightness,
            softness = params.softness,
            tone = params.tone,
            cartoonTone = params.cartoonTone,
            effectIntensity = params.effectIntensity,
            noiseReduction = params.noiseReduction,
            eqBassDb = params.eqBassDb,
            eqMidDb = params.eqMidDb,
            eqTrebleDb = params.eqTrebleDb,
            echoAmount = params.echoAmount,
            reverbAmount = params.reverbAmount,
            inputGain = params.inputGain,
            outputGain = params.outputGain,
            characterMode = params.characterMode
        )
        presetDao.upsert(entity)
        return VoicePreset(id, entity.name, category, entity.description, isBuiltIn = false, params = params)
    }

    suspend fun deleteCustomVoicePreset(id: String) {
        presetDao.deleteById(id)
    }

    suspend fun saveSensitivityProfile(profile: SensitivityProfile) {
        sensitivityDao.upsert(
            SensitivityProfileEntity(
                id = profile.id,
                name = profile.name.trim(),
                general = profile.general.coerceIn(0, 200),
                redDot = profile.redDot.coerceIn(0, 200),
                scope2x = profile.scope2x.coerceIn(0, 200),
                scope4x = profile.scope4x.coerceIn(0, 200),
                sniperScope = profile.sniperScope.coerceIn(0, 200),
                freeLook = profile.freeLook.coerceIn(0, 200),
                linkedPackage = profile.linkedPackage,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun deleteSensitivityProfile(id: String) {
        sensitivityDao.deleteById(id)
    }

    fun exportSensitivityProfilesToJson(profiles: List<SensitivityProfile>): String {
        return json.encodeToString(profiles)
    }

    suspend fun importSensitivityProfilesFromJson(rawJson: String): Result<Int> {
        return runCatching {
            val decoded = json.decodeFromString<List<SensitivityProfile>>(rawJson)
            val entities = decoded.map { p ->
                val cleanId = p.id.ifBlank { "imp_${UUID.randomUUID().toString().take(8)}" }
                SensitivityProfileEntity(
                    id = cleanId,
                    name = p.name.ifBlank { "Imported Profile" },
                    general = p.general.coerceIn(0, 200),
                    redDot = p.redDot.coerceIn(0, 200),
                    scope2x = p.scope2x.coerceIn(0, 200),
                    scope4x = p.scope4x.coerceIn(0, 200),
                    sniperScope = p.sniperScope.coerceIn(0, 200),
                    freeLook = p.freeLook.coerceIn(0, 200),
                    linkedPackage = p.linkedPackage,
                    updatedAt = System.currentTimeMillis()
                )
            }
            sensitivityDao.upsertAll(entities)
            entities.size
        }
    }

    suspend fun upsertGameProfile(entity: GameProfileEntity) {
        gameDao.upsert(entity)
    }

    suspend fun removeManualGame(packageName: String) {
        gameDao.deleteByPackage(packageName)
    }

    suspend fun setOperatingMode(mode: OperatingMode) = preferences.setOperatingMode(mode)
    suspend fun setPreferredSampleRate(rate: Int) = preferences.setPreferredSampleRate(rate)
    suspend fun setLowLatencyBufferFrames(frames: Int) = preferences.setLowLatencyBufferFrames(frames)
    suspend fun setShowSplashOnStartup(show: Boolean) = preferences.setShowSplashOnStartup(show)
    suspend fun setActivePerformanceMode(mode: PerformanceMode) = preferences.setActivePerformanceMode(mode)
    suspend fun setActiveVoicePresetId(id: String) = preferences.setActiveVoicePresetId(id)
    suspend fun setActiveRefreshRateHz(hz: Int) = preferences.setActiveRefreshRateHz(hz)
    suspend fun setReduceAnimationsInGameMode(enabled: Boolean) = preferences.setReduceAnimationsInGameMode(enabled)

    suspend fun resetAllData() {
        presetDao.deleteAll()
        sensitivityDao.deleteAll()
        gameDao.deleteAll()
        preferences.resetDefaults()
        seedDefaultsIfEmpty()
    }
}
