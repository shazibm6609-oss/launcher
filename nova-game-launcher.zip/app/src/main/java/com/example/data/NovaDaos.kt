package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface CustomVoicePresetDao {
    @Query("SELECT * FROM custom_voice_presets ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<CustomVoicePresetEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: CustomVoicePresetEntity)

    @Query("DELETE FROM custom_voice_presets WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM custom_voice_presets")
    suspend fun deleteAll()
}

@Dao
interface SensitivityProfileDao {
    @Query("SELECT * FROM sensitivity_profiles ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<SensitivityProfileEntity>>

    @Query("SELECT COUNT(*) FROM sensitivity_profiles")
    suspend fun count(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: SensitivityProfileEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(entities: List<SensitivityProfileEntity>)

    @Query("DELETE FROM sensitivity_profiles WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM sensitivity_profiles")
    suspend fun deleteAll()
}

@Dao
interface GameProfileDao {
    @Query("SELECT * FROM game_profiles")
    fun observeAll(): Flow<List<GameProfileEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: GameProfileEntity)

    @Query("DELETE FROM game_profiles WHERE packageName = :packageName")
    suspend fun deleteByPackage(packageName: String)

    @Query("DELETE FROM game_profiles")
    suspend fun deleteAll()
}
