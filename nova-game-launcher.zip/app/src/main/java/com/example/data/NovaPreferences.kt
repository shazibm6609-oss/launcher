package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.OperatingMode
import com.example.model.PerformanceMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.novaDataStore: DataStore<Preferences> by preferencesDataStore(name = "nova_settings")

data class AppSettings(
    val operatingMode: OperatingMode = OperatingMode.AUTO,
    val preferredSampleRate: Int = 48000,
    val lowLatencyBufferFrames: Int = 192,
    val showSplashOnStartup: Boolean = true,
    val activePerformanceMode: PerformanceMode = PerformanceMode.BALANCED,
    val activeVoicePresetId: String = "natural_female",
    val activeRefreshRateHz: Int = 0, // 0 = Auto
    val reduceAnimationsInGameMode: Boolean = true
)

class NovaPreferences(private val context: Context) {
    private object Keys {
        val OPERATING_MODE = stringPreferencesKey("operating_mode")
        val SAMPLE_RATE = intPreferencesKey("sample_rate")
        val BUFFER_FRAMES = intPreferencesKey("buffer_frames")
        val SHOW_SPLASH = booleanPreferencesKey("show_splash")
        val PERF_MODE = stringPreferencesKey("perf_mode")
        val VOICE_PRESET_ID = stringPreferencesKey("voice_preset_id")
        val REFRESH_RATE_HZ = intPreferencesKey("refresh_rate_hz")
        val REDUCE_ANIMATIONS = booleanPreferencesKey("reduce_animations")
    }

    val settingsFlow: Flow<AppSettings> = context.novaDataStore.data.map { prefs ->
        AppSettings(
            operatingMode = prefs[Keys.OPERATING_MODE]?.let { name ->
                OperatingMode.entries.firstOrNull { it.name == name }
            } ?: OperatingMode.AUTO,
            preferredSampleRate = prefs[Keys.SAMPLE_RATE] ?: 48000,
            lowLatencyBufferFrames = prefs[Keys.BUFFER_FRAMES] ?: 192,
            showSplashOnStartup = prefs[Keys.SHOW_SPLASH] ?: true,
            activePerformanceMode = prefs[Keys.PERF_MODE]?.let { name ->
                PerformanceMode.entries.firstOrNull { it.name == name }
            } ?: PerformanceMode.BALANCED,
            activeVoicePresetId = prefs[Keys.VOICE_PRESET_ID] ?: "natural_female",
            activeRefreshRateHz = prefs[Keys.REFRESH_RATE_HZ] ?: 0,
            reduceAnimationsInGameMode = prefs[Keys.REDUCE_ANIMATIONS] ?: true
        )
    }

    suspend fun setOperatingMode(mode: OperatingMode) {
        context.novaDataStore.edit { it[Keys.OPERATING_MODE] = mode.name }
    }

    suspend fun setPreferredSampleRate(rate: Int) {
        context.novaDataStore.edit { it[Keys.SAMPLE_RATE] = rate }
    }

    suspend fun setLowLatencyBufferFrames(frames: Int) {
        context.novaDataStore.edit { it[Keys.BUFFER_FRAMES] = frames }
    }

    suspend fun setShowSplashOnStartup(show: Boolean) {
        context.novaDataStore.edit { it[Keys.SHOW_SPLASH] = show }
    }

    suspend fun setActivePerformanceMode(mode: PerformanceMode) {
        context.novaDataStore.edit { it[Keys.PERF_MODE] = mode.name }
    }

    suspend fun setActiveVoicePresetId(presetId: String) {
        context.novaDataStore.edit { it[Keys.VOICE_PRESET_ID] = presetId }
    }

    suspend fun setActiveRefreshRateHz(hz: Int) {
        context.novaDataStore.edit { it[Keys.REFRESH_RATE_HZ] = hz }
    }

    suspend fun setReduceAnimationsInGameMode(enabled: Boolean) {
        context.novaDataStore.edit { it[Keys.REDUCE_ANIMATIONS] = enabled }
    }

    suspend fun resetDefaults() {
        context.novaDataStore.edit { it.clear() }
    }
}
