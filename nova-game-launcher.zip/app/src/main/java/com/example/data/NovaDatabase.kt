package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        CustomVoicePresetEntity::class,
        SensitivityProfileEntity::class,
        GameProfileEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class NovaDatabase : RoomDatabase() {
    abstract fun customVoicePresetDao(): CustomVoicePresetDao
    abstract fun sensitivityProfileDao(): SensitivityProfileDao
    abstract fun gameProfileDao(): GameProfileDao

    companion object {
        @Volatile
        private var INSTANCE: NovaDatabase? = null

        fun getInstance(context: Context): NovaDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    NovaDatabase::class.java,
                    "nova_launcher.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
