package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "custom_voice_presets")
data class CustomVoicePresetEntity(
    @PrimaryKey val id: String,
    val name: String,
    val category: String,
    val description: String,
    val pitchSemitones: Float,
    val formantShift: Float,
    val brightness: Float,
    val softness: Float,
    val tone: Float,
    val cartoonTone: Float,
    val effectIntensity: Float,
    val noiseReduction: Boolean,
    val eqBassDb: Float,
    val eqMidDb: Float,
    val eqTrebleDb: Float,
    val echoAmount: Float,
    val reverbAmount: Float,
    val inputGain: Float,
    val outputGain: Float,
    val characterMode: Int,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "sensitivity_profiles")
data class SensitivityProfileEntity(
    @PrimaryKey val id: String,
    val name: String,
    val general: Int,
    val redDot: Int,
    val scope2x: Int,
    val scope4x: Int,
    val sniperScope: Int,
    val freeLook: Int,
    val linkedPackage: String?,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "game_profiles")
data class GameProfileEntity(
    @PrimaryKey val packageName: String,
    val isFavorite: Boolean = false,
    val isManuallyAdded: Boolean = false,
    val voicePresetId: String? = null,
    val performanceMode: String = "GAMING",
    val targetRefreshRateHz: Int = 0,
    val sensitivityProfileId: String? = null
)
