package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// AMOLED Obsidian & Neon Esports Palette
val AmoledBlack = Color(0xFF04060A)
val ObsidianSurface = Color(0xFF0B0F17)
val ObsidianCard = Color(0xFF111824)
val ObsidianElevated = Color(0xFF172030)
val ObsidianOutline = Color(0xFF233044)

val NeonCyan = Color(0xFF00E5FF)
val NeonCyanDim = Color(0xFF0091B3)
val ElectricPurple = Color(0xFF9D4EDD)
val ElectricPurpleBright = Color(0xFFC77DFF)
val CyberMagenta = Color(0xFFFF2E93)
val NeonEmerald = Color(0xFF00E676)
val AmberWarning = Color(0xFFFFB300)
val CrimsonDanger = Color(0xFFFF3B5C)

val TextPrimary = Color(0xFFF2F6FF)
val TextSecondary = Color(0xFF9FB0C7)
val TextMuted = Color(0xFF63748C)
