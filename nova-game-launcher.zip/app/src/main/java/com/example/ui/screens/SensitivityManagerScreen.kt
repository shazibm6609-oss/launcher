package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import com.example.model.InstalledGame
import com.example.model.SensitivityProfile
import com.example.ui.NovaViewModel
import com.example.ui.components.NovaGamingCard
import com.example.ui.components.NovaLabeledSlider
import com.example.ui.components.NovaSubScreenTopBar
import com.example.ui.theme.AmoledBlack
import com.example.ui.theme.CrimsonDanger
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun SensitivityManagerScreen(
    viewModel: NovaViewModel,
    profiles: List<SensitivityProfile>,
    games: List<InstalledGame>,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current

    var selectedId by remember { mutableStateOf(profiles.firstOrNull()?.id ?: "") }
    val activeProfile = profiles.firstOrNull { it.id == selectedId } ?: profiles.firstOrNull()

    var draft by remember(activeProfile?.id, activeProfile?.updatedAt) {
        mutableStateOf(activeProfile ?: SensitivityProfile(id = "default", name = "Default Profile"))
    }

    LaunchedEffect(profiles) {
        if (selectedId.isBlank() && profiles.isNotEmpty()) {
            selectedId = profiles.first().id
        }
    }

    var showCreateDialog by remember { mutableStateOf(false) }
    var showRenameDialog by remember { mutableStateOf(false) }
    var showImportJsonDialog by remember { mutableStateOf(false) }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(viewModel.exportSensitivityJson().toByteArray())
                }
                viewModel.showMessage("Exported sensitivity profiles to JSON")
            }.onFailure {
                viewModel.showMessage("Export failed: ${it.message}")
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            runCatching {
                val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                viewModel.importSensitivityJson(text)
            }.onFailure {
                viewModel.showMessage("Import failed: ${it.message}")
            }
        }
    }

    Scaffold(
        containerColor = AmoledBlack,
        topBar = {
            NovaSubScreenTopBar(
                title = "Sensitivity Manager",
                subtitle = "Calibration & Per-Game Reference Profiles",
                onBack = onBack
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Profile Selector Strip
            item {
                NovaGamingCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("SAVED PROFILES", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                        Button(
                            onClick = { showCreateDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = AmoledBlack),
                            modifier = Modifier.testTag("sens_new_profile_button")
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("New")
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(profiles, key = { it.id }) { p ->
                            FilterChip(
                                selected = p.id == draft.id,
                                onClick = {
                                    selectedId = p.id
                                    draft = p
                                },
                                label = { Text(p.name) }
                            )
                        }
                    }
                }
            }

            // Sliders Card
            item {
                NovaGamingCard(accentColor = ElectricPurple) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(draft.name, style = MaterialTheme.typography.titleLarge, color = NeonCyan)
                            Text(
                                text = "Linked: ${games.firstOrNull { it.packageName == draft.linkedPackage }?.label ?: draft.linkedPackage ?: "Universal"}",
                                style = MaterialTheme.typography.labelMedium,
                                color = TextSecondary
                            )
                        }
                        Row {
                            IconButton(onClick = { showRenameDialog = true }) {
                                Icon(Icons.Filled.Edit, contentDescription = "Rename profile", tint = NeonCyan)
                            }
                            if (profiles.size > 1) {
                                IconButton(onClick = { viewModel.deleteSensitivityProfile(draft.id) }) {
                                    Icon(Icons.Filled.Delete, contentDescription = "Delete profile", tint = CrimsonDanger)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    NovaLabeledSlider(
                        label = "General",
                        valueText = "${draft.general}",
                        value = draft.general.toFloat(),
                        valueRange = 0f..200f,
                        onValueChange = { draft = draft.copy(general = it.toInt()) },
                        testTag = "sens_slider_general"
                    )
                    NovaLabeledSlider(
                        label = "Red Dot",
                        valueText = "${draft.redDot}",
                        value = draft.redDot.toFloat(),
                        valueRange = 0f..200f,
                        onValueChange = { draft = draft.copy(redDot = it.toInt()) },
                        accentColor = ElectricPurple
                    )
                    NovaLabeledSlider(
                        label = "2x Scope",
                        valueText = "${draft.scope2x}",
                        value = draft.scope2x.toFloat(),
                        valueRange = 0f..200f,
                        onValueChange = { draft = draft.copy(scope2x = it.toInt()) }
                    )
                    NovaLabeledSlider(
                        label = "4x Scope",
                        valueText = "${draft.scope4x}",
                        value = draft.scope4x.toFloat(),
                        valueRange = 0f..200f,
                        onValueChange = { draft = draft.copy(scope4x = it.toInt()) },
                        accentColor = ElectricPurple
                    )
                    NovaLabeledSlider(
                        label = "Sniper Scope",
                        valueText = "${draft.sniperScope}",
                        value = draft.sniperScope.toFloat(),
                        valueRange = 0f..200f,
                        onValueChange = { draft = draft.copy(sniperScope = it.toInt()) }
                    )
                    NovaLabeledSlider(
                        label = "Free Look",
                        valueText = "${draft.freeLook}",
                        value = draft.freeLook.toFloat(),
                        valueRange = 0f..200f,
                        onValueChange = { draft = draft.copy(freeLook = it.toInt()) },
                        accentColor = ElectricPurple
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = { viewModel.saveSensitivityProfile(draft) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("sens_save_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = NeonEmerald, contentColor = AmoledBlack)
                    ) {
                        Icon(Icons.Filled.Save, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save Profile Changes")
                    }
                }
            }

            // Import / Export JSON
            item {
                NovaGamingCard {
                    Text("IMPORT / EXPORT PROFILES", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Safe configuration storage only — never injects into game memory or modifies game binaries.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { exportLauncher.launch("nova_sensitivity_profiles.json") },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.Upload, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Export File")
                        }
                        OutlinedButton(
                            onClick = { importLauncher.launch(arrayOf("application/json", "text/plain")) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.Download, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Import File")
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                clipboard.setText(AnnotatedString(viewModel.exportSensitivityJson()))
                                viewModel.showMessage("Copied JSON profiles to clipboard")
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.ContentCopy, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Copy JSON")
                        }
                        OutlinedButton(
                            onClick = { showImportJsonDialog = true },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Paste JSON")
                        }
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        var newName by remember { mutableStateOf("") }
        var linkedPkg by remember { mutableStateOf<String?>("com.dts.freefireth") }
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("Create Sensitivity Profile") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        label = { Text("Profile Name") },
                        singleLine = true
                    )
                    Text("Game Link", style = MaterialTheme.typography.labelMedium, color = NeonCyan)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(
                            selected = linkedPkg == "com.dts.freefireth",
                            onClick = { linkedPkg = "com.dts.freefireth" },
                            label = { Text("Free Fire") }
                        )
                        FilterChip(
                            selected = linkedPkg == null,
                            onClick = { linkedPkg = null },
                            label = { Text("Universal") }
                        )
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.createNewSensitivityProfile(newName, linkedPkg)
                    showCreateDialog = false
                }) { Text("Create") }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showRenameDialog) {
        var renamed by remember { mutableStateOf(draft.name) }
        AlertDialog(
            onDismissRequest = { showRenameDialog = false },
            title = { Text("Rename Profile") },
            text = {
                OutlinedTextField(
                    value = renamed,
                    onValueChange = { renamed = it },
                    label = { Text("Profile Name") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(onClick = {
                    val updated = draft.copy(name = renamed.ifBlank { draft.name })
                    draft = updated
                    viewModel.saveSensitivityProfile(updated)
                    showRenameDialog = false
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showRenameDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showImportJsonDialog) {
        var jsonInput by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showImportJsonDialog = false },
            title = { Text("Import Sensitivity JSON") },
            text = {
                OutlinedTextField(
                    value = jsonInput,
                    onValueChange = { jsonInput = it },
                    label = { Text("Paste JSON array") },
                    minLines = 5
                )
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.importSensitivityJson(jsonInput)
                    showImportJsonDialog = false
                }) { Text("Import") }
            },
            dismissButton = {
                TextButton(onClick = { showImportJsonDialog = false }) { Text("Cancel") }
            }
        )
    }
}
