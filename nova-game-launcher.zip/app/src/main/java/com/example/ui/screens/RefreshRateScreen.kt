package com.example.ui.screens

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.model.InstalledGame
import com.example.model.RefreshRateSnapshot
import com.example.ui.NovaViewModel
import com.example.ui.components.NovaGamingCard
import com.example.ui.components.NovaSubScreenTopBar
import com.example.ui.components.StatusPill
import com.example.ui.theme.AmoledBlack
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun RefreshRateScreen(
    viewModel: NovaViewModel,
    snapshot: RefreshRateSnapshot,
    games: List<InstalledGame>,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val activity = LocalContext.current as? Activity
    val targetTiers = listOf(60, 90, 120, 144)

    Scaffold(
        containerColor = AmoledBlack,
        topBar = {
            NovaSubScreenTopBar(
                title = "Refresh Rate Manager",
                subtitle = "Hardware Display Modes & Per-Game Hz",
                onBack = onBack
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                NovaGamingCard(highlighted = true, accentColor = ElectricPurple) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("ACTIVE DISPLAY RATE", style = MaterialTheme.typography.labelMedium, color = ElectricPurple)
                            Text(
                                text = "${snapshot.currentHz.toInt()} Hz",
                                style = MaterialTheme.typography.displayLarge,
                                color = NeonCyan
                            )
                            Text(
                                text = "Measured Choreographer: ${"%.1f".format(snapshot.measuredFps)} FPS",
                                style = MaterialTheme.typography.labelMedium,
                                color = TextSecondary
                            )
                        }
                        StatusPill(
                            label = if (snapshot.isAutoMode) "AUTO MODE" else "MANUAL ${snapshot.selectedTargetHz}Hz",
                            active = true,
                            activeColor = NeonEmerald
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Hardware Supported: ${snapshot.supportedRatesHz.joinToString(" • ") { "${it}Hz" }}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary
                    )
                    Text(
                        text = if (snapshot.canApplySystemWide) {
                            "Privileged Root/Shizuku active — applies both launcher window & system peak_refresh_rate."
                        } else {
                            "Standard mode — applies to Nova window only. Authorize Root or Shizuku for system-wide rate."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }
            }

            item {
                NovaGamingCard {
                    Text("AUTOMATIC / MANUAL SELECTION", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    Spacer(modifier = Modifier.height(10.dp))

                    NovaGamingCard(
                        highlighted = snapshot.isAutoMode,
                        accentColor = NeonCyan,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.applyRefreshRate(activity, 0) }
                            .testTag("hz_mode_auto")
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Automatic (Adaptive)", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                                Text("Lets Android OS scale refresh rate dynamically", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                            }
                            StatusPill(label = if (snapshot.isAutoMode) "ACTIVE" else "SET AUTO", active = snapshot.isAutoMode)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    targetTiers.forEach { hz ->
                        val supported = hz in snapshot.supportedRatesHz
                        val selected = !snapshot.isAutoMode && snapshot.selectedTargetHz == hz
                        NovaGamingCard(
                            highlighted = selected,
                            accentColor = if (supported) NeonCyan else TextMuted,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 8.dp)
                                .clickable(enabled = supported) {
                                    viewModel.applyRefreshRate(activity, hz)
                                }
                                .testTag("hz_tier_$hz")
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "$hz Hz",
                                        style = MaterialTheme.typography.titleLarge,
                                        color = if (supported) TextPrimary else TextMuted
                                    )
                                    Text(
                                        text = if (supported) "Supported by display panel" else "Not reported by device hardware",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = if (supported) TextSecondary else TextMuted
                                    )
                                }
                                StatusPill(
                                    label = when {
                                        selected -> "ACTIVE"
                                        supported -> "APPLY"
                                        else -> "UNSUPPORTED"
                                    },
                                    active = selected,
                                    activeColor = NeonEmerald,
                                    inactiveColor = if (supported) NeonCyan else TextMuted
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedButton(
                        onClick = { viewModel.restoreRefreshRate(activity) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("hz_restore_button")
                    ) {
                        Icon(Icons.Filled.Restore, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Restore Original Refresh Settings")
                    }
                }
            }

            item {
                NovaGamingCard {
                    Text("PER-GAME REFRESH PROFILES", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    Spacer(modifier = Modifier.height(6.dp))
                    val customRateGames = games.filter { it.targetRefreshRateHz > 0 }
                    if (customRateGames.isEmpty()) {
                        Text(
                            text = "No per-game refresh overrides configured yet. Open Game Library -> Profile on any game to assign 60/90/120/144 Hz.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    } else {
                        customRateGames.forEach { g ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(g.label, style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
                                StatusPill(label = "${g.targetRefreshRateHz} Hz", active = true, activeColor = NeonCyan)
                            }
                        }
                    }
                }
            }
        }
    }
}
