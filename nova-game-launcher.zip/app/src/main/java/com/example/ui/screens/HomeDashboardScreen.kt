package com.example.ui.screens

import android.app.Activity
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DisplaySettings
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.AudioRoutingStatus
import com.example.model.DeviceTelemetry
import com.example.model.InstalledGame
import com.example.model.PerformanceMode
import com.example.model.RefreshRateSnapshot
import com.example.model.RootStatus
import com.example.model.ShizukuStatus
import com.example.model.VoiceEngineMetrics
import com.example.model.VoicePreset
import com.example.ui.NovaViewModel
import com.example.ui.components.AppIconImage
import com.example.ui.components.NovaGamingCard
import com.example.ui.components.StatusPill
import com.example.ui.theme.AmoledBlack
import com.example.ui.theme.CyberMagenta
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun HomeDashboardScreen(
    viewModel: NovaViewModel,
    selectedPreset: VoicePreset,
    voiceMetrics: VoiceEngineMetrics,
    routingStatus: AudioRoutingStatus,
    telemetry: DeviceTelemetry,
    refreshSnapshot: RefreshRateSnapshot,
    rootStatus: RootStatus,
    shizukuStatus: ShizukuStatus,
    activePerfMode: PerformanceMode,
    games: List<InstalledGame>,
    onOpenVoiceStudio: () -> Unit,
    onOpenGames: () -> Unit,
    onOpenPerformance: () -> Unit,
    onOpenSensitivity: () -> Unit,
    onOpenRefreshRate: () -> Unit,
    onOpenRoot: () -> Unit,
    onOpenShizuku: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val activity = LocalContext.current as? Activity

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(AmoledBlack),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Hero Header Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(172.dp)
                    .clip(RoundedCornerShape(22.dp))
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_nova_hero_banner),
                    contentDescription = "Nova Command Center Banner",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    AmoledBlack.copy(alpha = 0.25f),
                                    AmoledBlack.copy(alpha = 0.88f)
                                )
                            )
                        )
                        .padding(18.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "NOVA COMMAND",
                                style = MaterialTheme.typography.headlineMedium,
                                color = NeonCyan
                            )
                            IconButtonSurface(
                                icon = Icons.Filled.Settings,
                                contentDescription = "Settings",
                                onClick = onOpenSettings,
                                testTag = "dashboard_settings_button"
                            )
                        }
                        Column {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                StatusPill(
                                    label = if (rootStatus.isAuthorized) "MAGISK ROOT" else if (rootStatus.magiskDetected) "ROOT LOCKED" else "NO ROOT",
                                    active = rootStatus.isAuthorized,
                                    activeColor = NeonEmerald
                                )
                                StatusPill(
                                    label = if (shizukuStatus.isPermissionGranted && shizukuStatus.isBinderAlive) "SHIZUKU OK" else "SHIZUKU",
                                    active = shizukuStatus.isPermissionGranted && shizukuStatus.isBinderAlive,
                                    activeColor = NeonCyan
                                )
                                StatusPill(
                                    label = "${refreshSnapshot.currentHz.toInt()} Hz",
                                    active = true,
                                    activeColor = ElectricPurple
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "${activePerfMode.label} • ${telemetry.deviceTempCelsius}°C • RAM ${telemetry.ramPercent.toInt()}%",
                                style = MaterialTheme.typography.labelMedium,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }
        }

        // Featured Real-Time Voice Changer Quick Card
        item {
            NovaGamingCard(
                highlighted = voiceMetrics.isProcessing,
                accentColor = CyberMagenta
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "REAL-TIME VOICE STUDIO",
                            style = MaterialTheme.typography.labelMedium,
                            color = CyberMagenta
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = selectedPreset.name,
                            style = MaterialTheme.typography.titleLarge,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (voiceMetrics.isProcessing) {
                                "${routingStatus.activeEngine} • ${"%.1f".format(routingStatus.latencyMs)} ms"
                            } else {
                                "Pitch ${"%+.1f".format(selectedPreset.params.pitchSemitones)} st • Formant ${"%.2f".format(selectedPreset.params.formantShift)}x"
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Button(
                        onClick = onOpenVoiceStudio,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (voiceMetrics.isProcessing) CyberMagenta else NeonCyan,
                            contentColor = AmoledBlack
                        ),
                        modifier = Modifier.testTag("dashboard_open_voice_studio")
                    ) {
                        Icon(
                            imageVector = if (voiceMetrics.isProcessing) Icons.Filled.GraphicEq else Icons.Filled.Mic,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (voiceMetrics.isProcessing) "LIVE" else "STUDIO")
                    }
                }
            }
        }

        // Quick Games Strip
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "QUICK LAUNCH GAMES",
                    style = MaterialTheme.typography.labelLarge,
                    color = TextPrimary
                )
                Text(
                    text = "See All (${games.size})",
                    style = MaterialTheme.typography.labelMedium,
                    color = NeonCyan,
                    modifier = Modifier
                        .clickable { onOpenGames() }
                        .padding(8.dp)
                        .testTag("dashboard_see_all_games")
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            if (games.isEmpty()) {
                NovaGamingCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "No games auto-detected yet",
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary
                            )
                            Text(
                                text = "Add Free Fire or any installed app manually in Game Library.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary
                            )
                        }
                        OutlinedButton(onClick = onOpenGames) {
                            Text("Add Game")
                        }
                    }
                }
            } else {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(games.take(8), key = { it.packageName }) { game ->
                        NovaGamingCard(
                            modifier = Modifier
                                .width(154.dp)
                                .clickable { viewModel.launchGameWithProfile(activity, game) }
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                AppIconImage(
                                    drawable = viewModel.loadAppIcon(game.packageName),
                                    contentDescription = game.label,
                                    modifier = Modifier.size(40.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = game.label,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (game.targetRefreshRateHz > 0) "${game.targetRefreshRateHz}Hz" else game.performanceMode.label,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = NeonCyan
                                )
                                Icon(
                                    imageVector = Icons.Filled.PlayArrow,
                                    contentDescription = "Launch ${game.label}",
                                    tint = NeonEmerald,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // System & Gaming Modules Grid
        item {
            Text(
                text = "GAMING MODULES",
                style = MaterialTheme.typography.labelLarge,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(10.dp))
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ModuleTile(
                        title = "Performance",
                        subtitle = "${telemetry.ramUsedMb}/${telemetry.ramTotalMb} MB • ${telemetry.thermalStatusLabel}",
                        icon = Icons.Filled.Speed,
                        accent = NeonEmerald,
                        onClick = onOpenPerformance,
                        modifier = Modifier.weight(1f),
                        testTag = "tile_performance"
                    )
                    ModuleTile(
                        title = "Refresh Rate",
                        subtitle = "Active ${refreshSnapshot.currentHz.toInt()} Hz • ${refreshSnapshot.measuredFps.toInt()} FPS",
                        icon = Icons.Filled.DisplaySettings,
                        accent = ElectricPurple,
                        onClick = onOpenRefreshRate,
                        modifier = Modifier.weight(1f),
                        testTag = "tile_refresh_rate"
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ModuleTile(
                        title = "Sensitivity",
                        subtitle = "Scopes & Free Fire curves",
                        icon = Icons.Filled.Tune,
                        accent = NeonCyan,
                        onClick = onOpenSensitivity,
                        modifier = Modifier.weight(1f),
                        testTag = "tile_sensitivity"
                    )
                    ModuleTile(
                        title = "Game Library",
                        subtitle = "${games.size} installed title(s)",
                        icon = Icons.Filled.SportsEsports,
                        accent = CyberMagenta,
                        onClick = onOpenGames,
                        modifier = Modifier.weight(1f),
                        testTag = "tile_game_library"
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ModuleTile(
                        title = "Magisk Root",
                        subtitle = if (rootStatus.isAuthorized) "Authorized (uid=0)" else rootStatus.magiskVersion,
                        icon = Icons.Filled.Security,
                        accent = NeonEmerald,
                        onClick = onOpenRoot,
                        modifier = Modifier.weight(1f),
                        testTag = "tile_root_manager"
                    )
                    ModuleTile(
                        title = "Shizuku API",
                        subtitle = if (shizukuStatus.isPermissionGranted) "Connected (uid=${shizukuStatus.shizukuUid})" else if (shizukuStatus.isBinderAlive) "Needs Permission" else "Service Offline",
                        icon = Icons.Filled.Terminal,
                        accent = NeonCyan,
                        onClick = onOpenShizuku,
                        modifier = Modifier.weight(1f),
                        testTag = "tile_shizuku_manager"
                    )
                }
            }
        }
    }
}

@Composable
private fun ModuleTile(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accent: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = ""
) {
    NovaGamingCard(
        modifier = modifier
            .clickable(onClick = onClick)
            .testTag(testTag),
        accentColor = accent
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = accent,
            modifier = Modifier.size(26.dp)
        )
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            color = TextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun IconButtonSurface(
    icon: ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    testTag: String
) {
    Surface(
        modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = CircleShape,
        color = ObsidianCard.copy(alpha = 0.8f)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(imageVector = icon, contentDescription = contentDescription, tint = TextPrimary)
        }
    }
}
