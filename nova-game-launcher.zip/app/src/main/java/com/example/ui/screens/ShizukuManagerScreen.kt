package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Launch
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.model.ShizukuStatus
import com.example.ui.NovaViewModel
import com.example.ui.components.NovaGamingCard
import com.example.ui.components.NovaSubScreenTopBar
import com.example.ui.components.StatusPill
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.AmoledBlack
import com.example.ui.theme.CrimsonDanger
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ShizukuManagerScreen(
    viewModel: NovaViewModel,
    shizukuStatus: ShizukuStatus,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    Scaffold(
        containerColor = AmoledBlack,
        topBar = {
            NovaSubScreenTopBar(
                title = "Shizuku Manager",
                subtitle = "Non-Root ADB / Privileged UserService API",
                onBack = onBack
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                NovaGamingCard(
                    highlighted = shizukuStatus.isBinderAlive && shizukuStatus.isPermissionGranted,
                    accentColor = NeonCyan
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("SHIZUKU SERVICE", style = MaterialTheme.typography.labelMedium, color = NeonCyan)
                            Text(
                                text = when {
                                    shizukuStatus.isBinderAlive && shizukuStatus.isPermissionGranted -> "Connected & Authorized"
                                    shizukuStatus.isBinderAlive -> "Service Running (Needs Auth)"
                                    shizukuStatus.isInstalled -> "Installed (Service Stopped)"
                                    else -> "Shizuku Not Installed"
                                },
                                style = MaterialTheme.typography.headlineMedium,
                                color = TextPrimary
                            )
                            Text(
                                text = if (shizukuStatus.isBinderAlive) {
                                    "API v${shizukuStatus.shizukuVersion} • UID ${shizukuStatus.shizukuUid}"
                                } else {
                                    "Start Shizuku via Wireless Debugging or Root to enable ADB-level controls."
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary
                            )
                        }
                        StatusPill(
                            label = if (shizukuStatus.isPermissionGranted && shizukuStatus.isBinderAlive) "READY" else "OFFLINE",
                            active = shizukuStatus.isPermissionGranted && shizukuStatus.isBinderAlive,
                            activeColor = NeonEmerald,
                            inactiveColor = AmberWarning
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { viewModel.requestShizukuPermission() },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("shizuku_authorize_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = AmoledBlack)
                        ) {
                            Icon(Icons.Filled.Terminal, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Authorize")
                        }
                        OutlinedButton(
                            onClick = { viewModel.openShizukuApp() },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.Launch, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Open Shizuku")
                        }
                    }
                }
            }

            if (shizukuStatus.lastError != null) {
                item {
                    NovaGamingCard(accentColor = CrimsonDanger, highlighted = true) {
                        Text("SHIZUKU DIAGNOSTIC", style = MaterialTheme.typography.labelMedium, color = CrimsonDanger)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(shizukuStatus.lastError, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                    }
                }
            }

            item {
                val ready = shizukuStatus.isBinderAlive && shizukuStatus.isPermissionGranted
                NovaGamingCard {
                    Text("SUPPORTED SHIZUKU OPERATIONS", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { viewModel.setShizukuAnimationScale(0.5f) },
                            enabled = ready,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("0.5x Animations")
                        }
                        OutlinedButton(
                            onClick = { viewModel.setShizukuGameMode("com.dts.freefireth", "performance") },
                            enabled = ready,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("FF Game Mode")
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { viewModel.runShizukuTestCommand("id && getprop ro.product.model") },
                            enabled = ready,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Probe Shizuku Shell")
                        }
                        OutlinedButton(
                            onClick = { viewModel.restoreShizukuSettings() },
                            enabled = ready,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("shizuku_restore_button")
                        ) {
                            Icon(Icons.Filled.Restore, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Restore")
                        }
                    }
                }
            }

            if (shizukuStatus.lastCommandOutput.isNotBlank()) {
                item {
                    NovaGamingCard {
                        Text("SHIZUKU CONSOLE OUTPUT", style = MaterialTheme.typography.labelMedium, color = NeonCyan)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = shizukuStatus.lastCommandOutput,
                            style = MaterialTheme.typography.labelMedium,
                            color = TextSecondary
                        )
                    }
                }
            }
        }
    }
}
