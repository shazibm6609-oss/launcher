package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.model.RootStatus
import com.example.ui.NovaViewModel
import com.example.ui.components.NovaGamingCard
import com.example.ui.components.NovaSubScreenTopBar
import com.example.ui.components.StatusPill
import com.example.ui.theme.AmoledBlack
import com.example.ui.theme.CrimsonDanger
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RootManagerScreen(
    viewModel: NovaViewModel,
    rootStatus: RootStatus,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    Scaffold(
        containerColor = AmoledBlack,
        topBar = {
            NovaSubScreenTopBar(
                title = "Magisk Root Manager",
                subtitle = "Superuser Integration & Safe System Controls",
                onBack = onBack
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                NovaGamingCard(
                    highlighted = rootStatus.isAuthorized,
                    accentColor = NeonEmerald
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("MAGISK / SU STATUS", style = MaterialTheme.typography.labelMedium, color = NeonEmerald)
                            Text(
                                text = if (rootStatus.isAuthorized) "Root Authorized" else if (rootStatus.magiskDetected) "Magisk Detected" else "Not Rooted",
                                style = MaterialTheme.typography.headlineMedium,
                                color = TextPrimary
                            )
                            Text(
                                text = "${rootStatus.magiskVersion} • ${rootStatus.uidInfo}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary
                            )
                        }
                        StatusPill(
                            label = if (rootStatus.isAuthorized) "UID=0" else "LOCKED",
                            active = rootStatus.isAuthorized,
                            activeColor = NeonEmerald,
                            inactiveColor = CrimsonDanger
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = { viewModel.detectAndRequestRoot() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("root_request_su_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = NeonEmerald, contentColor = AmoledBlack)
                    ) {
                        Icon(Icons.Filled.Security, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (rootStatus.isAuthorized) "Re-verify Superuser" else "Detect & Request Superuser")
                    }
                }
            }

            if (rootStatus.lastError != null) {
                item {
                    NovaGamingCard(accentColor = CrimsonDanger, highlighted = true) {
                        Text("ROOT ERROR / DIAGNOSTICS", style = MaterialTheme.typography.labelMedium, color = CrimsonDanger)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(rootStatus.lastError, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                    }
                }
            }

            item {
                NovaGamingCard {
                    Text("AUTHORIZED ROOT OPERATIONS", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Applies only supported system settings (CPU scaling governor, refresh rate settings, animation scales). SELinux & thermal throttling protections are strictly preserved.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Active CPU Governor: ${rootStatus.currentGovernor}", style = MaterialTheme.typography.labelMedium, color = NeonCyan)
                    if (rootStatus.originalGovernorBackup != null) {
                        Text("Original Backup: ${rootStatus.originalGovernorBackup}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    Spacer(modifier = Modifier.height(8.dp))

                    if (rootStatus.availableGovernors.isEmpty()) {
                        Text(
                            text = if (rootStatus.isAuthorized) "No writable cpufreq governors exposed by kernel." else "Authorize Superuser to inspect & switch CPU governors.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    } else {
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            rootStatus.availableGovernors.forEach { gov ->
                                FilterChip(
                                    selected = gov == rootStatus.currentGovernor,
                                    onClick = { viewModel.setRootCpuGovernor(gov) },
                                    label = { Text(gov) }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedButton(
                        onClick = { viewModel.restoreRootSettings() },
                        enabled = rootStatus.isAuthorized,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("root_restore_button")
                    ) {
                        Icon(Icons.Filled.Restore, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Restore Original Root Settings")
                    }
                }
            }

            if (rootStatus.lastCommandOutput.isNotBlank()) {
                item {
                    NovaGamingCard {
                        Text("LAST SHELL OUTPUT", style = MaterialTheme.typography.labelMedium, color = NeonCyan)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = rootStatus.lastCommandOutput,
                            style = MaterialTheme.typography.labelMedium,
                            color = TextSecondary
                        )
                    }
                }
            }
        }
    }
}
