package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.AppSettings
import com.example.model.OperatingMode
import com.example.ui.NovaViewModel
import com.example.ui.components.NovaGamingCard
import com.example.ui.components.NovaSubScreenTopBar
import com.example.ui.theme.AmoledBlack
import com.example.ui.theme.CrimsonDanger
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun SettingsScreen(
    viewModel: NovaViewModel,
    settings: AppSettings,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    Scaffold(
        containerColor = AmoledBlack,
        topBar = {
            NovaSubScreenTopBar(
                title = "Settings",
                subtitle = "Operating Mode, Low-Latency Audio & Data",
                onBack = onBack
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                NovaGamingCard {
                    Text("PRIVILEGE OPERATING MODE", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    Spacer(modifier = Modifier.height(6.dp))
                    OperatingMode.entries.forEach { mode ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.setOperatingMode(mode) }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = settings.operatingMode == mode,
                                onClick = { viewModel.setOperatingMode(mode) }
                            )
                            Text(mode.label, style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
                        }
                    }
                }
            }

            item {
                NovaGamingCard {
                    Text("VOICE DSP ENGINE TUNING", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Preferred Sample Rate", style = MaterialTheme.typography.labelMedium, color = NeonCyan)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(44100, 48000).forEach { sr ->
                            FilterChip(
                                selected = settings.preferredSampleRate == sr,
                                onClick = { viewModel.setPreferredSampleRate(sr) },
                                label = { Text("${sr / 1000} kHz") }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Low-Latency Frames Per Burst", style = MaterialTheme.typography.labelMedium, color = NeonCyan)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(128, 192, 256, 384).forEach { fpb ->
                            FilterChip(
                                selected = settings.lowLatencyBufferFrames == fpb,
                                onClick = { viewModel.setLowLatencyBufferFrames(fpb) },
                                label = { Text("$fpb") }
                            )
                        }
                    }
                }
            }

            item {
                NovaGamingCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Show Splash Screen on Startup", style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
                            Text("Animated launch sequence while probing Root & Shizuku", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                        }
                        Switch(
                            checked = settings.showSplashOnStartup,
                            onCheckedChange = { viewModel.setShowSplashOnStartup(it) }
                        )
                    }
                }
            }

            item {
                NovaGamingCard {
                    Text("ANDROID AUDIO ROUTING FACTS", style = MaterialTheme.typography.titleMedium, color = NeonCyan)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Nova processes live microphone audio in real time using Google Oboe (AAudio/OpenSL ES) and phase-aligned pitch + vocal formant DSP. Because Android 10–16 isolates microphone streams between apps, external games such as Free Fire cannot capture another app's output directly without an external USB/TRRS hardware mixer or a kernel ALSA loopback module on rooted devices.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }
            }

            item {
                Button(
                    onClick = { viewModel.resetAllAppData() },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonDanger, contentColor = TextPrimary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("settings_reset_all_button")
                ) {
                    Text("Reset All Custom Presets, Profiles & Settings")
                }
            }
        }
    }
}
