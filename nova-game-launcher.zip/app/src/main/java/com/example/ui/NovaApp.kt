package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.screens.GameLibraryScreen
import com.example.ui.screens.GamingPerformanceScreen
import com.example.ui.screens.HomeDashboardScreen
import com.example.ui.screens.RefreshRateScreen
import com.example.ui.screens.RootManagerScreen
import com.example.ui.screens.SensitivityManagerScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.ShizukuManagerScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.VoiceStudioScreen
import com.example.ui.theme.AmoledBlack
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianElevated
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.serialization.Serializable

@Serializable object SplashRoute
@Serializable object DashboardRoute
@Serializable object GamesRoute
@Serializable object VoiceStudioRoute
@Serializable object PerformanceRoute
@Serializable object SensitivityRoute
@Serializable object RefreshRateRoute
@Serializable object RootRoute
@Serializable object ShizukuRoute
@Serializable object SettingsRoute

private data class BottomTab(
    val route: Any,
    val label: String,
    val icon: ImageVector,
    val testTag: String
)

private val primaryTabs = listOf(
    BottomTab(DashboardRoute, "Home", Icons.Filled.Dashboard, "nav_home"),
    BottomTab(GamesRoute, "Games", Icons.Filled.SportsEsports, "nav_games"),
    BottomTab(VoiceStudioRoute, "Voice", Icons.Filled.GraphicEq, "nav_voice"),
    BottomTab(PerformanceRoute, "Perf", Icons.Filled.Speed, "nav_performance"),
    BottomTab(SensitivityRoute, "Sens", Icons.Filled.Tune, "nav_sensitivity")
)

@Composable
fun NovaApp(viewModel: NovaViewModel) {
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }

    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val allPresets by viewModel.allVoicePresets.collectAsStateWithLifecycle()
    val selectedPreset by viewModel.selectedPreset.collectAsStateWithLifecycle()
    val voiceParams by viewModel.voiceParams.collectAsStateWithLifecycle()
    val effectEnabled by viewModel.effectEnabled.collectAsStateWithLifecycle()
    val originalPreview by viewModel.originalPreview.collectAsStateWithLifecycle()
    val voiceMetrics by viewModel.voiceMetrics.collectAsStateWithLifecycle()
    val routingStatus by viewModel.audioRoutingStatus.collectAsStateWithLifecycle()
    val inputDevices by viewModel.inputDevices.collectAsStateWithLifecycle()
    val outputDevices by viewModel.outputDevices.collectAsStateWithLifecycle()
    val installedGames by viewModel.installedGames.collectAsStateWithLifecycle()
    val allLauncherApps by viewModel.allLauncherApps.collectAsStateWithLifecycle()
    val sensitivityProfiles by viewModel.sensitivityProfiles.collectAsStateWithLifecycle()
    val telemetry by viewModel.telemetry.collectAsStateWithLifecycle()
    val refreshSnapshot by viewModel.refreshRateSnapshot.collectAsStateWithLifecycle()
    val rootStatus by viewModel.rootStatus.collectAsStateWithLifecycle()
    val shizukuStatus by viewModel.shizukuStatus.collectAsStateWithLifecycle()
    val statusToast by viewModel.statusToast.collectAsStateWithLifecycle()
    val gamingVoiceTarget by viewModel.gamingVoiceGameTarget.collectAsStateWithLifecycle()

    LaunchedEffect(statusToast) {
        val msg = statusToast
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusToast()
        }
    }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDest = navBackStackEntry?.destination
    val showTopLevelNav = currentDest != null && (
        currentDest.hasRoute<DashboardRoute>() ||
            currentDest.hasRoute<GamesRoute>() ||
            currentDest.hasRoute<VoiceStudioRoute>() ||
            currentDest.hasRoute<PerformanceRoute>()
        )

    fun navigateTopTab(route: Any) {
        navController.navigate(route) {
            popUpTo<DashboardRoute> { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(AmoledBlack)
    ) {
        val useRail = maxWidth >= 700.dp

        Scaffold(
            containerColor = AmoledBlack,
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            bottomBar = {
                if (showTopLevelNav && !useRail) {
                    NavigationBar(containerColor = ObsidianSurface) {
                        primaryTabs.forEach { tab ->
                            val selected = currentDest?.let { dest ->
                                when (tab.route) {
                                    is DashboardRoute -> dest.hasRoute<DashboardRoute>()
                                    is GamesRoute -> dest.hasRoute<GamesRoute>()
                                    is VoiceStudioRoute -> dest.hasRoute<VoiceStudioRoute>()
                                    is PerformanceRoute -> dest.hasRoute<PerformanceRoute>()
                                    is SensitivityRoute -> dest.hasRoute<SensitivityRoute>()
                                    else -> false
                                }
                            } == true
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateTopTab(tab.route) },
                                icon = { Icon(tab.icon, contentDescription = tab.label) },
                                label = { Text(tab.label) },
                                modifier = Modifier.testTag(tab.testTag),
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = NeonCyan,
                                    selectedTextColor = NeonCyan,
                                    indicatorColor = ObsidianElevated,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                )
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (showTopLevelNav && useRail) {
                    NavigationRail(containerColor = ObsidianSurface) {
                        primaryTabs.forEach { tab ->
                            val selected = currentDest?.let { dest ->
                                when (tab.route) {
                                    is DashboardRoute -> dest.hasRoute<DashboardRoute>()
                                    is GamesRoute -> dest.hasRoute<GamesRoute>()
                                    is VoiceStudioRoute -> dest.hasRoute<VoiceStudioRoute>()
                                    is PerformanceRoute -> dest.hasRoute<PerformanceRoute>()
                                    is SensitivityRoute -> dest.hasRoute<SensitivityRoute>()
                                    else -> false
                                }
                            } == true
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTopTab(tab.route) },
                                icon = { Icon(tab.icon, contentDescription = tab.label) },
                                label = { Text(tab.label) },
                                modifier = Modifier.testTag(tab.testTag),
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = NeonCyan,
                                    selectedTextColor = NeonCyan,
                                    indicatorColor = ObsidianElevated,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextPrimary
                                )
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f)) {
                    NavHost(
                        navController = navController,
                        startDestination = if (settings.showSplashOnStartup) SplashRoute else DashboardRoute
                    ) {
                        composable<SplashRoute> {
                            SplashScreen(
                                onFinished = {
                                    navController.navigate(DashboardRoute) {
                                        popUpTo<SplashRoute> { inclusive = true }
                                    }
                                }
                            )
                        }
                        composable<DashboardRoute> {
                            HomeDashboardScreen(
                                viewModel = viewModel,
                                selectedPreset = selectedPreset,
                                voiceMetrics = voiceMetrics,
                                routingStatus = routingStatus,
                                telemetry = telemetry,
                                refreshSnapshot = refreshSnapshot,
                                rootStatus = rootStatus,
                                shizukuStatus = shizukuStatus,
                                activePerfMode = settings.activePerformanceMode,
                                games = installedGames,
                                onOpenVoiceStudio = { navigateTopTab(VoiceStudioRoute) },
                                onOpenGames = { navigateTopTab(GamesRoute) },
                                onOpenPerformance = { navigateTopTab(PerformanceRoute) },
                                onOpenSensitivity = { navController.navigate(SensitivityRoute) },
                                onOpenRefreshRate = { navController.navigate(RefreshRateRoute) },
                                onOpenRoot = { navController.navigate(RootRoute) },
                                onOpenShizuku = { navController.navigate(ShizukuRoute) },
                                onOpenSettings = { navController.navigate(SettingsRoute) }
                            )
                        }
                        composable<GamesRoute> {
                            GameLibraryScreen(
                                viewModel = viewModel,
                                games = installedGames,
                                allLauncherApps = allLauncherApps,
                                voicePresets = allPresets,
                                sensitivityProfiles = sensitivityProfiles,
                                supportedRatesHz = refreshSnapshot.supportedRatesHz
                            )
                        }
                        composable<VoiceStudioRoute> {
                            VoiceStudioScreen(
                                viewModel = viewModel,
                                allPresets = allPresets,
                                selectedPreset = selectedPreset,
                                params = voiceParams,
                                effectEnabled = effectEnabled,
                                originalPreview = originalPreview,
                                metrics = voiceMetrics,
                                routingStatus = routingStatus,
                                inputDevices = inputDevices,
                                outputDevices = outputDevices,
                                games = installedGames,
                                gamingVoiceTarget = gamingVoiceTarget
                            )
                        }
                        composable<PerformanceRoute> {
                            GamingPerformanceScreen(
                                viewModel = viewModel,
                                telemetry = telemetry,
                                settings = settings
                            )
                        }
                        composable<SensitivityRoute> {
                            SensitivityManagerScreen(
                                viewModel = viewModel,
                                profiles = sensitivityProfiles,
                                games = installedGames,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable<RefreshRateRoute> {
                            RefreshRateScreen(
                                viewModel = viewModel,
                                snapshot = refreshSnapshot,
                                games = installedGames,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable<RootRoute> {
                            RootManagerScreen(
                                viewModel = viewModel,
                                rootStatus = rootStatus,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable<ShizukuRoute> {
                            ShizukuManagerScreen(
                                viewModel = viewModel,
                                shizukuStatus = shizukuStatus,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable<SettingsRoute> {
                            SettingsScreen(
                                viewModel = viewModel,
                                settings = settings,
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}
