package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.AppSettings
import com.example.model.DeviceTelemetry
import com.example.model.PerformanceMode
import com.example.ui.NovaViewModel
import com.example.ui.components.NovaGamingCard
import com.example.ui.components.StatusPill
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.AmoledBlack
import com.example.ui.theme.CrimsonDanger
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.ObsidianOutline
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun GamingPerformanceScreen(
    viewModel: NovaViewModel,
    telemetry: DeviceTelemetry,
    settings: AppSettings
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(AmoledBlack),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("GAMING PERFORMANCE", style = MaterialTheme.typography.headlineMedium, color = NeonCyan)
            Text(
                text = "Live hardware telemetry & supported system performance tuning",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
        }

        // Performance Modes
        item {
            NovaGamingCard(accentColor = ElectricPurple) {
                Text("PERFORMANCE MODE", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                Spacer(modifier = Modifier.height(10.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    PerformanceMode.entries.forEach { mode ->
                        val active = settings.activePerformanceMode == mode
                        NovaGamingCard(
                            highlighted = active,
                            accentColor = NeonCyan,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.applyPerformanceMode(mode) }
                                .testTag("perf_mode_${mode.name}")
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(mode.label, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                                    Text(mode.description, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                                }
                                StatusPill(
                                    label = if (active) "ACTIVE" else "SELECT",
                                    active = active,
                                    activeColor = NeonEmerald
                                )
                            }
                        }
                    }
                }
            }
        }

        // Real-time Telemetry Grid
        item {
            NovaGamingCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("LIVE SYSTEM TELEMETRY", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    StatusPill(
                        label = telemetry.thermalStatusLabel,
                        active = !telemetry.isThermalThrottling,
                        activeColor = NeonEmerald,
                        inactiveColor = CrimsonDanger
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))

                // RAM Bar
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Memory (RAM)", style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                    Text(
                        "${telemetry.ramUsedMb} / ${telemetry.ramTotalMb} MB (${telemetry.ramPercent.toInt()}%)",
                        style = MaterialTheme.typography.labelMedium,
                        color = NeonCyan
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { (telemetry.ramPercent / 100f).coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = NeonCyan,
                    trackColor = ObsidianOutline
                )

                Spacer(modifier = Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TelemetryStatBox(
                        label = "Device Temp",
                        value = "${telemetry.deviceTempCelsius}°C",
                        accent = if (telemetry.deviceTempCelsius >= 42f) AmberWarning else NeonEmerald,
                        modifier = Modifier.weight(1f)
                    )
                    TelemetryStatBox(
                        label = "Battery",
                        value = "${telemetry.batteryLevel}%${if (telemetry.batteryCharging) " ⚡" else ""}",
                        accent = NeonCyan,
                        modifier = Modifier.weight(1f)
                    )
                    TelemetryStatBox(
                        label = "UI FPS",
                        value = "${telemetry.currentFps.toInt()} FPS",
                        accent = ElectricPurple,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = "CPU Governor: ${telemetry.cpuGovernor}",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary
                )
                Text(
                    text = if (telemetry.cpuUsagePercent != null) {
                        "CPU Load: ${"%.1f".format(telemetry.cpuUsagePercent)}%"
                    } else {
                        "CPU Load: /proc/stat restricted by SELinux on Android 8+ (core clocks shown below)"
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )

                if (telemetry.cpuFrequenciesMhz.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        telemetry.cpuFrequenciesMhz.forEachIndexed { idx, mhz ->
                            StatusPill(
                                label = "CPU$idx: $mhz MHz",
                                active = true,
                                activeColor = NeonCyan
                            )
                        }
                    }
                }
            }
        }

        // Custom Performance Toggle
        item {
            NovaGamingCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Reduce Window Animations in Gaming Mode", style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
                        Text("Sets 0.5x transition scale when Root or Shizuku is authorized", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                    }
                    Switch(
                        checked = settings.reduceAnimationsInGameMode,
                        onCheckedChange = { viewModel.setReduceAnimationsInGameMode(it) }
                    )
                }
            }
        }
    }
}

@Composable
private fun TelemetryStatBox(
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(AmoledBlack)
            .padding(12.dp)
    ) {
        Column {
            Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, style = MaterialTheme.typography.titleMedium, color = accent)
        }
    }
}
