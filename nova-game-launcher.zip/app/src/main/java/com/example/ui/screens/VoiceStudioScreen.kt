package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.HeadsetMic
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.model.AudioDeviceEntry
import com.example.model.AudioRoutingStatus
import com.example.model.BuiltInVoicePresets
import com.example.model.CharacterMode
import com.example.model.InstalledGame
import com.example.model.VoiceCategory
import com.example.model.VoiceEngineMetrics
import com.example.model.VoiceParameters
import com.example.model.VoicePreset
import com.example.ui.NovaViewModel
import com.example.ui.components.LiveWaveformVisualizer
import com.example.ui.components.NovaGamingCard
import com.example.ui.components.NovaLabeledSlider
import com.example.ui.components.StatusPill
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.AmoledBlack
import com.example.ui.theme.CrimsonDanger
import com.example.ui.theme.CyberMagenta
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.ObsidianElevated
import com.example.ui.theme.ObsidianOutline
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VoiceStudioScreen(
    viewModel: NovaViewModel,
    allPresets: List<VoicePreset>,
    selectedPreset: VoicePreset,
    params: VoiceParameters,
    effectEnabled: Boolean,
    originalPreview: Boolean,
    metrics: VoiceEngineMetrics,
    routingStatus: AudioRoutingStatus,
    inputDevices: List<AudioDeviceEntry>,
    outputDevices: List<AudioDeviceEntry>,
    games: List<InstalledGame>,
    gamingVoiceTarget: String?
) {
    val context = LocalContext.current
    var micGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        )
    }

    var pendingActionAfterMic by remember { mutableStateOf<(() -> Unit)?>(null) }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val audioOk = results[Manifest.permission.RECORD_AUDIO] == true ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        micGranted = audioOk
        if (audioOk) {
            pendingActionAfterMic?.invoke()
        } else {
            viewModel.showMessage("Microphone permission is required for live real-time voice processing.")
        }
        pendingActionAfterMic = null
    }

    fun requireMicAndRun(action: () -> Unit) {
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            action()
        } else {
            pendingActionAfterMic = action
            micPermissionLauncher.launch(perms.toTypedArray())
        }
    }

    var showAdvancedDsp by remember { mutableStateOf(false) }
    var showSaveDialog by remember { mutableStateOf(false) }
    var selectedInputId by remember { mutableStateOf(0) }
    var selectedOutputId by remember { mutableStateOf(0) }

    val pulse by rememberInfiniteTransition(label = "micPulse").animateFloat(
        initialValue = 1.0f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "micScale"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(AmoledBlack),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header + Live Mic Control
        item {
            NovaGamingCard(
                highlighted = metrics.isProcessing,
                accentColor = if (metrics.isProcessing) CyberMagenta else NeonCyan
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "VOICE STUDIO DSP",
                            style = MaterialTheme.typography.headlineMedium,
                            color = NeonCyan
                        )
                        Text(
                            text = "${routingStatus.activeEngine} • ${routingStatus.sampleRateHz / 1000} kHz",
                            style = MaterialTheme.typography.labelMedium,
                            color = TextSecondary
                        )
                    }
                    StatusPill(
                        label = if (metrics.isProcessing) "${"%.1f".format(routingStatus.latencyMs)} ms" else "STANDBY",
                        active = metrics.isProcessing,
                        activeColor = NeonEmerald
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Large Microphone Button + Effect / Original Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .size(92.dp)
                                .scale(if (metrics.isProcessing) pulse else 1f)
                                .clip(CircleShape)
                                .background(
                                    if (metrics.isProcessing) {
                                        Brush.radialGradient(listOf(CyberMagenta, ElectricPurple))
                                    } else {
                                        Brush.radialGradient(listOf(NeonCyan, ElectricPurple))
                                    }
                                )
                                .clickable {
                                    requireMicAndRun { viewModel.toggleLiveMicrophone() }
                                }
                                .testTag("voice_live_mic_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (metrics.isProcessing) Icons.Filled.Mic else Icons.Filled.MicOff,
                                contentDescription = if (metrics.isProcessing) "Stop live microphone" else "Start live microphone",
                                tint = AmoledBlack,
                                modifier = Modifier.size(40.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (metrics.isProcessing) "LIVE ON — TAP TO STOP" else "TAP FOR LIVE MIC",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (metrics.isProcessing) CyberMagenta else NeonCyan
                        )
                    }

                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        horizontalAlignment = Alignment.End
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Effect ON", style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Switch(
                                checked = effectEnabled,
                                onCheckedChange = { viewModel.setEffectEnabled(it) },
                                modifier = Modifier.testTag("voice_effect_switch"),
                                colors = SwitchDefaults.colors(checkedTrackColor = NeonCyan)
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Original Preview", style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Switch(
                                checked = originalPreview,
                                onCheckedChange = { viewModel.setOriginalPreview(it) },
                                modifier = Modifier.testTag("voice_original_preview_switch"),
                                colors = SwitchDefaults.colors(checkedTrackColor = AmberWarning)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                LiveWaveformVisualizer(
                    waveform = metrics.waveform,
                    inputDb = metrics.inputDb,
                    outputDb = metrics.outputDb,
                    isActive = metrics.isProcessing || metrics.isRecordingSample || metrics.isPlayingRecordedPreview,
                    accentColor = if (originalPreview || !effectEnabled) AmberWarning else NeonCyan
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Sample Record + Instant A/B Original vs Processed Voice Preview
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { requireMicAndRun { viewModel.toggleSampleRecording() } },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("voice_record_sample_button"),
                        border = BorderStroke(1.dp, if (metrics.isRecordingSample) CrimsonDanger else NeonCyan)
                    ) {
                        Icon(
                            imageVector = if (metrics.isRecordingSample) Icons.Filled.Stop else Icons.Filled.FiberManualRecord,
                            contentDescription = null,
                            tint = if (metrics.isRecordingSample) CrimsonDanger else NeonCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (metrics.isRecordingSample) {
                                "Stop (${"%.1f".format(metrics.recordedDurationSec)}s)"
                            } else {
                                "Rec Mic"
                            },
                            maxLines = 1
                        )
                    }

                    OutlinedButton(
                        onClick = {
                            if (metrics.isPlayingRecordedPreview) viewModel.stopRecordedPreview()
                            else viewModel.playRecordedPreview(original = false)
                        },
                        enabled = metrics.hasRecordedSample,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("voice_preview_processed_button")
                    ) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Processed", maxLines = 1)
                    }

                    OutlinedButton(
                        onClick = { viewModel.playRecordedPreview(original = true) },
                        enabled = metrics.hasRecordedSample,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("voice_preview_original_button")
                    ) {
                        Text("Original", maxLines = 1)
                    }
                }
            }
        }

        // Voice Presets (All 12 + Custom + Female/Baby Sub-presets)
        item {
            NovaGamingCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "VOICE PRESETS",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                        Text(
                            text = "Selected: ${selectedPreset.name}",
                            style = MaterialTheme.typography.labelMedium,
                            color = NeonCyan
                        )
                    }
                    Row {
                        IconButton(
                            onClick = { viewModel.resetVoiceParameters() },
                            modifier = Modifier.testTag("voice_reset_button")
                        ) {
                            Icon(Icons.Filled.RestartAlt, contentDescription = "Reset sliders", tint = TextSecondary)
                        }
                        IconButton(
                            onClick = { showSaveDialog = true },
                            modifier = Modifier.testTag("voice_save_preset_button")
                        ) {
                            Icon(Icons.Filled.BookmarkAdd, contentDescription = "Save custom preset", tint = NeonCyan)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = selectedPreset.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.height(10.dp))

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    allPresets.forEach { preset ->
                        val isSelected = preset.id == selectedPreset.id
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.selectVoicePreset(preset) },
                            label = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(preset.name)
                                    if (!preset.isBuiltIn) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(
                                            imageVector = Icons.Filled.Delete,
                                            contentDescription = "Delete ${preset.name}",
                                            modifier = Modifier
                                                .size(14.dp)
                                                .clickable { viewModel.deleteCustomVoicePreset(preset.id) }
                                        )
                                    }
                                }
                            },
                            modifier = Modifier.testTag("preset_chip_${preset.id}"),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = NeonCyan.copy(alpha = 0.22f),
                                selectedLabelColor = NeonCyan
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "FEMALE & BABY SPECIALTY TUNINGS",
                    style = MaterialTheme.typography.labelSmall,
                    color = ElectricPurple
                )
                Spacer(modifier = Modifier.height(6.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(BuiltInVoicePresets.FEMALE_SUB_PRESETS + BuiltInVoicePresets.BABY_SUB_PRESETS) { sub ->
                        FilterChip(
                            selected = sub.id == selectedPreset.id,
                            onClick = { viewModel.selectVoicePreset(sub) },
                            label = { Text(sub.name) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ElectricPurple.copy(alpha = 0.25f),
                                selectedLabelColor = ElectricPurple
                            )
                        )
                    }
                }
            }
        }

        // Core Female & Baby Vocal Sculpting Controls
        item {
            NovaGamingCard(accentColor = ElectricPurple) {
                Text(
                    text = "VOCAL FORMANT & PITCH CONTROLS",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(10.dp))

                NovaLabeledSlider(
                    label = "Pitch Shift",
                    valueText = "${"%+.1f".format(params.pitchSemitones)} semitones",
                    value = params.pitchSemitones,
                    valueRange = -12f..12f,
                    onValueChange = { v -> viewModel.updateVoiceParams { it.copy(pitchSemitones = v) } },
                    accentColor = NeonCyan,
                    testTag = "slider_pitch"
                )
                NovaLabeledSlider(
                    label = "Formant Shift (Vocal Tract)",
                    valueText = "${"%.2f".format(params.formantShift)}x",
                    value = params.formantShift,
                    valueRange = 0.65f..1.45f,
                    onValueChange = { v -> viewModel.updateVoiceParams { it.copy(formantShift = v) } },
                    accentColor = ElectricPurple,
                    testTag = "slider_formant"
                )
                NovaLabeledSlider(
                    label = "Effect Intensity (Wet Mix)",
                    valueText = "${(params.effectIntensity * 100).toInt()}%",
                    value = params.effectIntensity,
                    valueRange = 0f..1f,
                    onValueChange = { v -> viewModel.updateVoiceParams { it.copy(effectIntensity = v) } },
                    accentColor = CyberMagenta,
                    testTag = "slider_intensity"
                )
                NovaLabeledSlider(
                    label = "Voice Brightness",
                    valueText = "${"%+.0f".format(params.brightness * 100)}%",
                    value = params.brightness,
                    valueRange = -1f..1f,
                    onValueChange = { v -> viewModel.updateVoiceParams { it.copy(brightness = v) } }
                )
                NovaLabeledSlider(
                    label = "Voice Softness (Female Silk)",
                    valueText = "${(params.softness * 100).toInt()}%",
                    value = params.softness,
                    valueRange = 0f..1f,
                    onValueChange = { v -> viewModel.updateVoiceParams { it.copy(softness = v) } },
                    accentColor = ElectricPurple
                )
                NovaLabeledSlider(
                    label = "Tone Adjustment",
                    valueText = "${"%+.0f".format(params.tone * 100)}%",
                    value = params.tone,
                    valueRange = -1f..1f,
                    onValueChange = { v -> viewModel.updateVoiceParams { it.copy(tone = v) } }
                )
                NovaLabeledSlider(
                    label = "Cartoon Tone (Baby / Toon Resonance)",
                    valueText = "${(params.cartoonTone * 100).toInt()}%",
                    value = params.cartoonTone,
                    valueRange = 0f..1f,
                    onValueChange = { v -> viewModel.updateVoiceParams { it.copy(cartoonTone = v) } },
                    accentColor = CyberMagenta
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Adaptive Noise Reduction", style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
                        Text("Smooth background gate & fan suppression", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                    }
                    Switch(
                        checked = params.noiseReduction,
                        onCheckedChange = { nr -> viewModel.updateVoiceParams { it.copy(noiseReduction = nr) } },
                        modifier = Modifier.testTag("switch_noise_reduction"),
                        colors = SwitchDefaults.colors(checkedTrackColor = NeonEmerald)
                    )
                }
            }
        }

        // Expandable Studio EQ, Echo, Reverb & Gain
        item {
            NovaGamingCard {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showAdvancedDsp = !showAdvancedDsp }
                        .testTag("toggle_advanced_dsp"),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "EQUALIZER, ECHO, REVERB & GAIN",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary
                    )
                    Icon(
                        imageVector = if (showAdvancedDsp) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                        contentDescription = "Toggle advanced DSP",
                        tint = NeonCyan
                    )
                }

                AnimatedVisibility(visible = showAdvancedDsp) {
                    Column(modifier = Modifier.padding(top = 12.dp)) {
                        NovaLabeledSlider(
                            label = "Input Mic Volume",
                            valueText = "${(params.inputGain * 100).toInt()}%",
                            value = params.inputGain,
                            valueRange = 0.2f..2.5f,
                            onValueChange = { v -> viewModel.updateVoiceParams { it.copy(inputGain = v) } }
                        )
                        NovaLabeledSlider(
                            label = "Output Volume",
                            valueText = "${(params.outputGain * 100).toInt()}%",
                            value = params.outputGain,
                            valueRange = 0.2f..2.5f,
                            onValueChange = { v -> viewModel.updateVoiceParams { it.copy(outputGain = v) } }
                        )
                        NovaLabeledSlider(
                            label = "EQ Bass (120 Hz)",
                            valueText = "${"%+.1f".format(params.eqBassDb)} dB",
                            value = params.eqBassDb,
                            valueRange = -12f..12f,
                            onValueChange = { v -> viewModel.updateVoiceParams { it.copy(eqBassDb = v) } }
                        )
                        NovaLabeledSlider(
                            label = "EQ Mid (1.2 kHz)",
                            valueText = "${"%+.1f".format(params.eqMidDb)} dB",
                            value = params.eqMidDb,
                            valueRange = -12f..12f,
                            onValueChange = { v -> viewModel.updateVoiceParams { it.copy(eqMidDb = v) } }
                        )
                        NovaLabeledSlider(
                            label = "EQ Treble (5.4 kHz)",
                            valueText = "${"%+.1f".format(params.eqTrebleDb)} dB",
                            value = params.eqTrebleDb,
                            valueRange = -12f..12f,
                            onValueChange = { v -> viewModel.updateVoiceParams { it.copy(eqTrebleDb = v) } }
                        )
                        NovaLabeledSlider(
                            label = "Echo Delay",
                            valueText = "${(params.echoAmount * 100).toInt()}%",
                            value = params.echoAmount,
                            valueRange = 0f..1f,
                            onValueChange = { v -> viewModel.updateVoiceParams { it.copy(echoAmount = v) } },
                            accentColor = ElectricPurple
                        )
                        NovaLabeledSlider(
                            label = "Room Reverb",
                            valueText = "${(params.reverbAmount * 100).toInt()}%",
                            value = params.reverbAmount,
                            valueRange = 0f..1f,
                            onValueChange = { v -> viewModel.updateVoiceParams { it.copy(reverbAmount = v) } },
                            accentColor = ElectricPurple
                        )

                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Character Modulator", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                        Spacer(modifier = Modifier.height(6.dp))
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            CharacterMode.entries.forEach { mode ->
                                FilterChip(
                                    selected = params.characterMode == mode.code,
                                    onClick = { viewModel.updateVoiceParams { it.copy(characterMode = mode.code) } },
                                    label = { Text(mode.label) }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Dedicated Gaming Voice Mode & Honest Audio Routing Monitor
        item {
            NovaGamingCard(accentColor = NeonCyan) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.HeadsetMic, contentDescription = null, tint = NeonCyan)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "GAMING VOICE MODE & ROUTING",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                    }
                    IconButton(onClick = { viewModel.refreshAudioDevices() }) {
                        Icon(Icons.Filled.Refresh, contentDescription = "Refresh audio devices", tint = NeonCyan)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatusPill(
                        label = if (routingStatus.wiredOrUsbConnected) "USB/Wired Ready" else "Internal Mic/Spk",
                        active = routingStatus.wiredOrUsbConnected,
                        activeColor = NeonEmerald
                    )
                    StatusPill(
                        label = "DSP ${routingStatus.dspCpuUs} µs",
                        active = metrics.isProcessing,
                        activeColor = NeonCyan
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
                DeviceSelectorRow(
                    label = "Input Device",
                    devices = inputDevices,
                    selectedId = selectedInputId,
                    onSelected = { id ->
                        selectedInputId = id
                        viewModel.selectAudioDevices(selectedInputId, selectedOutputId)
                    }
                )
                Spacer(modifier = Modifier.height(8.dp))
                DeviceSelectorRow(
                    label = "Output Device",
                    devices = outputDevices,
                    selectedId = selectedOutputId,
                    onSelected = { id ->
                        selectedOutputId = id
                        viewModel.selectAudioDevices(selectedInputId, selectedOutputId)
                    }
                )

                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Routing Status: ${routingStatus.routingSummary}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(8.dp))

                // Honest Android Game Microphone Limitation Notice
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = AmberWarning.copy(alpha = 0.12f),
                    border = BorderStroke(1.dp, AmberWarning.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = if (routingStatus.gameMicInjectionSupported) Icons.Filled.Info else Icons.Filled.Warning,
                            contentDescription = null,
                            tint = AmberWarning,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            val targetLabel = games.firstOrNull { it.packageName == gamingVoiceTarget }?.label
                                ?: "External Games (e.g. Free Fire)"
                            Text(
                                text = if (routingStatus.gameMicInjectionSupported) {
                                    "ALSA Loopback Detected for $targetLabel"
                                } else {
                                    "Game Mic Injection Unsupported Without Hardware/Kernel Loopback"
                                },
                                style = MaterialTheme.typography.labelLarge,
                                color = AmberWarning
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = routingStatus.routingLimitationNote,
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }
        }
    }

    if (showSaveDialog) {
        SaveCustomPresetDialog(
            onDismiss = { showSaveDialog = false },
            onSave = { name, cat, desc ->
                viewModel.saveCustomVoicePreset(name, cat, desc)
                showSaveDialog = false
            }
        )
    }
}

@Composable
private fun DeviceSelectorRow(
    label: String,
    devices: List<AudioDeviceEntry>,
    selectedId: Int,
    onSelected: (Int) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    val selectedName = devices.firstOrNull { it.id == selectedId }?.name ?: "Default"

    Box(modifier = Modifier.fillMaxWidth()) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { expanded = true },
            shape = RoundedCornerShape(12.dp),
            color = ObsidianElevated,
            border = BorderStroke(1.dp, ObsidianOutline)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Text(selectedName, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                }
                Icon(Icons.Filled.ExpandMore, contentDescription = null, tint = NeonCyan)
            }
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            devices.forEach { dev ->
                DropdownMenuItem(
                    text = { Text("${dev.name} [${dev.typeLabel}]") },
                    onClick = {
                        expanded = false
                        onSelected(dev.id)
                    }
                )
            }
        }
    }
}

@Composable
private fun SaveCustomPresetDialog(
    onDismiss: () -> Unit,
    onSave: (String, VoiceCategory, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var category by remember { mutableStateOf(VoiceCategory.FEMALE) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Save Custom Voice Preset") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Preset Name") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Notes (optional)") }
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(VoiceCategory.FEMALE, VoiceCategory.BABY, VoiceCategory.CUSTOM).forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat.name) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = { onSave(name, category, description) }) {
                Text("Save Preset")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
