package com.example.ui.screens

import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.InstalledGame
import com.example.model.PerformanceMode
import com.example.model.SensitivityProfile
import com.example.model.VoicePreset
import com.example.system.LaunchableApp
import com.example.ui.NovaViewModel
import com.example.ui.components.AppIconImage
import com.example.ui.components.NovaGamingCard
import com.example.ui.components.StatusPill
import com.example.ui.theme.AmoledBlack
import com.example.ui.theme.CyberMagenta
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun GameLibraryScreen(
    viewModel: NovaViewModel,
    games: List<InstalledGame>,
    allLauncherApps: List<LaunchableApp>,
    voicePresets: List<VoicePreset>,
    sensitivityProfiles: List<SensitivityProfile>,
    supportedRatesHz: List<Int>
) {
    val activity = LocalContext.current as? Activity
    var query by remember { mutableStateOf("") }
    var favoritesOnly by remember { mutableStateOf(false) }
    var showAddAppDialog by remember { mutableStateOf(false) }
    var editingGame by remember { mutableStateOf<InstalledGame?>(null) }

    val filteredGames = remember(games, query, favoritesOnly) {
        games.filter { g ->
            val matchesQuery = query.isBlank() ||
                g.label.contains(query, ignoreCase = true) ||
                g.packageName.contains(query, ignoreCase = true)
            val matchesFav = !favoritesOnly || g.isFavorite
            matchesQuery && matchesFav
        }
    }

    Scaffold(
        containerColor = AmoledBlack,
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    viewModel.refreshGames()
                    showAddAppDialog = true
                },
                containerColor = NeonCyan,
                contentColor = AmoledBlack,
                modifier = Modifier.testTag("game_library_add_fab")
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Add game manually")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("GAME LIBRARY", style = MaterialTheme.typography.headlineMedium, color = NeonCyan)
                        Text(
                            text = "${games.size} game(s) • Auto-detected & custom",
                            style = MaterialTheme.typography.labelMedium,
                            color = TextSecondary
                        )
                    }
                    IconButton(onClick = { viewModel.refreshGames() }) {
                        Icon(Icons.Filled.Refresh, contentDescription = "Rescan installed games", tint = NeonCyan)
                    }
                }
            }

            item {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Search Free Fire or installed games...") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { query = "" }) {
                                Icon(Icons.Filled.Close, contentDescription = "Clear search")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("game_search_input")
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = !favoritesOnly,
                        onClick = { favoritesOnly = false },
                        label = { Text("All (${games.size})") }
                    )
                    FilterChip(
                        selected = favoritesOnly,
                        onClick = { favoritesOnly = true },
                        label = { Text("Favorites (${games.count { it.isFavorite }})") }
                    )
                }
            }

            if (filteredGames.isEmpty()) {
                item {
                    NovaGamingCard {
                        Text("No matching games found", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Tap the + button to manually add any installed app or game (including Free Fire / Free Fire MAX) to Nova Game Launcher.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    }
                }
            } else {
                items(filteredGames, key = { it.packageName }) { game ->
                    val isFreeFire = game.packageName.contains("freefire", ignoreCase = true)
                    NovaGamingCard(
                        highlighted = isFreeFire,
                        accentColor = if (isFreeFire) CyberMagenta else NeonCyan
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AppIconImage(
                                drawable = viewModel.loadAppIcon(game.packageName),
                                contentDescription = game.label,
                                modifier = Modifier.size(52.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = game.label,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = game.packageName,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    StatusPill(
                                        label = game.performanceMode.label,
                                        active = true,
                                        activeColor = ElectricPurple
                                    )
                                    if (game.targetRefreshRateHz > 0) {
                                        StatusPill(
                                            label = "${game.targetRefreshRateHz} Hz",
                                            active = true,
                                            activeColor = NeonCyan
                                        )
                                    }
                                }
                            }
                            IconButton(onClick = { viewModel.toggleFavoriteGame(game) }) {
                                Icon(
                                    imageVector = if (game.isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                                    contentDescription = "Toggle favorite",
                                    tint = if (game.isFavorite) CyberMagenta else TextSecondary
                                )
                            }
                        }

                        if (isFreeFire) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Free Fire Profile Compatible: launches with sensitivity reference & Game Mode. External game mic capture remains isolated by Android OS unless using USB/TRRS loopback.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = CyberMagenta
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = { editingGame = game },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Filled.Tune, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Profile")
                            }
                            Button(
                                onClick = { viewModel.launchGameWithProfile(activity, game) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = NeonEmerald,
                                    contentColor = AmoledBlack
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("launch_game_${game.packageName}")
                            ) {
                                Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Launch")
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddAppDialog) {
        AddManualGameDialog(
            apps = allLauncherApps.filter { app -> games.none { it.packageName == app.packageName } },
            onDismiss = { showAddAppDialog = false },
            onAdd = { app ->
                viewModel.addManualGame(app)
                showAddAppDialog = false
            }
        )
    }

    editingGame?.let { game ->
        PerGameProfileDialog(
            game = game,
            voicePresets = voicePresets,
            sensitivityProfiles = sensitivityProfiles,
            supportedRatesHz = supportedRatesHz,
            onDismiss = { editingGame = null },
            onSave = { vId, pMode, hz, sId ->
                viewModel.updateGameProfile(game, vId, pMode, hz, sId)
                editingGame = null
            },
            onRemoveManual = if (game.isManuallyAdded) {
                {
                    viewModel.removeManualGame(game.packageName)
                    editingGame = null
                }
            } else null
        )
    }
}

@Composable
private fun AddManualGameDialog(
    apps: List<LaunchableApp>,
    onDismiss: () -> Unit,
    onAdd: (LaunchableApp) -> Unit
) {
    var filter by remember { mutableStateOf("") }
    val filtered = remember(apps, filter) {
        apps.filter { filter.isBlank() || it.label.contains(filter, ignoreCase = true) || it.packageName.contains(filter, ignoreCase = true) }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Game Manually") },
        text = {
            Column(modifier = Modifier.height(360.dp)) {
                OutlinedTextField(
                    value = filter,
                    onValueChange = { filter = it },
                    label = { Text("Filter installed apps") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(filtered, key = { it.packageName }) { app ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onAdd(app) }
                                .padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(app.label, style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
                                Text(app.packageName, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                            Text("ADD", style = MaterialTheme.typography.labelMedium, color = NeonCyan)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}

@Composable
private fun PerGameProfileDialog(
    game: InstalledGame,
    voicePresets: List<VoicePreset>,
    sensitivityProfiles: List<SensitivityProfile>,
    supportedRatesHz: List<Int>,
    onDismiss: () -> Unit,
    onSave: (String?, PerformanceMode, Int, String?) -> Unit,
    onRemoveManual: (() -> Unit)?
) {
    var voiceId by remember { mutableStateOf(game.voicePresetId) }
    var perfMode by remember { mutableStateOf(game.performanceMode) }
    var targetHz by remember { mutableStateOf(game.targetRefreshRateHz) }
    var sensId by remember { mutableStateOf(game.sensitivityProfileId) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("${game.label} Profile") },
        text = {
            LazyColumn(
                modifier = Modifier.height(360.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text("Performance Mode", style = MaterialTheme.typography.labelMedium, color = NeonCyan)
                    PerformanceMode.entries.forEach { mode ->
                        FilterChip(
                            selected = perfMode == mode,
                            onClick = { perfMode = mode },
                            label = { Text(mode.label) }
                        )
                    }
                }
                item {
                    Text("Target Refresh Rate", style = MaterialTheme.typography.labelMedium, color = NeonCyan)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(selected = targetHz == 0, onClick = { targetHz = 0 }, label = { Text("Auto") })
                        supportedRatesHz.forEach { hz ->
                            FilterChip(selected = targetHz == hz, onClick = { targetHz = hz }, label = { Text("${hz}Hz") })
                        }
                    }
                }
                item {
                    Text("Linked Voice Preset", style = MaterialTheme.typography.labelMedium, color = NeonCyan)
                    FilterChip(selected = voiceId == null, onClick = { voiceId = null }, label = { Text("Keep Current") })
                    voicePresets.take(6).forEach { vp ->
                        FilterChip(selected = voiceId == vp.id, onClick = { voiceId = vp.id }, label = { Text(vp.name) })
                    }
                }
                item {
                    Text("Linked Sensitivity Profile", style = MaterialTheme.typography.labelMedium, color = NeonCyan)
                    FilterChip(selected = sensId == null, onClick = { sensId = null }, label = { Text("None") })
                    sensitivityProfiles.forEach { sp ->
                        FilterChip(selected = sensId == sp.id, onClick = { sensId = sp.id }, label = { Text(sp.name) })
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = { onSave(voiceId, perfMode, targetHz, sensId) }) {
                Text("Save Profile")
            }
        },
        dismissButton = {
            Row {
                if (onRemoveManual != null) {
                    TextButton(onClick = onRemoveManual) { Text("Remove", color = CyberMagenta) }
                }
                TextButton(onClick = onDismiss) { Text("Cancel") }
            }
        }
    )
}
