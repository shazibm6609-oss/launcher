package com.example.ui

import android.app.Activity
import android.app.Application
import android.graphics.drawable.Drawable
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.VoiceEngineManager
import com.example.data.AppSettings
import com.example.data.GameProfileEntity
import com.example.data.NovaDatabase
import com.example.data.NovaPreferences
import com.example.data.NovaRepository
import com.example.model.AudioDeviceEntry
import com.example.model.AudioRoutingStatus
import com.example.model.BuiltInVoicePresets
import com.example.model.DeviceTelemetry
import com.example.model.InstalledGame
import com.example.model.OperatingMode
import com.example.model.PerformanceMode
import com.example.model.RefreshRateSnapshot
import com.example.model.RootStatus
import com.example.model.SensitivityProfile
import com.example.model.ShizukuStatus
import com.example.model.VoiceCategory
import com.example.model.VoiceEngineMetrics
import com.example.model.VoiceParameters
import com.example.model.VoicePreset
import com.example.system.GameDiscoveryManager
import com.example.system.LaunchableApp
import com.example.system.PerformanceEngine
import com.example.system.RefreshRateManager
import com.example.system.RootManager
import com.example.system.ShizukuManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID

class NovaViewModel(application: Application) : AndroidViewModel(application) {
    private val database = NovaDatabase.getInstance(application)
    private val preferences = NovaPreferences(application)
    private val repository = NovaRepository(database, preferences)

    val rootManager = RootManager(application)
    val shizukuManager = ShizukuManager(application)
    val refreshRateManager = RefreshRateManager(application, rootManager, shizukuManager)
    val performanceEngine = PerformanceEngine(application, rootManager, shizukuManager, refreshRateManager)
    val voiceEngineManager = VoiceEngineManager(application)
    private val gameDiscoveryManager = GameDiscoveryManager(application)

    val settings: StateFlow<AppSettings> = repository.settingsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = AppSettings()
    )

    val allVoicePresets: StateFlow<List<VoicePreset>> = repository.customVoicePresetsFlow
        .combine(MutableStateFlow(BuiltInVoicePresets.ALL)) { custom, builtIn ->
            builtIn + custom
        }
        .stateIn(viewModelScope, SharingStarted.Eagerly, BuiltInVoicePresets.ALL)

    val sensitivityProfiles: StateFlow<List<SensitivityProfile>> = repository.sensitivityProfilesFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val voiceMetrics: StateFlow<VoiceEngineMetrics> = voiceEngineManager.metrics
    val audioRoutingStatus: StateFlow<AudioRoutingStatus> = voiceEngineManager.routingStatus
    val inputDevices: StateFlow<List<AudioDeviceEntry>> = voiceEngineManager.inputDevices
    val outputDevices: StateFlow<List<AudioDeviceEntry>> = voiceEngineManager.outputDevices

    val rootStatus: StateFlow<RootStatus> = rootManager.status
    val shizukuStatus: StateFlow<ShizukuStatus> = shizukuManager.status
    val refreshRateSnapshot: StateFlow<RefreshRateSnapshot> = refreshRateManager.snapshot
    val telemetry: StateFlow<DeviceTelemetry> = performanceEngine.telemetry

    private val _selectedPreset = MutableStateFlow(BuiltInVoicePresets.ALL.first())
    val selectedPreset: StateFlow<VoicePreset> = _selectedPreset.asStateFlow()

    private val _voiceParams = MutableStateFlow(BuiltInVoicePresets.ALL.first().params)
    val voiceParams: StateFlow<VoiceParameters> = _voiceParams.asStateFlow()

    private val _effectEnabled = MutableStateFlow(true)
    val effectEnabled: StateFlow<Boolean> = _effectEnabled.asStateFlow()

    private val _originalPreview = MutableStateFlow(false)
    val originalPreview: StateFlow<Boolean> = _originalPreview.asStateFlow()

    private val _installedGames = MutableStateFlow<List<InstalledGame>>(emptyList())
    val installedGames: StateFlow<List<InstalledGame>> = _installedGames.asStateFlow()

    private val _allLauncherApps = MutableStateFlow<List<LaunchableApp>>(emptyList())
    val allLauncherApps: StateFlow<List<LaunchableApp>> = _allLauncherApps.asStateFlow()

    private val _statusToast = MutableStateFlow<String?>(null)
    val statusToast: StateFlow<String?> = _statusToast.asStateFlow()

    private val _gamingVoiceGameTarget = MutableStateFlow<String?>(null)
    val gamingVoiceGameTarget: StateFlow<String?> = _gamingVoiceGameTarget.asStateFlow()

    init {
        shizukuManager.registerListeners()
        refreshRateManager.startFpsMonitor()

        viewModelScope.launch {
            repository.seedDefaultsIfEmpty()
            rootManager.detectRoot()
            refreshGames()
        }

        viewModelScope.launch {
            repository.gameProfilesFlow.collect { profiles ->
                _installedGames.value = gameDiscoveryManager.buildInstalledGamesList(profiles)
            }
        }

        // Sync persisted voice preset ID on first emission
        viewModelScope.launch {
            val savedId = settings.value.activeVoicePresetId
            allVoicePresets.value.firstOrNull { it.id == savedId }?.let { preset ->
                selectVoicePreset(preset)
            }
        }

        // Real-time telemetry polling loop (1.5s interval)
        viewModelScope.launch {
            while (isActive) {
                performanceEngine.pollTelemetry()
                refreshRateManager.refreshHardwareDisplayInfo(settings.value.activeRefreshRateHz)
                delay(1500L)
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        voiceEngineManager.stopLiveProcessing()
        voiceEngineManager.stopSampleRecording()
        voiceEngineManager.stopRecordedPreview()
        shizukuManager.unregisterListeners()
        refreshRateManager.stopFpsMonitor()
    }

    fun clearStatusToast() {
        _statusToast.value = null
    }

    fun showMessage(msg: String) {
        _statusToast.value = msg
    }

    // ---- VOICE STUDIO ----

    fun selectVoicePreset(preset: VoicePreset) {
        _selectedPreset.value = preset
        _voiceParams.value = preset.params
        _originalPreview.value = false
        _effectEnabled.value = true
        pushDspParams()
        viewModelScope.launch {
            repository.setActiveVoicePresetId(preset.id)
        }
    }

    fun updateVoiceParams(transform: (VoiceParameters) -> VoiceParameters) {
        _voiceParams.value = transform(_voiceParams.value)
        pushDspParams()
    }

    fun setEffectEnabled(enabled: Boolean) {
        _effectEnabled.value = enabled
        pushDspParams()
    }

    fun setOriginalPreview(original: Boolean) {
        _originalPreview.value = original
        pushDspParams()
    }

    fun resetVoiceParameters() {
        val current = _selectedPreset.value
        _voiceParams.value = current.params
        _effectEnabled.value = true
        _originalPreview.value = false
        pushDspParams()
        showMessage("Reset ${current.name} controls to defaults")
    }

    fun toggleLiveMicrophone() {
        if (voiceMetrics.value.isProcessing) {
            voiceEngineManager.stopLiveProcessing()
        } else {
            pushDspParams()
            val s = settings.value
            val ok = voiceEngineManager.startLiveProcessing(s.preferredSampleRate, s.lowLatencyBufferFrames)
            if (!ok) {
                showMessage("Failed to open microphone stream. Check audio device and permission.")
            }
        }
    }

    fun refreshAudioDevices() {
        voiceEngineManager.refreshAudioDevices()
    }

    fun selectAudioDevices(inputId: Int, outputId: Int) {
        voiceEngineManager.setDevices(inputId, outputId)
    }

    fun setGamingVoiceTarget(packageName: String?) {
        _gamingVoiceGameTarget.value = packageName
    }

    fun toggleSampleRecording() {
        if (voiceMetrics.value.isRecordingSample) {
            voiceEngineManager.stopSampleRecording()
        } else {
            voiceEngineManager.startSampleRecording()
        }
    }

    fun playRecordedPreview(original: Boolean) {
        pushDspParams()
        voiceEngineManager.playRecordedPreview(original)
    }

    fun stopRecordedPreview() {
        voiceEngineManager.stopRecordedPreview()
    }

    fun saveCustomVoicePreset(name: String, category: VoiceCategory, description: String) {
        if (name.isBlank()) {
            showMessage("Enter a preset name")
            return
        }
        viewModelScope.launch {
            val saved = repository.saveCustomVoicePreset(name, category, description, _voiceParams.value)
            _selectedPreset.value = saved
            repository.setActiveVoicePresetId(saved.id)
            showMessage("Saved custom preset '${saved.name}'")
        }
    }

    fun deleteCustomVoicePreset(id: String) {
        viewModelScope.launch {
            repository.deleteCustomVoicePreset(id)
            if (_selectedPreset.value.id == id) {
                selectVoicePreset(BuiltInVoicePresets.ALL.first())
            }
            showMessage("Deleted custom preset")
        }
    }

    private fun pushDspParams() {
        voiceEngineManager.updateParameters(
            params = _voiceParams.value,
            effectOn = _effectEnabled.value,
            originalPreview = _originalPreview.value
        )
    }

    // ---- GAME LAUNCHER ----

    fun refreshGames() {
        viewModelScope.launch {
            _allLauncherApps.value = gameDiscoveryManager.discoverAllLauncherApps()
            val saved = emptyMap<String, GameProfileEntity>()
            if (_installedGames.value.isEmpty()) {
                _installedGames.value = gameDiscoveryManager.buildInstalledGamesList(saved)
            }
        }
    }

    fun loadAppIcon(packageName: String): Drawable? = gameDiscoveryManager.loadAppIcon(packageName)

    fun toggleFavoriteGame(game: InstalledGame) {
        viewModelScope.launch {
            repository.upsertGameProfile(
                GameProfileEntity(
                    packageName = game.packageName,
                    isFavorite = !game.isFavorite,
                    isManuallyAdded = game.isManuallyAdded,
                    voicePresetId = game.voicePresetId,
                    performanceMode = game.performanceMode.name,
                    targetRefreshRateHz = game.targetRefreshRateHz,
                    sensitivityProfileId = game.sensitivityProfileId
                )
            )
        }
    }

    fun addManualGame(app: LaunchableApp) {
        viewModelScope.launch {
            repository.upsertGameProfile(
                GameProfileEntity(
                    packageName = app.packageName,
                    isFavorite = false,
                    isManuallyAdded = true,
                    performanceMode = PerformanceMode.GAMING.name
                )
            )
            showMessage("Added ${app.label} to Game Library")
        }
    }

    fun updateGameProfile(
        game: InstalledGame,
        voicePresetId: String?,
        performanceMode: PerformanceMode,
        targetRefreshRateHz: Int,
        sensitivityProfileId: String?
    ) {
        viewModelScope.launch {
            repository.upsertGameProfile(
                GameProfileEntity(
                    packageName = game.packageName,
                    isFavorite = game.isFavorite,
                    isManuallyAdded = game.isManuallyAdded,
                    voicePresetId = voicePresetId,
                    performanceMode = performanceMode.name,
                    targetRefreshRateHz = targetRefreshRateHz,
                    sensitivityProfileId = sensitivityProfileId
                )
            )
            showMessage("Saved profile for ${game.label}")
        }
    }

    fun removeManualGame(packageName: String) {
        viewModelScope.launch {
            repository.removeManualGame(packageName)
            showMessage("Removed from manual games")
        }
    }

    fun launchGameWithProfile(activity: Activity?, game: InstalledGame) {
        viewModelScope.launch {
            // Apply per-game voice preset if linked
            game.voicePresetId?.let { pid ->
                allVoicePresets.value.firstOrNull { it.id == pid }?.let { selectVoicePreset(it) }
            }
            _gamingVoiceGameTarget.value = game.packageName

            // Apply per-game performance mode
            repository.setActivePerformanceMode(game.performanceMode)
            performanceEngine.applyPerformanceMode(
                mode = game.performanceMode,
                operatingMode = settings.value.operatingMode,
                targetPackage = game.packageName,
                reduceAnimations = settings.value.reduceAnimationsInGameMode
            )

            // Apply per-game refresh rate if specified
            if (game.targetRefreshRateHz > 0) {
                repository.setActiveRefreshRateHz(game.targetRefreshRateHz)
                refreshRateManager.applyRefreshRate(activity, game.targetRefreshRateHz, settings.value.operatingMode)
            }

            val launched = gameDiscoveryManager.launchPackage(game.packageName)
            if (!launched) {
                showMessage("Unable to launch ${game.label}")
            }
        }
    }

    // ---- PERFORMANCE & REFRESH RATE ----

    fun applyPerformanceMode(mode: PerformanceMode) {
        viewModelScope.launch {
            repository.setActivePerformanceMode(mode)
            val msg = performanceEngine.applyPerformanceMode(
                mode = mode,
                operatingMode = settings.value.operatingMode,
                targetPackage = _gamingVoiceGameTarget.value,
                reduceAnimations = settings.value.reduceAnimationsInGameMode
            )
            showMessage(msg)
        }
    }

    fun applyRefreshRate(activity: Activity?, hz: Int) {
        viewModelScope.launch {
            repository.setActiveRefreshRateHz(hz)
            val res = refreshRateManager.applyRefreshRate(activity, hz, settings.value.operatingMode)
            res.onSuccess { showMessage(it) }
                .onFailure { showMessage(it.message ?: "Failed to set refresh rate") }
        }
    }

    fun restoreRefreshRate(activity: Activity?) {
        viewModelScope.launch {
            repository.setActiveRefreshRateHz(0)
            val msg = refreshRateManager.restoreOriginalRefreshRate(activity, settings.value.operatingMode)
            showMessage(msg)
        }
    }

    // ---- SENSITIVITY MANAGER ----

    fun saveSensitivityProfile(profile: SensitivityProfile) {
        viewModelScope.launch {
            repository.saveSensitivityProfile(profile)
            showMessage("Saved '${profile.name}'")
        }
    }

    fun createNewSensitivityProfile(name: String, linkedPkg: String?) {
        val profile = SensitivityProfile(
            id = "sens_${UUID.randomUUID().toString().take(8)}",
            name = name.ifBlank { "New Profile" },
            linkedPackage = linkedPkg
        )
        saveSensitivityProfile(profile)
    }

    fun deleteSensitivityProfile(id: String) {
        viewModelScope.launch {
            repository.deleteSensitivityProfile(id)
            showMessage("Deleted sensitivity profile")
        }
    }

    fun exportSensitivityJson(): String {
        return repository.exportSensitivityProfilesToJson(sensitivityProfiles.value)
    }

    fun importSensitivityJson(rawJson: String) {
        viewModelScope.launch {
            val res = repository.importSensitivityProfilesFromJson(rawJson)
            res.onSuccess { count -> showMessage("Imported $count sensitivity profile(s)") }
                .onFailure { showMessage("Invalid JSON format: ${it.message}") }
        }
    }

    // ---- ROOT & SHIZUKU ----

    fun detectAndRequestRoot() {
        viewModelScope.launch {
            val status = rootManager.requestSuperuserAndVerify()
            if (status.isAuthorized) {
                showMessage("Magisk Root authorized (${status.uidInfo})")
            } else {
                showMessage(status.lastError ?: "Root unavailable or denied")
            }
        }
    }

    fun setRootCpuGovernor(gov: String) {
        viewModelScope.launch {
            val res = rootManager.setCpuGovernor(gov)
            if (res.isSuccess) showMessage("CPU governor set to $gov")
            else showMessage("Failed: ${res.stderr}")
        }
    }

    fun restoreRootSettings() {
        viewModelScope.launch {
            val res = rootManager.restoreOriginalSettings()
            showMessage(res.stdout.ifBlank { res.stderr }.ifBlank { "Root settings restored" })
        }
    }

    fun requestShizukuPermission() {
        shizukuManager.refreshStatus()
        shizukuManager.requestPermission()
    }

    fun openShizukuApp() {
        if (!shizukuManager.openShizukuApp()) {
            showMessage("Shizuku app is not installed.")
        }
    }

    fun runShizukuTestCommand(command: String) {
        viewModelScope.launch {
            val res = shizukuManager.runPrivilegedCommand(command)
            if (res.isSuccess) showMessage("Shizuku executed OK")
            else showMessage(res.stderr)
        }
    }

    fun setShizukuGameMode(packageName: String, mode: String) {
        viewModelScope.launch {
            val res = shizukuManager.setGameMode(packageName, mode)
            if (res.isSuccess) showMessage("Game mode set to $mode for $packageName")
            else showMessage(res.stderr)
        }
    }

    fun setShizukuAnimationScale(scale: Float) {
        viewModelScope.launch {
            val res = shizukuManager.setAnimationScales(scale)
            if (res.isSuccess) showMessage("Animation scales set to ${scale}x")
            else showMessage(res.stderr)
        }
    }

    fun restoreShizukuSettings() {
        viewModelScope.launch {
            val res = shizukuManager.restoreOriginalSettings()
            showMessage(res.stdout.ifBlank { res.stderr }.ifBlank { "Shizuku settings restored" })
        }
    }

    // ---- SETTINGS ----

    fun setOperatingMode(mode: OperatingMode) {
        viewModelScope.launch { repository.setOperatingMode(mode) }
    }

    fun setPreferredSampleRate(rate: Int) {
        viewModelScope.launch { repository.setPreferredSampleRate(rate) }
    }

    fun setLowLatencyBufferFrames(frames: Int) {
        viewModelScope.launch { repository.setLowLatencyBufferFrames(frames) }
    }

    fun setShowSplashOnStartup(show: Boolean) {
        viewModelScope.launch { repository.setShowSplashOnStartup(show) }
    }

    fun setReduceAnimationsInGameMode(enabled: Boolean) {
        viewModelScope.launch { repository.setReduceAnimationsInGameMode(enabled) }
    }

    fun resetAllAppData() {
        viewModelScope.launch {
            repository.resetAllData()
            selectVoicePreset(BuiltInVoicePresets.ALL.first())
            showMessage("All presets, profiles, and settings reset to factory defaults")
        }
    }
}
