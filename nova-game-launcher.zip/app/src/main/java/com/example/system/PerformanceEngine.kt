package com.example.system

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import com.example.model.DeviceTelemetry
import com.example.model.OperatingMode
import com.example.model.PerformanceMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File

class PerformanceEngine(
    private val context: Context,
    private val rootManager: RootManager,
    private val shizukuManager: ShizukuManager,
    private val refreshRateManager: RefreshRateManager
) {
    private val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager

    private val _telemetry = MutableStateFlow(DeviceTelemetry())
    val telemetry: StateFlow<DeviceTelemetry> = _telemetry.asStateFlow()

    private var prevIdle = -1L
    private var prevTotal = -1L

    suspend fun pollTelemetry(): DeviceTelemetry = withContext(Dispatchers.IO) {
        // 1. RAM
        val memInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memInfo)
        val totalMb = memInfo.totalMem / (1024L * 1024L)
        val availMb = memInfo.availMem / (1024L * 1024L)
        val usedMb = (totalMb - availMb).coerceAtLeast(0L)
        val ramPct = if (totalMb > 0) (usedMb.toFloat() / totalMb.toFloat()) * 100f else 0f

        // 2. Battery & Device Temperature
        val batIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val batteryPct = if (level >= 0 && scale > 0) (level * 100 / scale) else 0
        val status = batIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        val tempTenths = batIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        val tempC = tempTenths / 10f

        // 3. Thermal Throttling Status (Android 10+ API 29+)
        val (thermalLabel, isThrottling) = if (Build.VERSION.SDK_INT >= 29) {
            when (powerManager.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> "Normal" to false
                PowerManager.THERMAL_STATUS_LIGHT -> "Light Warmth" to false
                PowerManager.THERMAL_STATUS_MODERATE -> "Moderate Throttle" to true
                PowerManager.THERMAL_STATUS_SEVERE -> "Severe Throttle" to true
                PowerManager.THERMAL_STATUS_CRITICAL -> "Critical Throttle" to true
                PowerManager.THERMAL_STATUS_EMERGENCY -> "Emergency" to true
                PowerManager.THERMAL_STATUS_SHUTDOWN -> "Shutdown Risk" to true
                else -> "Normal" to false
            }
        } else {
            (if (tempC >= 43f) "Warm" else "Normal") to (tempC >= 45f)
        }

        // 4. CPU Frequencies & Governor
        val cpuFreqs = readCpuFrequenciesMhz()
        val gov = readGovernor()
        val cpuPercent = readCpuUsagePercent()

        val fps = refreshRateManager.snapshot.value.measuredFps

        val snapshot = DeviceTelemetry(
            cpuUsagePercent = cpuPercent,
            cpuFrequenciesMhz = cpuFreqs,
            cpuGovernor = gov,
            ramUsedMb = usedMb,
            ramTotalMb = totalMb,
            ramPercent = ramPct,
            batteryLevel = batteryPct,
            batteryCharging = charging,
            deviceTempCelsius = tempC,
            thermalStatusLabel = thermalLabel,
            isThermalThrottling = isThrottling,
            currentFps = fps
        )
        _telemetry.value = snapshot
        snapshot
    }

    suspend fun applyPerformanceMode(
        mode: PerformanceMode,
        operatingMode: OperatingMode,
        targetPackage: String? = null,
        reduceAnimations: Boolean = true
    ): String {
        val actions = mutableListOf<String>()

        val animScale = when (mode) {
            PerformanceMode.GAMING -> if (reduceAnimations) 0.5f else 1.0f
            PerformanceMode.PERFORMANCE -> 0.5f
            PerformanceMode.BALANCED -> 1.0f
            PerformanceMode.BATTERY_SAVER -> 1.0f
            PerformanceMode.CUSTOM -> if (reduceAnimations) 0.5f else 1.0f
        }

        val targetGov = when (mode) {
            PerformanceMode.GAMING, PerformanceMode.PERFORMANCE -> "performance"
            PerformanceMode.BALANCED, PerformanceMode.CUSTOM -> "schedutil"
            PerformanceMode.BATTERY_SAVER -> "powersave"
        }

        val useRoot = (operatingMode == OperatingMode.ROOT) ||
            (operatingMode == OperatingMode.AUTO && rootManager.status.value.isAuthorized)
        val useShizuku = shizukuManager.status.value.isBinderAlive && shizukuManager.status.value.isPermissionGranted

        if (operatingMode != OperatingMode.STANDARD) {
            if (useRoot && rootManager.status.value.isAuthorized) {
                val avail = rootManager.status.value.availableGovernors
                if (targetGov in avail) {
                    val r = rootManager.setCpuGovernor(targetGov)
                    if (r.isSuccess) actions.add("Root CPU governor -> $targetGov")
                }
                val animRes = rootManager.setAnimationScales(animScale)
                if (animRes.isSuccess) actions.add("Animation scale -> ${animScale}x")
            } else if (useShizuku) {
                val animRes = shizukuManager.setAnimationScales(animScale)
                if (animRes.isSuccess) actions.add("Shizuku animation scale -> ${animScale}x")
                if (!targetPackage.isNullOrBlank() && Build.VERSION.SDK_INT >= 31) {
                    val gmMode = when (mode) {
                        PerformanceMode.GAMING, PerformanceMode.PERFORMANCE -> "performance"
                        PerformanceMode.BATTERY_SAVER -> "battery"
                        else -> "standard"
                    }
                    val gmRes = shizukuManager.setGameMode(targetPackage, gmMode)
                    if (gmRes.isSuccess) actions.add("GameManager ($targetPackage) -> $gmMode")
                }
            }
        }

        // Standard non-privileged memory trim hint
        if (mode == PerformanceMode.GAMING || mode == PerformanceMode.PERFORMANCE) {
            System.gc()
            actions.add("JVM heap trimmed & low-latency mode ready")
        }

        return if (actions.isEmpty()) {
            "${mode.label} active (Standard mode — authorize Root/Shizuku for system governor & GameManager control)"
        } else {
            actions.joinToString(" • ")
        }
    }

    private fun readCpuFrequenciesMhz(): List<Int> {
        val list = mutableListOf<Int>()
        for (core in 0 until 8) {
            val file = File("/sys/devices/system/cpu/cpu$core/cpufreq/scaling_cur_freq")
            if (!file.exists()) break
            val khz = runCatching { file.readText().trim().toIntOrNull() }.getOrNull()
            if (khz != null && khz > 0) {
                list.add(khz / 1000)
            }
        }
        return list
    }

    private fun readGovernor(): String {
        val file = File("/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor")
        val direct = runCatching {
            if (file.exists() && file.canRead()) file.readText().trim() else null
        }.getOrNull()
        return direct?.takeIf { it.isNotBlank() }
            ?: rootManager.status.value.currentGovernor.takeIf { it != "Unknown" }
            ?: "Restricted (Root needed)"
    }

    private fun readCpuUsagePercent(): Float? {
        return runCatching {
            val stat = File("/proc/stat")
            if (!stat.exists() || !stat.canRead()) return null
            val line = stat.bufferedReader().use { it.readLine() } ?: return null
            val parts = line.trim().split(Regex("\\s+"))
            if (parts.size < 5 || parts[0] != "cpu") return null
            val user = parts[1].toLong()
            val nice = parts[2].toLong()
            val sys = parts[3].toLong()
            val idle = parts[4].toLong()
            val iowait = parts.getOrNull(5)?.toLongOrNull() ?: 0L
            val irq = parts.getOrNull(6)?.toLongOrNull() ?: 0L
            val softirq = parts.getOrNull(7)?.toLongOrNull() ?: 0L
            val total = user + nice + sys + idle + iowait + irq + softirq
            val idleAll = idle + iowait
            if (prevTotal <= 0L) {
                prevTotal = total
                prevIdle = idleAll
                return null
            }
            val diffTotal = (total - prevTotal).coerceAtLeast(1L)
            val diffIdle = (idleAll - prevIdle).coerceAtLeast(0L)
            prevTotal = total
            prevIdle = idleAll
            (((diffTotal - diffIdle).toFloat() / diffTotal.toFloat()) * 100f).coerceIn(0f, 100f)
        }.getOrNull()
    }
}
