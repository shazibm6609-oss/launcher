package com.example.system

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Build
import com.example.data.GameProfileEntity
import com.example.model.InstalledGame
import com.example.model.PerformanceMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class LaunchableApp(
    val packageName: String,
    val label: String,
    val isGameCategory: Boolean
)

class GameDiscoveryManager(private val context: Context) {
    private val pm: PackageManager = context.packageManager

    private val knownPopularGames = setOf(
        "com.dts.freefireth",
        "com.dts.freefiremax",
        "com.tencent.ig",
        "com.pubg.imobile",
        "com.pubg.krmobile",
        "com.activision.callofduty.shooter",
        "com.garena.game.codm",
        "com.mobile.legends",
        "com.miHoYo.GenshinImpact",
        "com.HoYoverse.hkrpgoversea",
        "com.roblox.client",
        "com.mojang.minecraftpe",
        "com.supercell.brawlstars",
        "com.supercell.clashroyale",
        "com.epicgames.fortnite",
        "com.riotgames.league.wildrift",
        "com.ea.gp.fifamobile"
    )

    suspend fun discoverAllLauncherApps(): List<LaunchableApp> = withContext(Dispatchers.IO) {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfos = if (Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(intent, 0)
        }

        val seen = HashSet<String>()
        val result = mutableListOf<LaunchableApp>()
        for (ri in resolveInfos) {
            val pkg = ri.activityInfo?.packageName ?: continue
            if (pkg == context.packageName || !seen.add(pkg)) continue
            val appInfo = ri.activityInfo.applicationInfo
            val isGame = isAppAGame(appInfo, pkg)
            val label = ri.loadLabel(pm)?.toString()?.takeIf { it.isNotBlank() } ?: pkg
            result.add(LaunchableApp(packageName = pkg, label = label, isGameCategory = isGame))
        }
        result.sortedBy { it.label.lowercase() }
    }

    suspend fun buildInstalledGamesList(
        profiles: Map<String, GameProfileEntity>
    ): List<InstalledGame> {
        val allApps = discoverAllLauncherApps()
        return allApps.mapNotNull { app ->
            val saved = profiles[app.packageName]
            if (app.isGameCategory || saved != null) {
                InstalledGame(
                    packageName = app.packageName,
                    label = app.label,
                    isDetectedGame = app.isGameCategory,
                    isFavorite = saved?.isFavorite ?: false,
                    isManuallyAdded = saved?.isManuallyAdded ?: false,
                    voicePresetId = saved?.voicePresetId,
                    performanceMode = saved?.performanceMode?.let { name ->
                        PerformanceMode.entries.firstOrNull { it.name == name }
                    } ?: PerformanceMode.GAMING,
                    targetRefreshRateHz = saved?.targetRefreshRateHz ?: 0,
                    sensitivityProfileId = saved?.sensitivityProfileId
                )
            } else {
                null
            }
        }.sortedWith(compareByDescending<InstalledGame> { it.isFavorite }.thenBy { it.label.lowercase() })
    }

    fun loadAppIcon(packageName: String): Drawable? {
        return runCatching { pm.getApplicationIcon(packageName) }.getOrNull()
    }

    fun launchPackage(packageName: String): Boolean {
        val launchIntent = pm.getLaunchIntentForPackage(packageName) ?: return false
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return runCatching {
            context.startActivity(launchIntent)
            true
        }.getOrDefault(false)
    }

    private fun isAppAGame(info: ApplicationInfo?, pkg: String): Boolean {
        if (pkg in knownPopularGames) return true
        if (info == null) return false
        if (Build.VERSION.SDK_INT >= 26 && info.category == ApplicationInfo.CATEGORY_GAME) {
            return true
        }
        @Suppress("DEPRECATION")
        return (info.flags and ApplicationInfo.FLAG_IS_GAME) != 0
    }
}
