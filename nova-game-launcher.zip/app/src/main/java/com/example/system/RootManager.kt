package com.example.system

import android.content.Context
import android.content.pm.PackageManager
import com.example.model.RootStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.TimeUnit

data class ShellResult(
    val exitCode: Int,
    val stdout: String,
    val stderr: String
) {
    val isSuccess: Boolean get() = exitCode == 0
}

class RootManager(private val context: Context) {
    private val _status = MutableStateFlow(RootStatus())
    val status: StateFlow<RootStatus> = _status.asStateFlow()

    private val suCandidatePaths = listOf(
        "/system/bin/su",
        "/system/xbin/su",
        "/sbin/su",
        "/debug_ramdisk/su",
        "/su/bin/su",
        "/vendor/bin/su"
    )

    private var savedPeakRefresh: String? = null
    private var savedMinRefresh: String? = null
    private var savedAnimWindow: String? = null
    private var savedAnimTrans: String? = null
    private var savedAnimDuration: String? = null

    suspend fun detectRoot(): RootStatus = withContext(Dispatchers.IO) {
        val suPath = suCandidatePaths.firstOrNull { File(it).exists() }
        val magiskPkgInstalled = isPackageInstalled("com.topjohnwu.magisk") ||
            isPackageInstalled("io.github.huskydg.magisk") ||
            isPackageInstalled("io.github.vvb2060.magisk")
        val magiskFilesExist = File("/data/adb/magisk").exists() || File("/sbin/.magisk").exists()

        val magiskVersionFromPath = runCatching {
            val proc = ProcessBuilder("magisk", "-v").start()
            proc.waitFor(1500, TimeUnit.MILLISECONDS)
            if (proc.exitValue() == 0) proc.inputStream.bufferedReader().readText().trim() else ""
        }.getOrDefault("")

        val detected = suPath != null || magiskPkgInstalled || magiskFilesExist || magiskVersionFromPath.isNotBlank()
        val versionLabel = when {
            magiskVersionFromPath.isNotBlank() -> magiskVersionFromPath
            magiskPkgInstalled -> "Magisk App Detected"
            suPath != null -> "SU Binary ($suPath)"
            else -> "Not Detected"
        }

        val current = _status.value.copy(
            magiskDetected = detected,
            magiskVersion = versionLabel,
            suBinaryPath = suPath
        )
        _status.value = current
        current
    }

    suspend fun requestSuperuserAndVerify(): RootStatus = withContext(Dispatchers.IO) {
        detectRoot()
        val result = executeRootCommand("id && magisk -V 2>/dev/null || true")
        if (result.isSuccess && result.stdout.contains("uid=0")) {
            val govs = readGovernorsRoot()
            val curGov = readCurrentGovernorRoot()
            val backup = _status.value.originalGovernorBackup ?: curGov.takeIf { it != "Unknown" }
            val updated = _status.value.copy(
                isAuthorized = true,
                uidInfo = result.stdout.lines().firstOrNull().orEmpty(),
                availableGovernors = govs,
                currentGovernor = curGov,
                originalGovernorBackup = backup,
                lastCommandOutput = result.stdout,
                lastError = null
            )
            _status.value = updated
            updated
        } else {
            val errMsg = when {
                !_status.value.magiskDetected -> "No su/Magisk binary found on this device."
                result.stderr.isNotBlank() -> result.stderr
                else -> "Superuser permission denied or timed out (exit ${result.exitCode})."
            }
            val updated = _status.value.copy(
                isAuthorized = false,
                lastCommandOutput = result.stdout,
                lastError = errMsg
            )
            _status.value = updated
            updated
        }
    }

    suspend fun executeRootCommand(command: String): ShellResult = withContext(Dispatchers.IO) {
        try {
            val pb = ProcessBuilder("su", "-c", command)
            val process = pb.start()
            val finished = process.waitFor(4500, TimeUnit.MILLISECONDS)
            if (!finished) {
                process.destroyForcibly()
                return@withContext ShellResult(-1, "", "Root command timed out")
            }
            val out = process.inputStream.bufferedReader().readText().trim()
            val err = process.errorStream.bufferedReader().readText().trim()
            val code = process.exitValue()
            _status.value = _status.value.copy(
                lastCommandOutput = out.ifBlank { err },
                lastError = if (code != 0) err.ifBlank { "Exit code $code" } else null
            )
            ShellResult(code, out, err)
        } catch (e: Exception) {
            val msg = e.message ?: "Failed to invoke su binary"
            _status.value = _status.value.copy(lastError = msg)
            ShellResult(-1, "", msg)
        }
    }

    suspend fun setCpuGovernor(governor: String): ShellResult {
        if (!_status.value.isAuthorized) {
            return ShellResult(-1, "", "Root access is not authorized")
        }
        if (_status.value.originalGovernorBackup == null) {
            val orig = readCurrentGovernorRoot()
            if (orig != "Unknown") {
                _status.value = _status.value.copy(originalGovernorBackup = orig)
            }
        }
        val safeGov = governor.replace(Regex("[^a-zA-Z0-9_-]"), "")
        val cmd = "for f in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo $safeGov > \"\$f\" 2>/dev/null; done; cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor"
        val res = executeRootCommand(cmd)
        if (res.isSuccess && res.stdout.isNotBlank()) {
            _status.value = _status.value.copy(currentGovernor = res.stdout.lines().first().trim())
        }
        return res
    }

    suspend fun applySystemRefreshRate(hz: Int): ShellResult {
        if (!_status.value.isAuthorized) return ShellResult(-1, "", "Root not authorized")
        if (savedPeakRefresh == null) {
            savedPeakRefresh = executeRootCommand("settings get system peak_refresh_rate").stdout
            savedMinRefresh = executeRootCommand("settings get system min_refresh_rate").stdout
        }
        val cmd = if (hz <= 0) {
            "settings delete system peak_refresh_rate; settings delete system min_refresh_rate"
        } else {
            "settings put system peak_refresh_rate ${hz}.0 && settings put system min_refresh_rate ${hz}.0"
        }
        return executeRootCommand(cmd)
    }

    suspend fun setAnimationScales(scale: Float): ShellResult {
        if (!_status.value.isAuthorized) return ShellResult(-1, "", "Root not authorized")
        if (savedAnimWindow == null) {
            savedAnimWindow = executeRootCommand("settings get global window_animation_scale").stdout
            savedAnimTrans = executeRootCommand("settings get global transition_animation_scale").stdout
            savedAnimDuration = executeRootCommand("settings get global animator_duration_scale").stdout
        }
        val s = scale.coerceIn(0f, 1.5f)
        return executeRootCommand(
            "settings put global window_animation_scale $s && " +
                "settings put global transition_animation_scale $s && " +
                "settings put global animator_duration_scale $s"
        )
    }

    suspend fun restoreOriginalSettings(): ShellResult {
        if (!_status.value.isAuthorized) {
            return ShellResult(-1, "", "Root access is not authorized")
        }
        val cmds = mutableListOf<String>()
        _status.value.originalGovernorBackup?.let { origGov ->
            val safe = origGov.replace(Regex("[^a-zA-Z0-9_-]"), "")
            cmds.add("for f in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo $safe > \"\$f\" 2>/dev/null; done")
        }
        savedPeakRefresh?.let { peak ->
            if (peak == "null" || peak.isBlank()) cmds.add("settings delete system peak_refresh_rate")
            else cmds.add("settings put system peak_refresh_rate $peak")
        }
        savedMinRefresh?.let { min ->
            if (min == "null" || min.isBlank()) cmds.add("settings delete system min_refresh_rate")
            else cmds.add("settings put system min_refresh_rate $min")
        }
        savedAnimWindow?.takeIf { it.isNotBlank() && it != "null" }?.let {
            cmds.add("settings put global window_animation_scale $it")
        }
        savedAnimTrans?.takeIf { it.isNotBlank() && it != "null" }?.let {
            cmds.add("settings put global transition_animation_scale $it")
        }
        savedAnimDuration?.takeIf { it.isNotBlank() && it != "null" }?.let {
            cmds.add("settings put global animator_duration_scale $it")
        }
        if (cmds.isEmpty()) {
            return ShellResult(0, "No modified system settings to restore.", "")
        }
        val res = executeRootCommand(cmds.joinToString("; "))
        val refreshedGov = readCurrentGovernorRoot()
        _status.value = _status.value.copy(currentGovernor = refreshedGov)
        return res
    }

    private suspend fun readGovernorsRoot(): List<String> {
        val res = executeRootCommand("cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors 2>/dev/null")
        return res.stdout.split(Regex("\\s+")).filter { it.isNotBlank() }
    }

    private suspend fun readCurrentGovernorRoot(): String {
        val res = executeRootCommand("cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null")
        return res.stdout.lines().firstOrNull()?.trim()?.takeIf { it.isNotBlank() } ?: "Unknown"
    }

    private fun isPackageInstalled(pkg: String): Boolean {
        return runCatching {
            context.packageManager.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0))
            true
        }.getOrElse {
            runCatching {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(pkg, 0)
                true
            }.getOrDefault(false)
        }
    }
}
