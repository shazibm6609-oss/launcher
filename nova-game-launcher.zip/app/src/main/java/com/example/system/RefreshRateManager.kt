package com.example.system

import android.app.Activity
import android.content.Context
import android.hardware.display.DisplayManager
import android.os.Build
import android.provider.Settings
import android.view.Choreographer
import android.view.Display
import com.example.model.OperatingMode
import com.example.model.RefreshRateSnapshot
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.roundToInt

class RefreshRateManager(
    private val context: Context,
    private val rootManager: RootManager,
    private val shizukuManager: ShizukuManager
) {
    private val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
    private val _snapshot = MutableStateFlow(RefreshRateSnapshot())
    val snapshot: StateFlow<RefreshRateSnapshot> = _snapshot.asStateFlow()

    private var frameCount = 0
    private var lastMeasureNanos = 0L
    private var isMonitoringFps = false

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!isMonitoringFps) return
            if (lastMeasureNanos == 0L) {
                lastMeasureNanos = frameTimeNanos
                frameCount = 0
            } else {
                frameCount++
                val elapsed = frameTimeNanos - lastMeasureNanos
                if (elapsed >= 500_000_000L) {
                    val fps = (frameCount * 1_000_000_000f) / elapsed.toFloat()
                    _snapshot.value = _snapshot.value.copy(measuredFps = fps)
                    frameCount = 0
                    lastMeasureNanos = frameTimeNanos
                }
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    fun startFpsMonitor() {
        if (isMonitoringFps) return
        isMonitoringFps = true
        lastMeasureNanos = 0L
        Choreographer.getInstance().postFrameCallback(frameCallback)
        refreshHardwareDisplayInfo()
    }

    fun stopFpsMonitor() {
        isMonitoringFps = false
        Choreographer.getInstance().removeFrameCallback(frameCallback)
    }

    fun refreshHardwareDisplayInfo(selectedTargetHz: Int = _snapshot.value.selectedTargetHz) {
        val display = getPrimaryDisplay()
        val modes = display?.supportedModes ?: emptyArray()
        val supportedRates = modes.map { it.refreshRate.roundToInt() }.distinct().sorted()
        val activeHz = display?.mode?.refreshRate ?: 60f
        val peakSetting = runCatching {
            Settings.System.getFloat(context.contentResolver, "peak_refresh_rate")
        }.getOrNull()

        val canSystemWide = rootManager.status.value.isAuthorized ||
            (shizukuManager.status.value.isBinderAlive && shizukuManager.status.value.isPermissionGranted)

        _snapshot.value = _snapshot.value.copy(
            currentHz = activeHz,
            supportedRatesHz = if (supportedRates.isEmpty()) listOf(60) else supportedRates,
            isAutoMode = selectedTargetHz <= 0,
            selectedTargetHz = selectedTargetHz,
            systemPeakRateSetting = peakSetting,
            canApplySystemWide = canSystemWide
        )
    }

    suspend fun applyRefreshRate(
        activity: Activity?,
        targetHz: Int,
        operatingMode: OperatingMode
    ): Result<String> {
        val display = getPrimaryDisplay()
        val modes = display?.supportedModes ?: emptyArray()
        val supportedRates = modes.map { it.refreshRate.roundToInt() }.distinct()

        if (targetHz > 0 && targetHz !in supportedRates) {
            return Result.failure(IllegalArgumentException("${targetHz} Hz is not supported by this display hardware."))
        }

        // 1. Apply to Nova app window immediately via preferredDisplayModeId
        if (activity != null && Build.VERSION.SDK_INT >= 23) {
            val lp = activity.window.attributes
            if (targetHz <= 0) {
                lp.preferredDisplayModeId = 0
            } else {
                val matchingMode = modes
                    .filter { it.refreshRate.roundToInt() == targetHz }
                    .maxByOrNull { it.physicalWidth * it.physicalHeight }
                if (matchingMode != null) {
                    lp.preferredDisplayModeId = matchingMode.modeId
                }
            }
            activity.runOnUiThread {
                activity.window.attributes = lp
            }
        }

        // 2. Apply system-wide if Root or Shizuku is authorized
        var sysOutcome = "Applied to launcher window"
        val useRootFirst = (operatingMode == OperatingMode.ROOT) ||
            (operatingMode == OperatingMode.AUTO && rootManager.status.value.isAuthorized)
        val canShizuku = shizukuManager.status.value.isBinderAlive && shizukuManager.status.value.isPermissionGranted

        if (operatingMode != OperatingMode.STANDARD) {
            if (useRootFirst && rootManager.status.value.isAuthorized) {
                val res = rootManager.applySystemRefreshRate(targetHz)
                sysOutcome = if (res.isSuccess) "Applied system-wide via Magisk Root (${if (targetHz <= 0) "Auto" else "$targetHz Hz"})"
                else "Window updated; Root system write failed: ${res.stderr}"
            } else if (canShizuku) {
                val res = shizukuManager.applySystemRefreshRate(targetHz)
                sysOutcome = if (res.isSuccess) "Applied system-wide via Shizuku (${if (targetHz <= 0) "Auto" else "$targetHz Hz"})"
                else "Window updated; Shizuku system write failed: ${res.stderr}"
            }
        }

        refreshHardwareDisplayInfo(targetHz)
        return Result.success(sysOutcome)
    }

    suspend fun restoreOriginalRefreshRate(activity: Activity?, operatingMode: OperatingMode): String {
        val res = applyRefreshRate(activity, 0, operatingMode)
        if (rootManager.status.value.isAuthorized) {
            rootManager.restoreOriginalSettings()
        } else if (shizukuManager.status.value.isBinderAlive && shizukuManager.status.value.isPermissionGranted) {
            shizukuManager.restoreOriginalSettings()
        }
        refreshHardwareDisplayInfo(0)
        return res.getOrDefault("Restored to Auto refresh rate")
    }

    private fun getPrimaryDisplay(): Display? {
        return displayManager.getDisplay(Display.DEFAULT_DISPLAY)
    }
}
