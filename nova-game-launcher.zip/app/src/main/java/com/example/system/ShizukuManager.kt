package com.example.system

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import android.os.Process
import androidx.annotation.Keep
import com.example.BuildConfig
import com.example.model.ShizukuStatus
import com.example.shizuku.INovaShizukuService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.util.concurrent.TimeUnit
import kotlin.system.exitProcess

@Keep
class NovaShizukuUserService : INovaShizukuService.Stub {
    @Suppress("unused")
    constructor()

    @Suppress("unused")
    constructor(@Suppress("UNUSED_PARAMETER") context: Context)

    override fun destroy() {
        exitProcess(0)
    }

    override fun runShell(command: String): String {
        return try {
            val pb = ProcessBuilder("sh", "-c", command)
            val proc = pb.start()
            val done = proc.waitFor(4500, TimeUnit.MILLISECONDS)
            if (!done) {
                proc.destroyForcibly()
                return "ERR:TIMEOUT"
            }
            val out = proc.inputStream.bufferedReader().readText().trim()
            val err = proc.errorStream.bufferedReader().readText().trim()
            val code = proc.exitValue()
            if (code == 0) out else "ERR($code): ${err.ifBlank { out }}"
        } catch (e: Exception) {
            "ERR: ${e.message ?: "Execution failed"}"
        }
    }

    override fun getProcessUid(): Int = Process.myUid()
}

class ShizukuManager(private val context: Context) {
    companion object {
        const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
        private const val REQ_CODE_SHIZUKU = 8412
    }

    private val _status = MutableStateFlow(ShizukuStatus())
    val status: StateFlow<ShizukuStatus> = _status.asStateFlow()

    private var userService: INovaShizukuService? = null

    private var savedPeakRefresh: String? = null
    private var savedMinRefresh: String? = null
    private var savedAnimWindow: String? = null
    private var savedAnimTrans: String? = null
    private var savedAnimDuration: String? = null

    private val userServiceArgs by lazy {
        Shizuku.UserServiceArgs(
            ComponentName(context.packageName, NovaShizukuUserService::class.java.name)
        )
            .daemon(false)
            .processNameSuffix("shizuku_service")
            .debuggable(BuildConfig.DEBUG)
            .version(BuildConfig.VERSION_CODE)
    }

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            if (service != null && service.pingBinder()) {
                userService = INovaShizukuService.Stub.asInterface(service)
                _status.value = _status.value.copy(
                    lastCommandOutput = "Shizuku UserService connected (UID ${runCatching { userService?.processUid }.getOrNull() ?: "?"})",
                    lastError = null
                )
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            userService = null
        }
    }

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        refreshStatus()
        if (hasPermission()) {
            bindUserService()
        }
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        userService = null
        refreshStatus()
    }

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == REQ_CODE_SHIZUKU) {
            val granted = grantResult == PackageManager.PERMISSION_GRANTED
            refreshStatus()
            if (granted) {
                bindUserService()
            } else {
                _status.value = _status.value.copy(
                    lastError = "Shizuku permission denied by user."
                )
            }
        }
    }

    fun registerListeners() {
        runCatching {
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
            Shizuku.addBinderDeadListener(binderDeadListener)
            Shizuku.addRequestPermissionResultListener(permissionListener)
        }
        refreshStatus()
    }

    fun unregisterListeners() {
        runCatching {
            Shizuku.removeBinderReceivedListener(binderReceivedListener)
            Shizuku.removeBinderDeadListener(binderDeadListener)
            Shizuku.removeRequestPermissionResultListener(permissionListener)
            Shizuku.unbindUserService(userServiceArgs, serviceConnection, true)
        }
    }

    fun refreshStatus(): ShizukuStatus {
        val installed = isShizukuAppInstalled()
        val alive = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
        val granted = if (alive) hasPermission() else false
        val version = if (alive) runCatching { Shizuku.getVersion() }.getOrDefault(-1) else -1
        val uid = if (alive) runCatching { Shizuku.getUid() }.getOrDefault(-1) else -1

        val current = _status.value.copy(
            isInstalled = installed,
            isBinderAlive = alive,
            isPermissionGranted = granted,
            shizukuVersion = version,
            shizukuUid = uid
        )
        _status.value = current
        if (alive && granted && userService == null) {
            bindUserService()
        }
        return current
    }

    fun requestPermission() {
        val alive = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
        if (!alive) {
            _status.value = _status.value.copy(
                lastError = "Shizuku service is not running. Start Shizuku via Wireless Debugging or Root first."
            )
            return
        }
        if (hasPermission()) {
            bindUserService()
            refreshStatus()
            return
        }
        if (Shizuku.isPreV11()) {
            _status.value = _status.value.copy(lastError = "Shizuku v11+ required.")
            return
        }
        Shizuku.requestPermission(REQ_CODE_SHIZUKU)
    }

    fun openShizukuApp(): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(SHIZUKU_PACKAGE) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return runCatching {
            context.startActivity(intent)
            true
        }.getOrDefault(false)
    }

    private fun bindUserService() {
        runCatching {
            Shizuku.bindUserService(userServiceArgs, serviceConnection)
        }.onFailure { e ->
            _status.value = _status.value.copy(lastError = "Failed to bind Shizuku UserService: ${e.message}")
        }
    }

    suspend fun runPrivilegedCommand(command: String): ShellResult = withContext(Dispatchers.IO) {
        val alive = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
        if (!alive || !hasPermission()) {
            val msg = "Shizuku service not active or unauthorized"
            _status.value = _status.value.copy(lastError = msg)
            return@withContext ShellResult(-1, "", msg)
        }
        val svc = userService
        if (svc == null) {
            bindUserService()
            val msg = "Shizuku UserService is connecting — tap again in a moment"
            _status.value = _status.value.copy(lastError = msg)
            return@withContext ShellResult(-1, "", msg)
        }
        return@withContext try {
            val output = svc.runShell(command)
            if (output.startsWith("ERR")) {
                _status.value = _status.value.copy(lastCommandOutput = output, lastError = output)
                ShellResult(1, "", output)
            } else {
                _status.value = _status.value.copy(lastCommandOutput = output, lastError = null)
                ShellResult(0, output, "")
            }
        } catch (e: Exception) {
            val msg = e.message ?: "Shizuku binder call failed"
            _status.value = _status.value.copy(lastError = msg)
            ShellResult(-1, "", msg)
        }
    }

    suspend fun setGameMode(packageName: String, mode: String): ShellResult {
        if (Build.VERSION.SDK_INT < 31) {
            return ShellResult(-1, "", "Android 12+ required for cmd game mode")
        }
        val safePkg = packageName.replace(Regex("[^a-zA-Z0-9._]"), "")
        val safeMode = mode.replace(Regex("[^a-zA-Z0-9_-]"), "")
        return runPrivilegedCommand("cmd game mode $safeMode $safePkg")
    }

    suspend fun applySystemRefreshRate(hz: Int): ShellResult {
        if (savedPeakRefresh == null) {
            savedPeakRefresh = runPrivilegedCommand("settings get system peak_refresh_rate").stdout
            savedMinRefresh = runPrivilegedCommand("settings get system min_refresh_rate").stdout
        }
        val cmd = if (hz <= 0) {
            "settings delete system peak_refresh_rate; settings delete system min_refresh_rate"
        } else {
            "settings put system peak_refresh_rate ${hz}.0 && settings put system min_refresh_rate ${hz}.0"
        }
        return runPrivilegedCommand(cmd)
    }

    suspend fun setAnimationScales(scale: Float): ShellResult {
        if (savedAnimWindow == null) {
            savedAnimWindow = runPrivilegedCommand("settings get global window_animation_scale").stdout
            savedAnimTrans = runPrivilegedCommand("settings get global transition_animation_scale").stdout
            savedAnimDuration = runPrivilegedCommand("settings get global animator_duration_scale").stdout
        }
        val s = scale.coerceIn(0f, 1.5f)
        return runPrivilegedCommand(
            "settings put global window_animation_scale $s && " +
                "settings put global transition_animation_scale $s && " +
                "settings put global animator_duration_scale $s"
        )
    }

    suspend fun restoreOriginalSettings(): ShellResult {
        val cmds = mutableListOf<String>()
        savedPeakRefresh?.let { peak ->
            if (peak == "null" || peak.isBlank()) cmds.add("settings delete system peak_refresh_rate")
            else cmds.add("settings put system peak_refresh_rate $peak")
        }
        savedMinRefresh?.let { min ->
            if (min == "null" || min.isBlank()) cmds.add("settings delete system min_refresh_rate")
            else cmds.add("settings put system min_refresh_rate $min")
        }
        savedAnimWindow?.takeIf { it.isNotBlank() && it != "null" }?.let {
            cmds.add("settings put global window_animation_scale $it")
        }
        savedAnimTrans?.takeIf { it.isNotBlank() && it != "null" }?.let {
            cmds.add("settings put global transition_animation_scale $it")
        }
        savedAnimDuration?.takeIf { it.isNotBlank() && it != "null" }?.let {
            cmds.add("settings put global animator_duration_scale $it")
        }
        if (cmds.isEmpty()) {
            return ShellResult(0, "No modified Shizuku settings to restore.", "")
        }
        return runPrivilegedCommand(cmds.joinToString("; "))
    }

    private fun hasPermission(): Boolean {
        return runCatching {
            !Shizuku.isPreV11() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        }.getOrDefault(false)
    }

    private fun isShizukuAppInstalled(): Boolean {
        return runCatching {
            context.packageManager.getPackageInfo(SHIZUKU_PACKAGE, PackageManager.PackageInfoFlags.of(0))
            true
        }.getOrElse {
            runCatching {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(SHIZUKU_PACKAGE, 0)
                true
            }.getOrDefault(false)
        }
    }
}
