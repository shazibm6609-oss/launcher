package com.example.model

import kotlinx.serialization.Serializable

enum class CharacterMode(val code: Int, val label: String) {
    NATURAL(0, "Natural / Formant"),
    ROBOT(1, "Robot Carrier"),
    ALIEN(2, "Alien FM"),
    RADIO(3, "Comms Radio")
}

enum class VoiceCategory {
    FEMALE,
    BABY,
    CHARACTER,
    CUSTOM
}

@Serializable
data class VoiceParameters(
    val pitchSemitones: Float = 0.0f,       // -12f .. +12f
    val formantShift: Float = 1.0f,         // 0.65f .. 1.45f
    val brightness: Float = 0.0f,           // -1f .. +1f
    val softness: Float = 0.0f,             // 0f .. 1f
    val tone: Float = 0.0f,                 // -1f .. +1f
    val cartoonTone: Float = 0.0f,          // 0f .. 1f
    val effectIntensity: Float = 1.0f,      // 0f .. 1f
    val noiseReduction: Boolean = true,
    val eqBassDb: Float = 0.0f,             // -12f .. +12f
    val eqMidDb: Float = 0.0f,              // -12f .. +12f
    val eqTrebleDb: Float = 0.0f,           // -12f .. +12f
    val echoAmount: Float = 0.0f,           // 0f .. 1f
    val reverbAmount: Float = 0.0f,         // 0f .. 1f
    val inputGain: Float = 1.0f,            // 0.2f .. 2.5f
    val outputGain: Float = 1.0f,           // 0.2f .. 2.5f
    val characterMode: Int = CharacterMode.NATURAL.code
)

@Serializable
data class VoicePreset(
    val id: String,
    val name: String,
    val category: VoiceCategory,
    val description: String,
    val isBuiltIn: Boolean = true,
    val params: VoiceParameters
)

object BuiltInVoicePresets {
    val ALL: List<VoicePreset> = listOf(
        VoicePreset(
            id = "natural_female",
            name = "Natural Female",
            category = VoiceCategory.FEMALE,
            description = "Warm natural feminine pitch (+4.5 st) & lifted vocal tract formants (1.18x)",
            params = VoiceParameters(
                pitchSemitones = 4.5f,
                formantShift = 1.18f,
                brightness = 0.28f,
                softness = 0.42f,
                tone = 0.15f,
                cartoonTone = 0.0f,
                effectIntensity = 0.95f,
                noiseReduction = true,
                eqBassDb = -2.5f,
                eqMidDb = 1.5f,
                eqTrebleDb = 2.0f
            )
        ),
        VoicePreset(
            id = "cute_female",
            name = "Cute Female",
            category = VoiceCategory.FEMALE,
            description = "Sweet airy feminine voice (+5.8 st) with silky softness & bright air",
            params = VoiceParameters(
                pitchSemitones = 5.8f,
                formantShift = 1.24f,
                brightness = 0.45f,
                softness = 0.58f,
                tone = 0.25f,
                cartoonTone = 0.15f,
                effectIntensity = 1.0f,
                noiseReduction = true,
                eqBassDb = -3.5f,
                eqMidDb = 2.0f,
                eqTrebleDb = 3.0f
            )
        ),
        VoicePreset(
            id = "anime_voice",
            name = "Anime-style Voice",
            category = VoiceCategory.FEMALE,
            description = "Expressive bright anime timbre (+6.5 st, 1.28x formant, crisp presence)",
            params = VoiceParameters(
                pitchSemitones = 6.5f,
                formantShift = 1.28f,
                brightness = 0.60f,
                softness = 0.30f,
                tone = 0.35f,
                cartoonTone = 0.32f,
                effectIntensity = 1.0f,
                noiseReduction = true,
                eqBassDb = -4.0f,
                eqMidDb = 2.5f,
                eqTrebleDb = 3.5f
            )
        ),
        VoicePreset(
            id = "baby_cartoon",
            name = "Baby Cartoon",
            category = VoiceCategory.BABY,
            description = "Playful child-like voice (+8.5 st) with high formant lift & cartoon resonance",
            params = VoiceParameters(
                pitchSemitones = 8.5f,
                formantShift = 1.36f,
                brightness = 0.65f,
                softness = 0.40f,
                tone = 0.42f,
                cartoonTone = 0.72f,
                effectIntensity = 1.0f,
                noiseReduction = true,
                eqBassDb = -5.5f,
                eqMidDb = 3.5f,
                eqTrebleDb = 4.0f
            )
        ),
        VoicePreset(
            id = "cartoon_character",
            name = "Cartoon Character",
            category = VoiceCategory.BABY,
            description = "Bouncy animated toon character (+7.0 st) with pronounced nasal brightness",
            params = VoiceParameters(
                pitchSemitones = 7.0f,
                formantShift = 1.30f,
                brightness = 0.55f,
                softness = 0.15f,
                tone = 0.48f,
                cartoonTone = 0.85f,
                effectIntensity = 1.0f,
                noiseReduction = true,
                eqBassDb = -4.5f,
                eqMidDb = 4.0f,
                eqTrebleDb = 2.5f
            )
        ),
        VoicePreset(
            id = "deep_male",
            name = "Deep Male",
            category = VoiceCategory.CHARACTER,
            description = "Rich bass-heavy baritone (-4.2 st) with lowered chest formants",
            params = VoiceParameters(
                pitchSemitones = -4.2f,
                formantShift = 0.84f,
                brightness = -0.15f,
                softness = 0.20f,
                tone = -0.35f,
                cartoonTone = 0.0f,
                effectIntensity = 1.0f,
                noiseReduction = true,
                eqBassDb = 4.5f,
                eqMidDb = -1.0f,
                eqTrebleDb = -1.5f
            )
        ),
        VoicePreset(
            id = "monster_voice",
            name = "Monster Voice",
            category = VoiceCategory.CHARACTER,
            description = "Massive menacing beast (-7.5 st, 0.72x formant) with dark cavern reverb",
            params = VoiceParameters(
                pitchSemitones = -7.5f,
                formantShift = 0.72f,
                brightness = -0.45f,
                softness = 0.0f,
                tone = -0.60f,
                cartoonTone = 0.0f,
                effectIntensity = 1.0f,
                noiseReduction = true,
                eqBassDb = 7.0f,
                eqMidDb = 1.0f,
                eqTrebleDb = -3.5f,
                reverbAmount = 0.45f
            )
        ),
        VoicePreset(
            id = "robot_voice",
            name = "Robot Voice",
            category = VoiceCategory.CHARACTER,
            description = "Synthetic cyber-droid carrier modulation + metallic comb resonator",
            params = VoiceParameters(
                pitchSemitones = -1.0f,
                formantShift = 0.96f,
                brightness = 0.25f,
                softness = 0.0f,
                tone = 0.20f,
                cartoonTone = 0.0f,
                effectIntensity = 1.0f,
                noiseReduction = true,
                characterMode = CharacterMode.ROBOT.code
            )
        ),
        VoicePreset(
            id = "alien_voice",
            name = "Alien Voice",
            category = VoiceCategory.CHARACTER,
            description = "Extraterrestrial FM ring modulation (+2.5 st) with space echo",
            params = VoiceParameters(
                pitchSemitones = 2.5f,
                formantShift = 1.15f,
                brightness = 0.35f,
                softness = 0.0f,
                tone = 0.15f,
                cartoonTone = 0.20f,
                effectIntensity = 1.0f,
                noiseReduction = true,
                echoAmount = 0.30f,
                reverbAmount = 0.35f,
                characterMode = CharacterMode.ALIEN.code
            )
        ),
        VoicePreset(
            id = "radio_voice",
            name = "Radio Voice",
            category = VoiceCategory.CHARACTER,
            description = "Tactical squad walkie-talkie bandpass with crisp saturation",
            params = VoiceParameters(
                pitchSemitones = 0.0f,
                formantShift = 1.0f,
                brightness = 0.20f,
                softness = 0.0f,
                tone = 0.40f,
                cartoonTone = 0.0f,
                effectIntensity = 1.0f,
                noiseReduction = true,
                eqBassDb = -6.0f,
                eqMidDb = 5.0f,
                eqTrebleDb = -3.0f,
                characterMode = CharacterMode.RADIO.code
            )
        ),
        VoicePreset(
            id = "echo_voice",
            name = "Echo Voice",
            category = VoiceCategory.CHARACTER,
            description = "Stadium announcer echo + atmospheric hall reverb",
            params = VoiceParameters(
                pitchSemitones = 0.0f,
                formantShift = 1.02f,
                brightness = 0.20f,
                softness = 0.20f,
                tone = 0.10f,
                cartoonTone = 0.0f,
                effectIntensity = 0.90f,
                noiseReduction = true,
                echoAmount = 0.62f,
                reverbAmount = 0.58f
            )
        ),
        VoicePreset(
            id = "custom_voice",
            name = "Custom Voice",
            category = VoiceCategory.CUSTOM,
            description = "User-tuned studio voice profile with unrestricted DSP sliders",
            params = VoiceParameters(
                pitchSemitones = 4.0f,
                formantShift = 1.15f,
                brightness = 0.20f,
                softness = 0.30f,
                tone = 0.10f,
                cartoonTone = 0.0f,
                effectIntensity = 1.0f,
                noiseReduction = true
            )
        )
    )

    val FEMALE_SUB_PRESETS: List<VoicePreset> = listOf(
        ALL[0], // Natural Female
        ALL[1], // Cute Female
        ALL[2], // Anime-style Voice
        VoicePreset(
            id = "soft_streamer_female",
            name = "Soft Streamer",
            category = VoiceCategory.FEMALE,
            description = "Silky low-breathiness feminine streamer profile (+4.0 st, 1.15x formant)",
            params = VoiceParameters(
                pitchSemitones = 4.0f,
                formantShift = 1.15f,
                brightness = 0.22f,
                softness = 0.72f,
                tone = 0.10f,
                effectIntensity = 0.92f,
                noiseReduction = true,
                eqBassDb = -2.0f,
                eqMidDb = 1.0f,
                eqTrebleDb = 2.5f,
                reverbAmount = 0.12f
            )
        )
    )

    val BABY_SUB_PRESETS: List<VoicePreset> = listOf(
        ALL[3], // Baby Cartoon
        ALL[4], // Cartoon Character
        VoicePreset(
            id = "funny_squeaky_baby",
            name = "Funny Baby",
            category = VoiceCategory.BABY,
            description = "Ultra-playful comedic mini-toon effect (+9.5 st, 1.40x formant)",
            params = VoiceParameters(
                pitchSemitones = 9.5f,
                formantShift = 1.40f,
                brightness = 0.75f,
                softness = 0.25f,
                tone = 0.50f,
                cartoonTone = 0.90f,
                effectIntensity = 1.0f,
                noiseReduction = true,
                eqBassDb = -6.0f,
                eqMidDb = 4.5f,
                eqTrebleDb = 4.5f
            )
        )
    )
}

data class AudioDeviceEntry(
    val id: Int,
    val name: String,
    val typeLabel: String,
    val isInput: Boolean,
    val isWiredOrUsb: Boolean
)

data class AudioRoutingStatus(
    val activeEngine: String = "Standby",
    val sampleRateHz: Int = 48000,
    val latencyMs: Float = 0f,
    val dspCpuUs: Int = 0,
    val inputDeviceName: String = "Default Microphone",
    val outputDeviceName: String = "Default Output",
    val wiredOrUsbConnected: Boolean = false,
    val gameMicInjectionSupported: Boolean = false,
    val routingSummary: String = "Standby — tap Mic to start live processing",
    val routingLimitationNote: String =
        "Android isolates app microphone capture for security. Without root audio-loopback kernel modules or an external USB/TRRS hardware mixer, external games (e.g., Free Fire) capture the hardware microphone directly while Nova monitors/previews processed audio locally."
)

data class VoiceEngineMetrics(
    val isProcessing: Boolean = false,
    val isRecordingSample: Boolean = false,
    val isPlayingRecordedPreview: Boolean = false,
    val hasRecordedSample: Boolean = false,
    val recordedDurationSec: Float = 0f,
    val inputDb: Float = -60f,
    val outputDb: Float = -60f,
    val peakDb: Float = -60f,
    val waveform: List<Float> = List(48) { 0f }
)

enum class PerformanceMode(val label: String, val description: String) {
    BALANCED("Balanced", "Standard clocks and adaptive thermal behavior"),
    PERFORMANCE("Performance", "Boosted responsiveness and reduced UI animation overhead"),
    GAMING("Gaming Mode", "GameManager performance hint + minimized background jitter"),
    BATTERY_SAVER("Battery Saver", "Lower CPU target & conservative refresh rate"),
    CUSTOM("Custom Mode", "User-configured governor, refresh rate, and animation scales")
}

data class DeviceTelemetry(
    val cpuUsagePercent: Float? = null,
    val cpuFrequenciesMhz: List<Int> = emptyList(),
    val cpuGovernor: String = "Unavailable",
    val ramUsedMb: Long = 0,
    val ramTotalMb: Long = 0,
    val ramPercent: Float = 0f,
    val batteryLevel: Int = 0,
    val batteryCharging: Boolean = false,
    val deviceTempCelsius: Float = 0f,
    val thermalStatusLabel: String = "Normal",
    val isThermalThrottling: Boolean = false,
    val currentFps: Float = 0f
)

@Serializable
data class SensitivityProfile(
    val id: String,
    val name: String,
    val general: Int = 95,
    val redDot: Int = 88,
    val scope2x: Int = 76,
    val scope4x: Int = 64,
    val sniperScope: Int = 48,
    val freeLook: Int = 80,
    val linkedPackage: String? = null,
    val updatedAt: Long = System.currentTimeMillis()
)

data class InstalledGame(
    val packageName: String,
    val label: String,
    val isDetectedGame: Boolean,
    val isFavorite: Boolean = false,
    val isManuallyAdded: Boolean = false,
    val voicePresetId: String? = null,
    val performanceMode: PerformanceMode = PerformanceMode.GAMING,
    val targetRefreshRateHz: Int = 0, // 0 = Auto
    val sensitivityProfileId: String? = null
)

data class RefreshRateSnapshot(
    val currentHz: Float = 60f,
    val measuredFps: Float = 60f,
    val supportedRatesHz: List<Int> = listOf(60),
    val isAutoMode: Boolean = true,
    val selectedTargetHz: Int = 0,
    val systemPeakRateSetting: Float? = null,
    val canApplySystemWide: Boolean = false
)

enum class OperatingMode(val label: String) {
    AUTO("Auto (Root -> Shizuku -> Standard)"),
    ROOT("Magisk Root Priority"),
    SHIZUKU("Shizuku API Priority"),
    STANDARD("Standard Non-Privileged")
}

data class RootStatus(
    val magiskDetected: Boolean = false,
    val magiskVersion: String = "Not Detected",
    val suBinaryPath: String? = null,
    val isAuthorized: Boolean = false,
    val uidInfo: String = "Unverified",
    val availableGovernors: List<String> = emptyList(),
    val currentGovernor: String = "Unknown",
    val originalGovernorBackup: String? = null,
    val lastCommandOutput: String = "",
    val lastError: String? = null
)

data class ShizukuStatus(
    val isInstalled: Boolean = false,
    val isBinderAlive: Boolean = false,
    val isPermissionGranted: Boolean = false,
    val shizukuVersion: Int = -1,
    val shizukuUid: Int = -1,
    val lastCommandOutput: String = "",
    val lastError: String? = null
)
