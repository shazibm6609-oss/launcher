package com.example.audio

import com.example.model.VoiceParameters

object NativeVoiceBridge {
    val isNativeLoaded: Boolean = try {
        System.loadLibrary("nova_dsp")
        true
    } catch (_: UnsatisfiedLinkError) {
        false
    } catch (_: SecurityException) {
        false
    }

    external fun nativeStart(
        inputDeviceId: Int,
        outputDeviceId: Int,
        sampleRate: Int,
        framesPerBurst: Int
    ): Boolean

    external fun nativeStop()
    external fun nativeIsRunning(): Boolean

    external fun nativeUpdateParams(
        effectEnabled: Boolean,
        bypassOriginal: Boolean,
        pitchSemitones: Float,
        formantShift: Float,
        brightness: Float,
        softness: Float,
        tone: Float,
        cartoonTone: Float,
        effectIntensity: Float,
        noiseReduction: Boolean,
        eqBassDb: Float,
        eqMidDb: Float,
        eqTrebleDb: Float,
        echoAmount: Float,
        reverbAmount: Float,
        inputGain: Float,
        outputGain: Float,
        characterMode: Int
    )

    external fun nativeGetMetrics(): FloatArray
    external fun nativeGetAudioApi(): String
    external fun nativeGetWaveform(outWave: FloatArray)
    external fun nativePrepareOffline(sampleRate: Float)
    external fun nativeProcessOffline(
        inputArr: FloatArray,
        outputArr: FloatArray,
        effectEnabled: Boolean,
        bypassOriginal: Boolean,
        pitchSemitones: Float,
        formantShift: Float,
        brightness: Float,
        softness: Float,
        tone: Float,
        cartoonTone: Float,
        effectIntensity: Float,
        noiseReduction: Boolean,
        eqBassDb: Float,
        eqMidDb: Float,
        eqTrebleDb: Float,
        echoAmount: Float,
        reverbAmount: Float,
        inputGain: Float,
        outputGain: Float,
        characterMode: Int
    )

    fun pushParams(effectEnabled: Boolean, bypassOriginal: Boolean, p: VoiceParameters) {
        if (!isNativeLoaded) return
        nativeUpdateParams(
            effectEnabled = effectEnabled,
            bypassOriginal = bypassOriginal,
            pitchSemitones = p.pitchSemitones,
            formantShift = p.formantShift,
            brightness = p.brightness,
            softness = p.softness,
            tone = p.tone,
            cartoonTone = p.cartoonTone,
            effectIntensity = p.effectIntensity,
            noiseReduction = p.noiseReduction,
            eqBassDb = p.eqBassDb,
            eqMidDb = p.eqMidDb,
            eqTrebleDb = p.eqTrebleDb,
            echoAmount = p.echoAmount,
            reverbAmount = p.reverbAmount,
            inputGain = p.inputGain,
            outputGain = p.outputGain,
            characterMode = p.characterMode
        )
    }
}
