package com.example.audio

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import com.example.model.AudioDeviceEntry
import java.io.File

class AudioDeviceRouter(private val context: Context) {
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    fun getInputDevices(): List<AudioDeviceEntry> {
        val devices = audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS)
        val result = mutableListOf(
            AudioDeviceEntry(
                id = 0,
                name = "System Default Mic",
                typeLabel = "Auto",
                isInput = true,
                isWiredOrUsb = false
            )
        )
        devices.forEach { dev ->
            val typeLabel = mapDeviceType(dev.type)
            val isExternal = dev.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                dev.type == AudioDeviceInfo.TYPE_USB_DEVICE ||
                dev.type == AudioDeviceInfo.TYPE_USB_HEADSET ||
                dev.type == AudioDeviceInfo.TYPE_USB_ACCESSORY
            val label = dev.productName?.toString()?.takeIf { it.isNotBlank() } ?: typeLabel
            result.add(
                AudioDeviceEntry(
                    id = dev.id,
                    name = "$label ($typeLabel)",
                    typeLabel = typeLabel,
                    isInput = true,
                    isWiredOrUsb = isExternal
                )
            )
        }
        return result
    }

    fun getOutputDevices(): List<AudioDeviceEntry> {
        val devices = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        val result = mutableListOf(
            AudioDeviceEntry(
                id = 0,
                name = "System Default Output",
                typeLabel = "Auto",
                isInput = false,
                isWiredOrUsb = false
            )
        )
        devices.forEach { dev ->
            val typeLabel = mapDeviceType(dev.type)
            val isExternal = dev.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                dev.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                dev.type == AudioDeviceInfo.TYPE_USB_DEVICE ||
                dev.type == AudioDeviceInfo.TYPE_USB_HEADSET ||
                dev.type == AudioDeviceInfo.TYPE_USB_ACCESSORY
            val label = dev.productName?.toString()?.takeIf { it.isNotBlank() } ?: typeLabel
            result.add(
                AudioDeviceEntry(
                    id = dev.id,
                    name = "$label ($typeLabel)",
                    typeLabel = typeLabel,
                    isInput = false,
                    isWiredOrUsb = isExternal
                )
            )
        }
        return result
    }

    fun isKernelLoopbackCardPresent(): Boolean {
        return runCatching {
            val cards = File("/proc/asound/cards")
            cards.exists() && cards.canRead() && cards.readText().contains("Loopback", ignoreCase = true)
        }.getOrDefault(false)
    }

    fun getPreferredDeviceInfo(deviceId: Int, isInput: Boolean): AudioDeviceInfo? {
        if (deviceId <= 0) return null
        val flag = if (isInput) AudioManager.GET_DEVICES_INPUTS else AudioManager.GET_DEVICES_OUTPUTS
        return audioManager.getDevices(flag).firstOrNull { it.id == deviceId }
    }

    fun getNativeSampleRate(): Int {
        val sr = audioManager.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE)?.toIntOrNull()
        return sr?.takeIf { it >= 16000 } ?: 48000
    }

    fun getNativeFramesPerBurst(): Int {
        val fpb = audioManager.getProperty(AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER)?.toIntOrNull()
        return fpb?.takeIf { it in 64..1024 } ?: 192
    }

    private fun mapDeviceType(type: Int): String {
        return when (type) {
            AudioDeviceInfo.TYPE_BUILTIN_MIC -> "Built-in Mic"
            AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "Speaker"
            AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> "Earpiece"
            AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Wired Headset"
            AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "Wired Headphones"
            AudioDeviceInfo.TYPE_USB_DEVICE -> "USB Audio"
            AudioDeviceInfo.TYPE_USB_HEADSET -> "USB Headset"
            AudioDeviceInfo.TYPE_USB_ACCESSORY -> "USB Accessory"
            AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "Bluetooth SCO"
            AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "Bluetooth A2DP"
            else -> if (Build.VERSION.SDK_INT >= 31 && type == AudioDeviceInfo.TYPE_BLE_HEADSET) {
                "LE Audio Headset"
            } else {
                "Audio Device"
            }
        }
    }
}
