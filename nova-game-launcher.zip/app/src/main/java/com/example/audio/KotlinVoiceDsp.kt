package com.example.audio

import com.example.model.VoiceParameters
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tanh

/**
 * Pure Kotlin real-time DSP processor mirroring NovaDspPipeline.h.
 * Used as a fallback audio engine when native Oboe stream creation is unavailable
 * and for offline/Robolectric verification of DSP behavior.
 */
class KotlinVoiceDsp {
    companion object {
        private const val TWO_PI = (2.0 * PI).toFloat()
        private const val PITCH_BUF_SIZE = 4096
        private const val PITCH_MASK = PITCH_BUF_SIZE - 1
        private const val WINDOW_SIZE = 768
        private const val ECHO_BUF_SIZE = 24000
        private const val ROBOT_COMB_SIZE = 512
        const val WAVE_BINS = 48
    }

    private class Biquad {
        private var b0 = 1f
        private var b1 = 0f
        private var b2 = 0f
        private var a1 = 0f
        private var a2 = 0f
        private var z1 = 0f
        private var z2 = 0f

        fun reset() {
            z1 = 0f
            z2 = 0f
        }

        fun setHighPass(sr: Float, freq: Float, q: Float = 0.707f) {
            val w0 = TWO_PI * freq.coerceIn(20f, sr * 0.45f) / sr
            val cosW0 = cos(w0)
            val alpha = sin(w0) / (2f * q.coerceAtLeast(0.1f))
            val a0 = 1f + alpha
            b0 = ((1f + cosW0) * 0.5f) / a0
            b1 = -(1f + cosW0) / a0
            b2 = ((1f + cosW0) * 0.5f) / a0
            a1 = (-2f * cosW0) / a0
            a2 = (1f - alpha) / a0
        }

        fun setLowPass(sr: Float, freq: Float, q: Float = 0.707f) {
            val w0 = TWO_PI * freq.coerceIn(20f, sr * 0.45f) / sr
            val cosW0 = cos(w0)
            val alpha = sin(w0) / (2f * q.coerceAtLeast(0.1f))
            val a0 = 1f + alpha
            b0 = ((1f - cosW0) * 0.5f) / a0
            b1 = (1f - cosW0) / a0
            b2 = ((1f - cosW0) * 0.5f) / a0
            a1 = (-2f * cosW0) / a0
            a2 = (1f - alpha) / a0
        }

        fun setPeaking(sr: Float, freq: Float, q: Float, gainDb: Float) {
            val a = 10f.pow(gainDb.coerceIn(-18f, 18f) / 40f)
            val w0 = TWO_PI * freq.coerceIn(30f, sr * 0.45f) / sr
            val cosW0 = cos(w0)
            val alpha = sin(w0) / (2f * q.coerceAtLeast(0.2f))
            val a0 = 1f + alpha / a
            b0 = (1f + alpha * a) / a0
            b1 = (-2f * cosW0) / a0
            b2 = (1f - alpha * a) / a0
            a1 = (-2f * cosW0) / a0
            a2 = (1f - alpha / a) / a0
        }

        fun setLowShelf(sr: Float, freq: Float, gainDb: Float) {
            val a = 10f.pow(gainDb.coerceIn(-18f, 18f) / 40f)
            val w0 = TWO_PI * freq.coerceIn(30f, sr * 0.45f) / sr
            val cosW0 = cos(w0)
            val sinW0 = sin(w0)
            val alpha = sinW0 / 2f * sqrt((a + 1f / a) * (1f / 0.707f - 1f) + 2f)
            val twoSqrtAAlpha = 2f * sqrt(a) * alpha
            val a0 = (a + 1f) + (a - 1f) * cosW0 + twoSqrtAAlpha
            b0 = (a * ((a + 1f) - (a - 1f) * cosW0 + twoSqrtAAlpha)) / a0
            b1 = (2f * a * ((a - 1f) - (a + 1f) * cosW0)) / a0
            b2 = (a * ((a + 1f) - (a - 1f) * cosW0 - twoSqrtAAlpha)) / a0
            a1 = (-2f * ((a - 1f) + (a + 1f) * cosW0)) / a0
            a2 = ((a + 1f) + (a - 1f) * cosW0 - twoSqrtAAlpha) / a0
        }

        fun setHighShelf(sr: Float, freq: Float, gainDb: Float) {
            val a = 10f.pow(gainDb.coerceIn(-18f, 18f) / 40f)
            val w0 = TWO_PI * freq.coerceIn(30f, sr * 0.45f) / sr
            val cosW0 = cos(w0)
            val sinW0 = sin(w0)
            val alpha = sinW0 / 2f * sqrt((a + 1f / a) * (1f / 0.707f - 1f) + 2f)
            val twoSqrtAAlpha = 2f * sqrt(a) * alpha
            val a0 = (a + 1f) - (a - 1f) * cosW0 + twoSqrtAAlpha
            b0 = (a * ((a + 1f) + (a - 1f) * cosW0 + twoSqrtAAlpha)) / a0
            b1 = (-2f * a * ((a - 1f) + (a + 1f) * cosW0)) / a0
            b2 = (a * ((a + 1f) + (a - 1f) * cosW0 - twoSqrtAAlpha)) / a0
            a1 = (2f * ((a - 1f) - (a + 1f) * cosW0)) / a0
            a2 = ((a + 1f) - (a - 1f) * cosW0 - twoSqrtAAlpha) / a0
        }

        fun process(x: Float): Float {
            val y = b0 * x + z1
            z1 = b1 * x - a1 * y + z2
            z2 = b2 * x - a2 * y
            return y
        }
    }

    private var sampleRate = 48000f
    private var lastParams: VoiceParameters? = null

    private val pitchBuf = FloatArray(PITCH_BUF_SIZE)
    private val echoBuf = FloatArray(ECHO_BUF_SIZE)
    private val robotComb = FloatArray(ROBOT_COMB_SIZE)

    private val comb1 = FloatArray(1600)
    private val comb2 = FloatArray(1650)
    private val comb3 = FloatArray(1520)
    private val comb4 = FloatArray(1450)
    private val ap1 = FloatArray(256)
    private val ap2 = FloatArray(580)

    private var writeIdx = 0
    private var echoIdx = 0
    private var robotCombIdx = 0
    private var c1Idx = 0
    private var c2Idx = 0
    private var c3Idx = 0
    private var c4Idx = 0
    private var ap1Idx = 0
    private var ap2Idx = 0

    private var phaseA = 0f
    private var delayA = WINDOW_SIZE * 0.5f
    private var delayB = WINDOW_SIZE * 0.5f
    private var noiseFloor = 0.002f
    private var gateGain = 1f
    private var envFollower = 0f
    private var modPhase1 = 0f
    private var modPhase2 = 0f
    private var lfoPhase = 0f

    private val hpfInput = Biquad()
    private val chestFilter = Biquad()
    private val f1Filter = Biquad()
    private val f2Filter = Biquad()
    private val f3Filter = Biquad()
    private val cartoonFilter = Biquad()
    private val brightnessFilter = Biquad()
    private val toneFilter = Biquad()
    private val softnessFilter = Biquad()
    private val radioHpf = Biquad()
    private val radioLpf = Biquad()
    private val eqBass = Biquad()
    private val eqMid = Biquad()
    private val eqTreble = Biquad()

    @Volatile var inputRms: Float = 0f
        private set
    @Volatile var outputRms: Float = 0f
        private set
    @Volatile var peakLevel: Float = 0f
        private set

    private val waveform = FloatArray(WAVE_BINS)
    private var waveIdx = 0

    fun prepare(sampleRateHz: Float) {
        sampleRate = sampleRateHz.coerceAtLeast(16000f)
        pitchBuf.fill(0f)
        echoBuf.fill(0f)
        robotComb.fill(0f)
        comb1.fill(0f)
        comb2.fill(0f)
        comb3.fill(0f)
        comb4.fill(0f)
        ap1.fill(0f)
        ap2.fill(0f)
        writeIdx = 0
        echoIdx = 0
        robotCombIdx = 0
        c1Idx = 0; c2Idx = 0; c3Idx = 0; c4Idx = 0
        ap1Idx = 0; ap2Idx = 0
        phaseA = 0f
        delayA = WINDOW_SIZE * 0.5f
        delayB = WINDOW_SIZE * 0.5f
        noiseFloor = 0.002f
        gateGain = 1f
        envFollower = 0f
        modPhase1 = 0f
        modPhase2 = 0f
        lfoPhase = 0f
        hpfInput.reset()
        hpfInput.setHighPass(sampleRate, 75f, 0.707f)
        lastParams = null
        updateFilters(VoiceParameters())
    }

    fun processBlock(
        input: FloatArray,
        output: FloatArray,
        numFrames: Int,
        params: VoiceParameters,
        effectEnabled: Boolean,
        bypassOriginal: Boolean
    ) {
        updateFilters(params)

        val pitchRatio = 2f.pow(params.pitchSemitones.coerceIn(-12f, 12f) / 12f)
        val rateDelta = 1f - pitchRatio
        val mix = if (bypassOriginal || !effectEnabled) 0f else params.effectIntensity.coerceIn(0f, 1f)
        val echoDelaySamples = (sampleRate * 0.21f).toInt().coerceIn(64, ECHO_BUF_SIZE - 1)
        val robotCombDelay = (sampleRate * 0.0058f).toInt().coerceIn(16, ROBOT_COMB_SIZE - 1)

        var sumInSq = 0.0
        var sumOutSq = 0.0
        var maxPeak = 0f

        for (i in 0 until numFrames) {
            val rawIn = input[i] * params.inputGain
            var clean = hpfInput.process(rawIn)
            sumInSq += (clean * clean).toDouble()

            val absS = abs(clean)
            envFollower = 0.992f * envFollower + 0.008f * absS
            if (params.noiseReduction) {
                noiseFloor = if (envFollower < noiseFloor * 1.4f) {
                    0.9992f * noiseFloor + 0.0008f * envFollower
                } else {
                    0.9999f * noiseFloor + 0.0001f * envFollower
                }
                val threshold = (noiseFloor * 2.2f).coerceAtLeast(0.0035f)
                val ratio = (envFollower / threshold)
                val targetGate = if (envFollower >= threshold) 1f else (ratio * ratio).coerceIn(0.08f, 1f)
                val coeff = if (targetGate > gateGain) 0.05f else 0.004f
                gateGain += coeff * (targetGate - gateGain)
                clean *= gateGain
            }

            pitchBuf[writeIdx and PITCH_MASK] = clean

            var pitched = clean
            if (abs(params.pitchSemitones) > 0.05f) {
                var phaseB = phaseA + 0.5f
                if (phaseB >= 1f) phaseB -= 1f

                val prevPhaseA = phaseA
                phaseA += 1f / WINDOW_SIZE
                if (phaseA >= 1f) {
                    phaseA -= 1f
                    delayA = findAlignedDelay(delayB)
                }
                var prevPhaseB = prevPhaseA + 0.5f
                if (prevPhaseB >= 1f) prevPhaseB -= 1f
                if (prevPhaseB > phaseB) {
                    delayB = findAlignedDelay(delayA)
                }

                delayA += rateDelta
                delayB += rateDelta
                val minDelay = 16f
                val maxDelay = (PITCH_BUF_SIZE - 64).toFloat()
                if (delayA < minDelay) delayA += WINDOW_SIZE
                if (delayA > maxDelay) delayA -= WINDOW_SIZE
                if (delayB < minDelay) delayB += WINDOW_SIZE
                if (delayB > maxDelay) delayB -= WINDOW_SIZE

                val wA = 0.5f * (1f - cos(TWO_PI * phaseA))
                val wB = 0.5f * (1f - cos(TWO_PI * phaseB))
                val sA = readLinear(writeIdx - delayA)
                val sB = readLinear(writeIdx - delayB)
                pitched = sA * wA + sB * wB
            }

            var vocal = chestFilter.process(pitched)
            vocal = f1Filter.process(vocal)
            vocal = f2Filter.process(vocal)
            vocal = f3Filter.process(vocal)
            vocal = cartoonFilter.process(vocal)
            vocal = brightnessFilter.process(vocal)
            vocal = toneFilter.process(vocal)

            if (params.softness > 0.01f) {
                val softened = softnessFilter.process(vocal)
                val drive = 1f + 0.35f * params.softness
                val warm = tanh(softened * drive) / tanh(drive)
                vocal = vocal * (1f - params.softness) + warm * params.softness
            }

            when (params.characterMode) {
                1 -> {
                    modPhase1 += TWO_PI * 112f / sampleRate
                    if (modPhase1 > TWO_PI) modPhase1 -= TWO_PI
                    val carrier = 0.65f * sin(modPhase1) + 0.35f * (if (modPhase1 < PI) 1f else -1f)
                    val readComb = (robotCombIdx - robotCombDelay + ROBOT_COMB_SIZE) % ROBOT_COMB_SIZE
                    val combOut = vocal + 0.48f * robotComb[readComb]
                    robotComb[robotCombIdx] = combOut
                    robotCombIdx = (robotCombIdx + 1) % ROBOT_COMB_SIZE
                    vocal = 0.55f * (vocal * carrier) + 0.45f * combOut
                }
                2 -> {
                    lfoPhase += TWO_PI * 4.5f / sampleRate
                    if (lfoPhase > TWO_PI) lfoPhase -= TWO_PI
                    val fmFreq = 46f + 18f * sin(lfoPhase)
                    modPhase1 += TWO_PI * fmFreq / sampleRate
                    modPhase2 += TWO_PI * 165f / sampleRate
                    if (modPhase1 > TWO_PI) modPhase1 -= TWO_PI
                    if (modPhase2 > TWO_PI) modPhase2 -= TWO_PI
                    val ring = 0.65f * sin(modPhase1) + 0.35f * sin(modPhase2)
                    vocal = 0.62f * (vocal * ring) + 0.38f * vocal
                }
                3 -> {
                    var bp = radioHpf.process(vocal)
                    bp = radioLpf.process(bp)
                    vocal = tanh(bp * 2.1f) * 0.72f
                }
            }

            var eqOut = eqBass.process(vocal)
            eqOut = eqMid.process(eqOut)
            eqOut = eqTreble.process(eqOut)

            var fxOut = eqOut
            if (params.echoAmount > 0.01f) {
                val rIdx = (echoIdx - echoDelaySamples + ECHO_BUF_SIZE) % ECHO_BUF_SIZE
                val delayed = echoBuf[rIdx]
                echoBuf[echoIdx] = eqOut + delayed * 0.36f
                echoIdx = (echoIdx + 1) % ECHO_BUF_SIZE
                fxOut += delayed * (params.echoAmount * 0.55f)
            } else {
                echoBuf[echoIdx] = 0f
                echoIdx = (echoIdx + 1) % ECHO_BUF_SIZE
            }

            if (params.reverbAmount > 0.01f) {
                fxOut += processReverb(eqOut) * (params.reverbAmount * 0.45f)
            }

            val blended = clean * (1f - mix) + fxOut * mix
            val outSample = tanh(blended * params.outputGain * 0.92f)
            output[i] = outSample
            sumOutSq += (outSample * outSample).toDouble()
            maxPeak = maxOf(maxPeak, abs(outSample))

            if ((writeIdx and 63) == 0) {
                waveform[waveIdx % WAVE_BINS] = outSample
                waveIdx++
            }
            writeIdx = (writeIdx + 1) and PITCH_MASK
        }

        if (numFrames > 0) {
            inputRms = sqrt(sumInSq / numFrames).toFloat()
            outputRms = sqrt(sumOutSq / numFrames).toFloat()
            peakLevel = maxPeak
        }
    }

    fun getWaveformSnapshot(): List<Float> {
        val out = ArrayList<Float>(WAVE_BINS)
        val head = waveIdx
        for (i in 0 until WAVE_BINS) {
            val idx = (head - WAVE_BINS + i + WAVE_BINS * 4) % WAVE_BINS
            out.add(waveform[idx])
        }
        return out
    }

    private fun readLinear(indexArg: Float): Float {
        var index = indexArg
        while (index < 0f) index += PITCH_BUF_SIZE
        val i0 = floor(index).toInt() and PITCH_MASK
        val i1 = (i0 + 1) and PITCH_MASK
        val frac = index - floor(index)
        return pitchBuf[i0] * (1f - frac) + pitchBuf[i1] * frac
    }

    private fun findAlignedDelay(refDelay: Float): Float {
        val baseDelay = WINDOW_SIZE * 0.5f
        var bestOffset = 0f
        var bestCorr = -1e9f
        var offset = -36
        while (offset <= 36) {
            val cand = baseDelay + offset
            var corr = 0f
            var k = 0
            while (k < 24) {
                val a = readLinear(writeIdx - cand - k)
                val b = readLinear(writeIdx - refDelay - k)
                corr += a * b
                k += 2
            }
            if (corr > bestCorr) {
                bestCorr = corr
                bestOffset = offset.toFloat()
            }
            offset += 4
        }
        return (baseDelay + bestOffset).coerceIn(32f, (PITCH_BUF_SIZE - 128).toFloat())
    }

    private fun processReverb(x: Float): Float {
        val d1 = 1557; val d2 = 1617; val d3 = 1491; val d4 = 1422
        val a1 = 225; val a2 = 556

        val c1 = comb1[c1Idx]; comb1[c1Idx] = x + c1 * 0.72f; c1Idx = (c1Idx + 1) % d1
        val c2 = comb2[c2Idx]; comb2[c2Idx] = x + c2 * 0.70f; c2Idx = (c2Idx + 1) % d2
        val c3 = comb3[c3Idx]; comb3[c3Idx] = x + c3 * 0.68f; c3Idx = (c3Idx + 1) % d3
        val c4 = comb4[c4Idx]; comb4[c4Idx] = x + c4 * 0.66f; c4Idx = (c4Idx + 1) % d4

        val sum = (c1 + c2 + c3 + c4) * 0.25f

        val buf1 = ap1[ap1Idx]; val out1 = -sum + buf1; ap1[ap1Idx] = sum + buf1 * 0.5f; ap1Idx = (ap1Idx + 1) % a1
        val buf2 = ap2[ap2Idx]; val out2 = -out1 + buf2; ap2[ap2Idx] = out1 + buf2 * 0.5f; ap2Idx = (ap2Idx + 1) % a2
        return out2
    }

    private fun updateFilters(p: VoiceParameters) {
        val prev = lastParams
        if (prev != null &&
            abs(p.formantShift - prev.formantShift) < 0.005f &&
            abs(p.brightness - prev.brightness) < 0.005f &&
            abs(p.softness - prev.softness) < 0.005f &&
            abs(p.tone - prev.tone) < 0.005f &&
            abs(p.cartoonTone - prev.cartoonTone) < 0.005f &&
            abs(p.eqBassDb - prev.eqBassDb) < 0.05f &&
            abs(p.eqMidDb - prev.eqMidDb) < 0.05f &&
            abs(p.eqTrebleDb - prev.eqTrebleDb) < 0.05f
        ) {
            return
        }
        lastParams = p

        val fs = p.formantShift.coerceIn(0.65f, 1.45f)
        val delta = fs - 1f
        val chestDb = (-delta * 16f).coerceIn(-10f, 9f)
        chestFilter.setLowShelf(sampleRate, 210f, chestDb)
        f1Filter.setPeaking(sampleRate, 520f * fs, 1.35f, delta * 12f)
        f2Filter.setPeaking(sampleRate, 1480f * fs, 1.65f, delta * 14f)
        f3Filter.setPeaking(sampleRate, 2650f * fs, 1.85f, delta * 10f)
        cartoonFilter.setPeaking(sampleRate, 2150f, 2.3f, p.cartoonTone * 9.5f)
        brightnessFilter.setHighShelf(sampleRate, 3500f, p.brightness * 9f)
        toneFilter.setPeaking(sampleRate, 1150f, 0.9f, p.tone * 6f)
        softnessFilter.setPeaking(sampleRate, 2400f, 1.4f, -p.softness * 5.5f)
        radioHpf.setHighPass(sampleRate, 360f, 0.85f)
        radioLpf.setLowPass(sampleRate, 3050f, 0.85f)
        eqBass.setLowShelf(sampleRate, 120f, p.eqBassDb)
        eqMid.setPeaking(sampleRate, 1200f, 1.0f, p.eqMidDb)
        eqTreble.setHighShelf(sampleRate, 5400f, p.eqTrebleDb)
    }
}
