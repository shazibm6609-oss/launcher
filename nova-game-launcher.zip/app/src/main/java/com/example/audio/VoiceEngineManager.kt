package com.example.audio

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Build
import android.os.Process
import com.example.model.AudioDeviceEntry
import com.example.model.AudioRoutingStatus
import com.example.model.VoiceEngineMetrics
import com.example.model.VoiceParameters
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.log10

class VoiceEngineManager(private val context: Context) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val router = AudioDeviceRouter(context)
    private val kotlinDsp = KotlinVoiceDsp()

    private val _metrics = MutableStateFlow(VoiceEngineMetrics())
    val metrics: StateFlow<VoiceEngineMetrics> = _metrics.asStateFlow()

    private val _routingStatus = MutableStateFlow(AudioRoutingStatus())
    val routingStatus: StateFlow<AudioRoutingStatus> = _routingStatus.asStateFlow()

    private val _inputDevices = MutableStateFlow<List<AudioDeviceEntry>>(emptyList())
    val inputDevices: StateFlow<List<AudioDeviceEntry>> = _inputDevices.asStateFlow()

    private val _outputDevices = MutableStateFlow<List<AudioDeviceEntry>>(emptyList())
    val outputDevices: StateFlow<List<AudioDeviceEntry>> = _outputDevices.asStateFlow()

    @Volatile private var currentParams = VoiceParameters()
    @Volatile private var effectEnabled = true
    @Volatile private var bypassOriginal = false
    @Volatile private var selectedInputId = 0
    @Volatile private var selectedOutputId = 0

    private var usingNative = false
    private var kotlinAudioJob: Job? = null
    private var monitorJob: Job? = null
    private var recordJob: Job? = null
    private var previewPlayJob: Job? = null

    private var recordedSamples: FloatArray = FloatArray(0)
    private var recordedSampleRate: Int = 48000

    init {
        refreshAudioDevices()
    }

    fun refreshAudioDevices() {
        val inputs = router.getInputDevices()
        val outputs = router.getOutputDevices()
        _inputDevices.value = inputs
        _outputDevices.value = outputs
        updateRoutingSummary(isRunning = _metrics.value.isProcessing)
    }

    fun setDevices(inputId: Int, outputId: Int) {
        val changed = (inputId != selectedInputId || outputId != selectedOutputId)
        selectedInputId = inputId
        selectedOutputId = outputId
        updateRoutingSummary(isRunning = _metrics.value.isProcessing)
        if (changed && _metrics.value.isProcessing) {
            val sr = router.getNativeSampleRate()
            val fpb = router.getNativeFramesPerBurst()
            stopLiveProcessing()
            startLiveProcessing(sr, fpb)
        }
    }

    fun updateParameters(params: VoiceParameters, effectOn: Boolean, originalPreview: Boolean) {
        currentParams = params
        effectEnabled = effectOn
        bypassOriginal = originalPreview
        if (usingNative) {
            NativeVoiceBridge.pushParams(effectOn, originalPreview, params)
        }
    }

    fun startLiveProcessing(preferredSampleRate: Int = 0, preferredFramesPerBurst: Int = 0): Boolean {
        if (_metrics.value.isProcessing) return true
        stopRecordedPreview()

        val sr = if (preferredSampleRate >= 16000) preferredSampleRate else router.getNativeSampleRate()
        val fpb = if (preferredFramesPerBurst in 64..1024) preferredFramesPerBurst else router.getNativeFramesPerBurst()

        var started = false
        if (NativeVoiceBridge.isNativeLoaded) {
            NativeVoiceBridge.pushParams(effectEnabled, bypassOriginal, currentParams)
            started = NativeVoiceBridge.nativeStart(selectedInputId, selectedOutputId, sr, fpb)
            usingNative = started
        }

        if (!started) {
            usingNative = false
            started = startKotlinFallbackLoop(sr, fpb)
        }

        if (started) {
            _metrics.value = _metrics.value.copy(isProcessing = true)
            startForegroundService()
            startMonitorLoop()
            updateRoutingSummary(isRunning = true)
        }
        return started
    }

    fun stopLiveProcessing() {
        monitorJob?.cancel()
        monitorJob = null

        if (usingNative && NativeVoiceBridge.isNativeLoaded) {
            NativeVoiceBridge.nativeStop()
        }
        usingNative = false

        kotlinAudioJob?.cancel()
        kotlinAudioJob = null

        stopForegroundService()
        _metrics.value = _metrics.value.copy(
            isProcessing = false,
            inputDb = -60f,
            outputDb = -60f,
            peakDb = -60f,
            waveform = List(48) { 0f }
        )
        updateRoutingSummary(isRunning = false)
    }

    @SuppressLint("MissingPermission")
    private fun startKotlinFallbackLoop(sampleRate: Int, framesPerBurst: Int): Boolean {
        val minIn = AudioRecord.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_FLOAT
        )
        val minOut = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_FLOAT
        )
        if (minIn <= 0 || minOut <= 0) return false

        val blockSize = framesPerBurst.coerceIn(128, 512)
        val recorder = AudioRecord.Builder()
            .setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION)
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(minIn, blockSize * 4 * 4))
            .build()

        val trackBuilder = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(minOut, blockSize * 4 * 4))
            .setTransferMode(AudioTrack.MODE_STREAM)

        if (Build.VERSION.SDK_INT >= 26) {
            trackBuilder.setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
        }
        val track = trackBuilder.build()

        router.getPreferredDeviceInfo(selectedInputId, true)?.let { recorder.preferredDevice = it }
        router.getPreferredDeviceInfo(selectedOutputId, false)?.let { track.preferredDevice = it }

        if (recorder.state != AudioRecord.STATE_INITIALIZED || track.state != AudioTrack.STATE_INITIALIZED) {
            recorder.release()
            track.release()
            return false
        }

        kotlinDsp.prepare(sampleRate.toFloat())
        kotlinAudioJob = scope.launch(Dispatchers.IO) {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            val inBuf = FloatArray(blockSize)
            val outBuf = FloatArray(blockSize)
            try {
                recorder.startRecording()
                track.play()
                val frameLatencyMs = (blockSize * 2f / sampleRate.toFloat()) * 1000f
                while (isActive) {
                    val read = recorder.read(inBuf, 0, blockSize, AudioRecord.READ_BLOCKING)
                    if (read > 0) {
                        val t0 = System.nanoTime()
                        kotlinDsp.processBlock(
                            input = inBuf,
                            output = outBuf,
                            numFrames = read,
                            params = currentParams,
                            effectEnabled = effectEnabled,
                            bypassOriginal = bypassOriginal
                        )
                        val cpuUs = ((System.nanoTime() - t0) / 1000L).toInt()
                        track.write(outBuf, 0, read, AudioTrack.WRITE_BLOCKING)
                        _routingStatus.value = _routingStatus.value.copy(
                            activeEngine = "AudioTrack Low-Latency (Kotlin DSP)",
                            sampleRateHz = sampleRate,
                            latencyMs = frameLatencyMs,
                            dspCpuUs = cpuUs
                        )
                    }
                }
            } finally {
                runCatching { recorder.stop() }
                runCatching { recorder.release() }
                runCatching { track.stop() }
                runCatching { track.release() }
            }
        }
        return true
    }

    @SuppressLint("MissingPermission")
    fun startSampleRecording(maxSeconds: Int = 8) {
        if (_metrics.value.isProcessing) {
            stopLiveProcessing()
        }
        stopRecordedPreview()
        recordJob?.cancel()

        val sr = router.getNativeSampleRate()
        val maxSamples = sr * maxSeconds
        val minBuf = AudioRecord.getMinBufferSize(
            sr,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_FLOAT
        )
        if (minBuf <= 0) return

        val recorder = AudioRecord.Builder()
            .setAudioSource(MediaRecorder.AudioSource.MIC)
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                    .setSampleRate(sr)
                    .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(minBuf, 4096))
            .build()

        if (recorder.state != AudioRecord.STATE_INITIALIZED) {
            recorder.release()
            return
        }

        _metrics.value = _metrics.value.copy(isRecordingSample = true, recordedDurationSec = 0f)
        recordJob = scope.launch(Dispatchers.IO) {
            val captured = FloatArray(maxSamples)
            var total = 0
            val chunk = FloatArray(512)
            try {
                recorder.startRecording()
                while (isActive && total < maxSamples) {
                    val toRead = minOf(chunk.size, maxSamples - total)
                    val read = recorder.read(chunk, 0, toRead, AudioRecord.READ_BLOCKING)
                    if (read > 0) {
                        System.arraycopy(chunk, 0, captured, total, read)
                        total += read
                        var sq = 0.0
                        for (i in 0 until read) sq += chunk[i] * chunk[i]
                        val rms = kotlin.math.sqrt(sq / read).toFloat()
                        val db = rmsToDb(rms)
                        val wave = List(48) { idx -> chunk[(idx * read / 48).coerceIn(0, read - 1)] }
                        _metrics.value = _metrics.value.copy(
                            inputDb = db,
                            outputDb = db,
                            recordedDurationSec = total.toFloat() / sr.toFloat(),
                            waveform = wave
                        )
                    }
                }
            } finally {
                runCatching { recorder.stop() }
                runCatching { recorder.release() }
                recordedSamples = captured.copyOf(total)
                recordedSampleRate = sr
                _metrics.value = _metrics.value.copy(
                    isRecordingSample = false,
                    hasRecordedSample = total > sr / 4,
                    recordedDurationSec = total.toFloat() / sr.toFloat(),
                    inputDb = -60f,
                    outputDb = -60f
                )
            }
        }
    }

    fun stopSampleRecording() {
        recordJob?.cancel()
        recordJob = null
    }

    fun playRecordedPreview(original: Boolean) {
        val sample = recordedSamples
        if (sample.isEmpty()) return
        stopRecordedPreview()

        val sr = recordedSampleRate
        val minOut = AudioTrack.getMinBufferSize(
            sr,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_FLOAT
        )
        if (minOut <= 0) return

        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                    .setSampleRate(sr)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(minOut, 4096))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        if (track.state != AudioTrack.STATE_INITIALIZED) {
            track.release()
            return
        }

        val previewDsp = KotlinVoiceDsp().apply { prepare(sr.toFloat()) }
        _metrics.value = _metrics.value.copy(isPlayingRecordedPreview = true)

        previewPlayJob = scope.launch(Dispatchers.IO) {
            val block = 512
            val inChunk = FloatArray(block)
            val outChunk = FloatArray(block)
            try {
                track.play()
                var offset = 0
                while (isActive && offset < sample.size) {
                    val count = minOf(block, sample.size - offset)
                    System.arraycopy(sample, offset, inChunk, 0, count)
                    previewDsp.processBlock(
                        input = inChunk,
                        output = outChunk,
                        numFrames = count,
                        params = currentParams,
                        effectEnabled = !original,
                        bypassOriginal = original
                    )
                    track.write(outChunk, 0, count, AudioTrack.WRITE_BLOCKING)
                    _metrics.value = _metrics.value.copy(
                        inputDb = rmsToDb(previewDsp.inputRms),
                        outputDb = rmsToDb(previewDsp.outputRms),
                        peakDb = rmsToDb(previewDsp.peakLevel),
                        waveform = previewDsp.getWaveformSnapshot()
                    )
                    offset += count
                }
            } finally {
                runCatching { track.stop() }
                runCatching { track.release() }
                _metrics.value = _metrics.value.copy(
                    isPlayingRecordedPreview = false,
                    inputDb = -60f,
                    outputDb = -60f,
                    peakDb = -60f,
                    waveform = List(48) { 0f }
                )
            }
        }
    }

    fun stopRecordedPreview() {
        previewPlayJob?.cancel()
        previewPlayJob = null
        _metrics.value = _metrics.value.copy(isPlayingRecordedPreview = false)
    }

    private fun startMonitorLoop() {
        monitorJob?.cancel()
        monitorJob = scope.launch {
            val waveArr = FloatArray(48)
            while (isActive) {
                if (usingNative && NativeVoiceBridge.isNativeLoaded) {
                    val m = NativeVoiceBridge.nativeGetMetrics()
                    NativeVoiceBridge.nativeGetWaveform(waveArr)
                    val apiName = NativeVoiceBridge.nativeGetAudioApi()
                    _metrics.value = _metrics.value.copy(
                        inputDb = rmsToDb(m.getOrElse(0) { 0f }),
                        outputDb = rmsToDb(m.getOrElse(1) { 0f }),
                        peakDb = rmsToDb(m.getOrElse(2) { 0f }),
                        waveform = waveArr.toList()
                    )
                    _routingStatus.value = _routingStatus.value.copy(
                        activeEngine = apiName,
                        latencyMs = m.getOrElse(3) { 0f },
                        dspCpuUs = m.getOrElse(4) { 0f }.toInt(),
                        sampleRateHz = m.getOrElse(5) { 48000f }.toInt()
                    )
                } else {
                    _metrics.value = _metrics.value.copy(
                        inputDb = rmsToDb(kotlinDsp.inputRms),
                        outputDb = rmsToDb(kotlinDsp.outputRms),
                        peakDb = rmsToDb(kotlinDsp.peakLevel),
                        waveform = kotlinDsp.getWaveformSnapshot()
                    )
                }
                delay(33L)
            }
        }
    }

    private fun updateRoutingSummary(isRunning: Boolean) {
        val inputs = _inputDevices.value
        val outputs = _outputDevices.value
        val inDev = inputs.firstOrNull { it.id == selectedInputId } ?: inputs.firstOrNull()
        val outDev = outputs.firstOrNull { it.id == selectedOutputId } ?: outputs.firstOrNull()
        val hasWiredOrUsb = inputs.any { it.isWiredOrUsb } || outputs.any { it.isWiredOrUsb }
        val kernelLoopback = router.isKernelLoopbackCardPresent()

        val summary = when {
            !isRunning -> "Standby — tap Live Mic to activate real-time voice processing"
            kernelLoopback -> "Active ($inDev -> ALSA Loopback detected). Check game mic device."
            hasWiredOrUsb -> "Active (Wired/USB hardware path). External mixer/TRRS splitter can feed game mic."
            else -> "Active (Local Low-Latency Monitor). Use wired/USB headset to avoid speaker feedback."
        }

        _routingStatus.value = _routingStatus.value.copy(
            activeEngine = if (!isRunning) "Standby" else _routingStatus.value.activeEngine,
            inputDeviceName = inDev?.name ?: "Default Microphone",
            outputDeviceName = outDev?.name ?: "Default Output",
            wiredOrUsbConnected = hasWiredOrUsb,
            gameMicInjectionSupported = kernelLoopback,
            routingSummary = summary
        )
    }

    private fun startForegroundService() {
        val intent = Intent(context, VoiceProcessingService::class.java)
        runCatching {
            if (Build.VERSION.SDK_INT >= 26) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }

    private fun stopForegroundService() {
        val intent = Intent(context, VoiceProcessingService::class.java)
        runCatching { context.stopService(intent) }
    }

    private fun rmsToDb(rms: Float): Float {
        if (rms <= 1e-5f) return -60f
        return (20f * log10(rms)).coerceIn(-60f, 0f)
    }
}
