package com.example.shizuku;

interface INovaShizukuService {
    void destroy() = 16777114;
    String runShell(String command) = 1;
    int getProcessUid() = 2;
}
