package com.example

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class NovaUiRobolectricTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun `dashboard navigates to voice studio and displays female and baby presets`() {
        composeRule.mainClock.advanceTimeBy(1500)
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("nav_voice").performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithText("VOICE STUDIO DSP").assertIsDisplayed()
        composeRule.onNodeWithTag("preset_chip_natural_female").assertIsDisplayed()
        composeRule.onNodeWithTag("preset_chip_baby_cartoon").assertIsDisplayed()

        composeRule.onNodeWithTag("preset_chip_baby_cartoon").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Selected: Baby Cartoon").assertIsDisplayed()
    }
}
