package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.audio.KotlinVoiceDsp
import com.example.model.BuiltInVoicePresets
import com.example.model.VoiceParameters
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `app name matches Nova Launcher`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Nova Launcher", appName)
    }

    @Test
    fun `female voice preset shifts fundamental frequency upward naturally without clipping`() {
        val dsp = KotlinVoiceDsp()
        val sr = 48000f
        dsp.prepare(sr)

        val femalePreset = BuiltInVoicePresets.ALL.first { it.id == "natural_female" }
        val numSamples = 16384
        val input = generateVoiceHarmonicSignal(sr, baseFreqHz = 125f, numSamples = numSamples)
        val output = FloatArray(numSamples)

        // Process in real-time 192-sample blocks
        val block = 192
        val inChunk = FloatArray(block)
        val outChunk = FloatArray(block)
        var offset = 0
        while (offset + block <= numSamples) {
            System.arraycopy(input, offset, inChunk, 0, block)
            dsp.processBlock(inChunk, outChunk, block, femalePreset.params, effectEnabled = true, bypassOriginal = false)
            System.arraycopy(outChunk, 0, output, offset, block)
            offset += block
        }

        val tail = output.copyOfRange(8192, offset)
        val peak = tail.maxOf { abs(it) }
        val freqIn = estimateDominantFreq(input.copyOfRange(8192, offset), sr)
        val freqOut = estimateDominantFreq(tail, sr)

        assertTrue("Female voice output should remain audible and non-zero", peak > 0.05f)
        assertTrue("Soft limiter must prevent clipping (peak <= 1.0)", peak <= 1.0f)
        assertTrue("No NaN samples in female voice stream", tail.none { it.isNaN() || it.isInfinite() })
        assertTrue("Female pitch ($freqOut Hz) should shift higher than male input ($freqIn Hz)", freqOut > freqIn * 1.15f)
    }

    @Test
    fun `baby voice preset produces higher pitch and brighter formant than female voice`() {
        val sr = 48000f
        val numSamples = 16384
        val input = generateVoiceHarmonicSignal(sr, baseFreqHz = 130f, numSamples = numSamples)

        val femaleOut = runBlocks(sr, input, BuiltInVoicePresets.ALL.first { it.id == "natural_female" }.params)
        val babyOut = runBlocks(sr, input, BuiltInVoicePresets.ALL.first { it.id == "baby_cartoon" }.params)

        val femaleFreq = estimateDominantFreq(femaleOut.copyOfRange(8192, 16128), sr)
        val babyFreq = estimateDominantFreq(babyOut.copyOfRange(8192, 16128), sr)

        assertTrue("Baby voice ($babyFreq Hz) should shift higher than Natural Female ($femaleFreq Hz)", babyFreq > femaleFreq)
        assertTrue("Baby voice output must not clip", babyOut.maxOf { abs(it) } <= 1.0f)
    }

    @Test
    fun `original voice bypass restores clean input signal without pitch alteration`() {
        val dsp = KotlinVoiceDsp()
        val sr = 48000f
        dsp.prepare(sr)

        val numSamples = 8192
        val input = generateVoiceHarmonicSignal(sr, baseFreqHz = 140f, numSamples = numSamples)
        val output = FloatArray(numSamples)
        val babyParams = BuiltInVoicePresets.ALL.first { it.id == "baby_cartoon" }.params

        dsp.processBlock(input, output, numSamples, babyParams, effectEnabled = true, bypassOriginal = true)

        val freqIn = estimateDominantFreq(input.copyOfRange(2048, 8192), sr)
        val freqOut = estimateDominantFreq(output.copyOfRange(2048, 8192), sr)
        assertEquals(freqIn, freqOut, 8f)
    }

    @Test
    fun `all 12 built in voice presets process continuous audio cleanly without NaN or dropout`() {
        val sr = 48000f
        val input = generateVoiceHarmonicSignal(sr, baseFreqHz = 145f, numSamples = 4096)
        assertEquals(12, BuiltInVoicePresets.ALL.size)

        BuiltInVoicePresets.ALL.forEach { preset ->
            val out = runBlocks(sr, input, preset.params)
            val tailRms = kotlin.math.sqrt(out.drop(1024).map { it * it }.average()).toFloat()
            assertFalse("Preset ${preset.name} produced NaN", out.any { it.isNaN() || it.isInfinite() })
            assertTrue("Preset ${preset.name} dropped audio (rms=$tailRms)", tailRms > 0.02f)
            assertTrue("Preset ${preset.name} clipped", out.maxOf { abs(it) } <= 1.0f)
        }
    }

    private fun runBlocks(sr: Float, input: FloatArray, params: VoiceParameters): FloatArray {
        val dsp = KotlinVoiceDsp().apply { prepare(sr) }
        val output = FloatArray(input.size)
        val block = 192
        val inChunk = FloatArray(block)
        val outChunk = FloatArray(block)
        var offset = 0
        while (offset + block <= input.size) {
            System.arraycopy(input, offset, inChunk, 0, block)
            dsp.processBlock(inChunk, outChunk, block, params, effectEnabled = true, bypassOriginal = false)
            System.arraycopy(outChunk, 0, output, offset, block)
            offset += block
        }
        return output
    }

    private fun generateVoiceHarmonicSignal(sr: Float, baseFreqHz: Float, numSamples: Int): FloatArray {
        return FloatArray(numSamples) { i ->
            val t = i / sr
            val f1 = sin(2.0 * PI * baseFreqHz * t) * 0.45
            val f2 = sin(2.0 * PI * baseFreqHz * 2.0 * t) * 0.25
            val f3 = sin(2.0 * PI * baseFreqHz * 3.0 * t) * 0.12
            (f1 + f2 + f3).toFloat()
        }
    }

    private fun estimateDominantFreq(samples: FloatArray, sr: Float): Float {
        var zeroCrossings = 0
        for (i in 1 until samples.size) {
            if ((samples[i - 1] < 0f && samples[i] >= 0f)) {
                zeroCrossings++
            }
        }
        val durationSec = samples.size / sr
        return zeroCrossings / durationSec
    }
}
